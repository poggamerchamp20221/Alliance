function Fa(e, t) {
  const n = /* @__PURE__ */ Object.create(null), r = e.split(",");
  for (let i = 0; i < r.length; i++)
    n[r[i]] = !0;
  return t ? (i) => !!n[i.toLowerCase()] : (i) => !!n[i];
}
const Ae = {}, Fn = [], kt = () => {
}, uf = () => !1, df = /^on[^a-z]/, ro = (e) => df.test(e), Va = (e) => e.startsWith("onUpdate:"), je = Object.assign, ja = (e, t) => {
  const n = e.indexOf(t);
  n > -1 && e.splice(n, 1);
}, ff = Object.prototype.hasOwnProperty, fe = (e, t) => ff.call(e, t), Q = Array.isArray, Vn = (e) => qr(e) === "[object Map]", er = (e) => qr(e) === "[object Set]", Ls = (e) => qr(e) === "[object Date]", ae = (e) => typeof e == "function", Le = (e) => typeof e == "string", Tr = (e) => typeof e == "symbol", ke = (e) => e !== null && typeof e == "object", yc = (e) => ke(e) && ae(e.then) && ae(e.catch), _c = Object.prototype.toString, qr = (e) => _c.call(e), mf = (e) => qr(e).slice(8, -1), wc = (e) => qr(e) === "[object Object]", Ua = (e) => Le(e) && e !== "NaN" && e[0] !== "-" && "" + parseInt(e, 10) === e, Ai = /* @__PURE__ */ Fa(
  // the leading comma is intentional so empty string "" is also included
  ",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"
), io = (e) => {
  const t = /* @__PURE__ */ Object.create(null);
  return (n) => t[n] || (t[n] = e(n));
}, pf = /-(\w)/g, Mt = io((e) => e.replace(pf, (t, n) => n ? n.toUpperCase() : "")), bf = /\B([A-Z])/g, tr = io(
  (e) => e.replace(bf, "-$1").toLowerCase()
), oo = io(
  (e) => e.charAt(0).toUpperCase() + e.slice(1)
), zo = io(
  (e) => e ? `on${oo(e)}` : ""
), Pr = (e, t) => !Object.is(e, t), Ni = (e, t) => {
  for (let n = 0; n < e.length; n++)
    e[n](t);
}, Di = (e, t, n) => {
  Object.defineProperty(e, t, {
    configurable: !0,
    enumerable: !1,
    value: n
  });
}, zi = (e) => {
  const t = parseFloat(e);
  return isNaN(t) ? e : t;
}, hf = (e) => {
  const t = Le(e) ? Number(e) : NaN;
  return isNaN(t) ? e : t;
};
let $s;
const ea = () => $s || ($s = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {});
function Kr(e) {
  if (Q(e)) {
    const t = {};
    for (let n = 0; n < e.length; n++) {
      const r = e[n], i = Le(r) ? _f(r) : Kr(r);
      if (i)
        for (const o in i)
          t[o] = i[o];
    }
    return t;
  } else {
    if (Le(e))
      return e;
    if (ke(e))
      return e;
  }
}
const vf = /;(?![^(]*\))/g, gf = /:([^]+)/, yf = /\/\*[^]*?\*\//g;
function _f(e) {
  const t = {};
  return e.replace(yf, "").split(vf).forEach((n) => {
    if (n) {
      const r = n.split(gf);
      r.length > 1 && (t[r[0].trim()] = r[1].trim());
    }
  }), t;
}
function _e(e) {
  let t = "";
  if (Le(e))
    t = e;
  else if (Q(e))
    for (let n = 0; n < e.length; n++) {
      const r = _e(e[n]);
      r && (t += r + " ");
    }
  else if (ke(e))
    for (const n in e)
      e[n] && (t += n + " ");
  return t.trim();
}
const wf = "itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly", xf = /* @__PURE__ */ Fa(wf);
function xc(e) {
  return !!e || e === "";
}
function Ef(e, t) {
  if (e.length !== t.length)
    return !1;
  let n = !0;
  for (let r = 0; n && r < e.length; r++)
    n = Xr(e[r], t[r]);
  return n;
}
function Xr(e, t) {
  if (e === t)
    return !0;
  let n = Ls(e), r = Ls(t);
  if (n || r)
    return n && r ? e.getTime() === t.getTime() : !1;
  if (n = Tr(e), r = Tr(t), n || r)
    return e === t;
  if (n = Q(e), r = Q(t), n || r)
    return n && r ? Ef(e, t) : !1;
  if (n = ke(e), r = ke(t), n || r) {
    if (!n || !r)
      return !1;
    const i = Object.keys(e).length, o = Object.keys(t).length;
    if (i !== o)
      return !1;
    for (const a in e) {
      const s = e.hasOwnProperty(a), l = t.hasOwnProperty(a);
      if (s && !l || !s && l || !Xr(e[a], t[a]))
        return !1;
    }
  }
  return String(e) === String(t);
}
function Ha(e, t) {
  return e.findIndex((n) => Xr(n, t));
}
const ie = (e) => Le(e) ? e : e == null ? "" : Q(e) || ke(e) && (e.toString === _c || !ae(e.toString)) ? JSON.stringify(e, Ec, 2) : String(e), Ec = (e, t) => t && t.__v_isRef ? Ec(e, t.value) : Vn(t) ? {
  [`Map(${t.size})`]: [...t.entries()].reduce((n, [r, i]) => (n[`${r} =>`] = i, n), {})
} : er(t) ? {
  [`Set(${t.size})`]: [...t.values()]
} : ke(t) && !Q(t) && !wc(t) ? String(t) : t;
let yt;
class kf {
  constructor(t = !1) {
    this.detached = t, this._active = !0, this.effects = [], this.cleanups = [], this.parent = yt, !t && yt && (this.index = (yt.scopes || (yt.scopes = [])).push(
      this
    ) - 1);
  }
  get active() {
    return this._active;
  }
  run(t) {
    if (this._active) {
      const n = yt;
      try {
        return yt = this, t();
      } finally {
        yt = n;
      }
    }
  }
  /**
   * This should only be called on non-detached scopes
   * @internal
   */
  on() {
    yt = this;
  }
  /**
   * This should only be called on non-detached scopes
   * @internal
   */
  off() {
    yt = this.parent;
  }
  stop(t) {
    if (this._active) {
      let n, r;
      for (n = 0, r = this.effects.length; n < r; n++)
        this.effects[n].stop();
      for (n = 0, r = this.cleanups.length; n < r; n++)
        this.cleanups[n]();
      if (this.scopes)
        for (n = 0, r = this.scopes.length; n < r; n++)
          this.scopes[n].stop(!0);
      if (!this.detached && this.parent && !t) {
        const i = this.parent.scopes.pop();
        i && i !== this && (this.parent.scopes[this.index] = i, i.index = this.index);
      }
      this.parent = void 0, this._active = !1;
    }
  }
}
function Sf(e, t = yt) {
  t && t.active && t.effects.push(e);
}
function Of() {
  return yt;
}
const Ba = (e) => {
  const t = new Set(e);
  return t.w = 0, t.n = 0, t;
}, kc = (e) => (e.w & nn) > 0, Sc = (e) => (e.n & nn) > 0, Af = ({ deps: e }) => {
  if (e.length)
    for (let t = 0; t < e.length; t++)
      e[t].w |= nn;
}, Nf = (e) => {
  const { deps: t } = e;
  if (t.length) {
    let n = 0;
    for (let r = 0; r < t.length; r++) {
      const i = t[r];
      kc(i) && !Sc(i) ? i.delete(e) : t[n++] = i, i.w &= ~nn, i.n &= ~nn;
    }
    t.length = n;
  }
}, ta = /* @__PURE__ */ new WeakMap();
let pr = 0, nn = 1;
const na = 30;
let wt;
const xn = Symbol(""), ra = Symbol("");
class Ga {
  constructor(t, n = null, r) {
    this.fn = t, this.scheduler = n, this.active = !0, this.deps = [], this.parent = void 0, Sf(this, r);
  }
  run() {
    if (!this.active)
      return this.fn();
    let t = wt, n = en;
    for (; t; ) {
      if (t === this)
        return;
      t = t.parent;
    }
    try {
      return this.parent = wt, wt = this, en = !0, nn = 1 << ++pr, pr <= na ? Af(this) : Fs(this), this.fn();
    } finally {
      pr <= na && Nf(this), nn = 1 << --pr, wt = this.parent, en = n, this.parent = void 0, this.deferStop && this.stop();
    }
  }
  stop() {
    wt === this ? this.deferStop = !0 : this.active && (Fs(this), this.onStop && this.onStop(), this.active = !1);
  }
}
function Fs(e) {
  const { deps: t } = e;
  if (t.length) {
    for (let n = 0; n < t.length; n++)
      t[n].delete(e);
    t.length = 0;
  }
}
let en = !0;
const Oc = [];
function nr() {
  Oc.push(en), en = !1;
}
function rr() {
  const e = Oc.pop();
  en = e === void 0 ? !0 : e;
}
function at(e, t, n) {
  if (en && wt) {
    let r = ta.get(e);
    r || ta.set(e, r = /* @__PURE__ */ new Map());
    let i = r.get(n);
    i || r.set(n, i = Ba()), Ac(i);
  }
}
function Ac(e, t) {
  let n = !1;
  pr <= na ? Sc(e) || (e.n |= nn, n = !kc(e)) : n = !e.has(wt), n && (e.add(wt), wt.deps.push(e));
}
function $t(e, t, n, r, i, o) {
  const a = ta.get(e);
  if (!a)
    return;
  let s = [];
  if (t === "clear")
    s = [...a.values()];
  else if (n === "length" && Q(e)) {
    const l = Number(r);
    a.forEach((c, u) => {
      (u === "length" || u >= l) && s.push(c);
    });
  } else
    switch (n !== void 0 && s.push(a.get(n)), t) {
      case "add":
        Q(e) ? Ua(n) && s.push(a.get("length")) : (s.push(a.get(xn)), Vn(e) && s.push(a.get(ra)));
        break;
      case "delete":
        Q(e) || (s.push(a.get(xn)), Vn(e) && s.push(a.get(ra)));
        break;
      case "set":
        Vn(e) && s.push(a.get(xn));
        break;
    }
  if (s.length === 1)
    s[0] && ia(s[0]);
  else {
    const l = [];
    for (const c of s)
      c && l.push(...c);
    ia(Ba(l));
  }
}
function ia(e, t) {
  const n = Q(e) ? e : [...e];
  for (const r of n)
    r.computed && Vs(r);
  for (const r of n)
    r.computed || Vs(r);
}
function Vs(e, t) {
  (e !== wt || e.allowRecurse) && (e.scheduler ? e.scheduler() : e.run());
}
const If = /* @__PURE__ */ Fa("__proto__,__v_isRef,__isVue"), Nc = new Set(
  /* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((e) => e !== "arguments" && e !== "caller").map((e) => Symbol[e]).filter(Tr)
), Cf = /* @__PURE__ */ Ya(), Tf = /* @__PURE__ */ Ya(!1, !0), Pf = /* @__PURE__ */ Ya(!0), js = /* @__PURE__ */ Mf();
function Mf() {
  const e = {};
  return ["includes", "indexOf", "lastIndexOf"].forEach((t) => {
    e[t] = function(...n) {
      const r = se(this);
      for (let o = 0, a = this.length; o < a; o++)
        at(r, "get", o + "");
      const i = r[t](...n);
      return i === -1 || i === !1 ? r[t](...n.map(se)) : i;
    };
  }), ["push", "pop", "shift", "unshift", "splice"].forEach((t) => {
    e[t] = function(...n) {
      nr();
      const r = se(this)[t].apply(this, n);
      return rr(), r;
    };
  }), e;
}
function Rf(e) {
  const t = se(this);
  return at(t, "has", e), t.hasOwnProperty(e);
}
function Ya(e = !1, t = !1) {
  return function(r, i, o) {
    if (i === "__v_isReactive")
      return !e;
    if (i === "__v_isReadonly")
      return e;
    if (i === "__v_isShallow")
      return t;
    if (i === "__v_raw" && o === (e ? t ? Xf : Mc : t ? Pc : Tc).get(r))
      return r;
    const a = Q(r);
    if (!e) {
      if (a && fe(js, i))
        return Reflect.get(js, i, o);
      if (i === "hasOwnProperty")
        return Rf;
    }
    const s = Reflect.get(r, i, o);
    return (Tr(i) ? Nc.has(i) : If(i)) || (e || at(r, "get", i), t) ? s : Je(s) ? a && Ua(i) ? s : s.value : ke(s) ? e ? Rc(s) : ir(s) : s;
  };
}
const Df = /* @__PURE__ */ Ic(), zf = /* @__PURE__ */ Ic(!0);
function Ic(e = !1) {
  return function(n, r, i, o) {
    let a = n[r];
    if (Gn(a) && Je(a) && !Je(i))
      return !1;
    if (!e && (!Li(i) && !Gn(i) && (a = se(a), i = se(i)), !Q(n) && Je(a) && !Je(i)))
      return a.value = i, !0;
    const s = Q(n) && Ua(r) ? Number(r) < n.length : fe(n, r), l = Reflect.set(n, r, i, o);
    return n === se(o) && (s ? Pr(i, a) && $t(n, "set", r, i) : $t(n, "add", r, i)), l;
  };
}
function Lf(e, t) {
  const n = fe(e, t);
  e[t];
  const r = Reflect.deleteProperty(e, t);
  return r && n && $t(e, "delete", t, void 0), r;
}
function $f(e, t) {
  const n = Reflect.has(e, t);
  return (!Tr(t) || !Nc.has(t)) && at(e, "has", t), n;
}
function Ff(e) {
  return at(e, "iterate", Q(e) ? "length" : xn), Reflect.ownKeys(e);
}
const Cc = {
  get: Cf,
  set: Df,
  deleteProperty: Lf,
  has: $f,
  ownKeys: Ff
}, Vf = {
  get: Pf,
  set(e, t) {
    return !0;
  },
  deleteProperty(e, t) {
    return !0;
  }
}, jf = /* @__PURE__ */ je(
  {},
  Cc,
  {
    get: Tf,
    set: zf
  }
), Wa = (e) => e, ao = (e) => Reflect.getPrototypeOf(e);
function oi(e, t, n = !1, r = !1) {
  e = e.__v_raw;
  const i = se(e), o = se(t);
  n || (t !== o && at(i, "get", t), at(i, "get", o));
  const { has: a } = ao(i), s = r ? Wa : n ? Xa : Mr;
  if (a.call(i, t))
    return s(e.get(t));
  if (a.call(i, o))
    return s(e.get(o));
  e !== i && e.get(t);
}
function ai(e, t = !1) {
  const n = this.__v_raw, r = se(n), i = se(e);
  return t || (e !== i && at(r, "has", e), at(r, "has", i)), e === i ? n.has(e) : n.has(e) || n.has(i);
}
function si(e, t = !1) {
  return e = e.__v_raw, !t && at(se(e), "iterate", xn), Reflect.get(e, "size", e);
}
function Us(e) {
  e = se(e);
  const t = se(this);
  return ao(t).has.call(t, e) || (t.add(e), $t(t, "add", e, e)), this;
}
function Hs(e, t) {
  t = se(t);
  const n = se(this), { has: r, get: i } = ao(n);
  let o = r.call(n, e);
  o || (e = se(e), o = r.call(n, e));
  const a = i.call(n, e);
  return n.set(e, t), o ? Pr(t, a) && $t(n, "set", e, t) : $t(n, "add", e, t), this;
}
function Bs(e) {
  const t = se(this), { has: n, get: r } = ao(t);
  let i = n.call(t, e);
  i || (e = se(e), i = n.call(t, e)), r && r.call(t, e);
  const o = t.delete(e);
  return i && $t(t, "delete", e, void 0), o;
}
function Gs() {
  const e = se(this), t = e.size !== 0, n = e.clear();
  return t && $t(e, "clear", void 0, void 0), n;
}
function li(e, t) {
  return function(r, i) {
    const o = this, a = o.__v_raw, s = se(a), l = t ? Wa : e ? Xa : Mr;
    return !e && at(s, "iterate", xn), a.forEach((c, u) => r.call(i, l(c), l(u), o));
  };
}
function ci(e, t, n) {
  return function(...r) {
    const i = this.__v_raw, o = se(i), a = Vn(o), s = e === "entries" || e === Symbol.iterator && a, l = e === "keys" && a, c = i[e](...r), u = n ? Wa : t ? Xa : Mr;
    return !t && at(
      o,
      "iterate",
      l ? ra : xn
    ), {
      // iterator protocol
      next() {
        const { value: f, done: d } = c.next();
        return d ? { value: f, done: d } : {
          value: s ? [u(f[0]), u(f[1])] : u(f),
          done: d
        };
      },
      // iterable protocol
      [Symbol.iterator]() {
        return this;
      }
    };
  };
}
function Yt(e) {
  return function(...t) {
    return e === "delete" ? !1 : this;
  };
}
function Uf() {
  const e = {
    get(o) {
      return oi(this, o);
    },
    get size() {
      return si(this);
    },
    has: ai,
    add: Us,
    set: Hs,
    delete: Bs,
    clear: Gs,
    forEach: li(!1, !1)
  }, t = {
    get(o) {
      return oi(this, o, !1, !0);
    },
    get size() {
      return si(this);
    },
    has: ai,
    add: Us,
    set: Hs,
    delete: Bs,
    clear: Gs,
    forEach: li(!1, !0)
  }, n = {
    get(o) {
      return oi(this, o, !0);
    },
    get size() {
      return si(this, !0);
    },
    has(o) {
      return ai.call(this, o, !0);
    },
    add: Yt("add"),
    set: Yt("set"),
    delete: Yt("delete"),
    clear: Yt("clear"),
    forEach: li(!0, !1)
  }, r = {
    get(o) {
      return oi(this, o, !0, !0);
    },
    get size() {
      return si(this, !0);
    },
    has(o) {
      return ai.call(this, o, !0);
    },
    add: Yt("add"),
    set: Yt("set"),
    delete: Yt("delete"),
    clear: Yt("clear"),
    forEach: li(!0, !0)
  };
  return ["keys", "values", "entries", Symbol.iterator].forEach((o) => {
    e[o] = ci(
      o,
      !1,
      !1
    ), n[o] = ci(
      o,
      !0,
      !1
    ), t[o] = ci(
      o,
      !1,
      !0
    ), r[o] = ci(
      o,
      !0,
      !0
    );
  }), [
    e,
    n,
    t,
    r
  ];
}
const [
  Hf,
  Bf,
  Gf,
  Yf
] = /* @__PURE__ */ Uf();
function qa(e, t) {
  const n = t ? e ? Yf : Gf : e ? Bf : Hf;
  return (r, i, o) => i === "__v_isReactive" ? !e : i === "__v_isReadonly" ? e : i === "__v_raw" ? r : Reflect.get(
    fe(n, i) && i in r ? n : r,
    i,
    o
  );
}
const Wf = {
  get: /* @__PURE__ */ qa(!1, !1)
}, qf = {
  get: /* @__PURE__ */ qa(!1, !0)
}, Kf = {
  get: /* @__PURE__ */ qa(!0, !1)
}, Tc = /* @__PURE__ */ new WeakMap(), Pc = /* @__PURE__ */ new WeakMap(), Mc = /* @__PURE__ */ new WeakMap(), Xf = /* @__PURE__ */ new WeakMap();
function Jf(e) {
  switch (e) {
    case "Object":
    case "Array":
      return 1;
    case "Map":
    case "Set":
    case "WeakMap":
    case "WeakSet":
      return 2;
    default:
      return 0;
  }
}
function Qf(e) {
  return e.__v_skip || !Object.isExtensible(e) ? 0 : Jf(mf(e));
}
function ir(e) {
  return Gn(e) ? e : Ka(
    e,
    !1,
    Cc,
    Wf,
    Tc
  );
}
function Zf(e) {
  return Ka(
    e,
    !1,
    jf,
    qf,
    Pc
  );
}
function Rc(e) {
  return Ka(
    e,
    !0,
    Vf,
    Kf,
    Mc
  );
}
function Ka(e, t, n, r, i) {
  if (!ke(e) || e.__v_raw && !(t && e.__v_isReactive))
    return e;
  const o = i.get(e);
  if (o)
    return o;
  const a = Qf(e);
  if (a === 0)
    return e;
  const s = new Proxy(
    e,
    a === 2 ? r : n
  );
  return i.set(e, s), s;
}
function jn(e) {
  return Gn(e) ? jn(e.__v_raw) : !!(e && e.__v_isReactive);
}
function Gn(e) {
  return !!(e && e.__v_isReadonly);
}
function Li(e) {
  return !!(e && e.__v_isShallow);
}
function Dc(e) {
  return jn(e) || Gn(e);
}
function se(e) {
  const t = e && e.__v_raw;
  return t ? se(t) : e;
}
function zc(e) {
  return Di(e, "__v_skip", !0), e;
}
const Mr = (e) => ke(e) ? ir(e) : e, Xa = (e) => ke(e) ? Rc(e) : e;
function Lc(e) {
  en && wt && (e = se(e), Ac(e.dep || (e.dep = Ba())));
}
function $c(e, t) {
  e = se(e);
  const n = e.dep;
  n && ia(n);
}
function Je(e) {
  return !!(e && e.__v_isRef === !0);
}
function re(e) {
  return Fc(e, !1);
}
function oa(e) {
  return Fc(e, !0);
}
function Fc(e, t) {
  return Je(e) ? e : new em(e, t);
}
class em {
  constructor(t, n) {
    this.__v_isShallow = n, this.dep = void 0, this.__v_isRef = !0, this._rawValue = n ? t : se(t), this._value = n ? t : Mr(t);
  }
  get value() {
    return Lc(this), this._value;
  }
  set value(t) {
    const n = this.__v_isShallow || Li(t) || Gn(t);
    t = n ? t : se(t), Pr(t, this._rawValue) && (this._rawValue = t, this._value = n ? t : Mr(t), $c(this));
  }
}
function Ja(e) {
  return Je(e) ? e.value : e;
}
const tm = {
  get: (e, t, n) => Ja(Reflect.get(e, t, n)),
  set: (e, t, n, r) => {
    const i = e[t];
    return Je(i) && !Je(n) ? (i.value = n, !0) : Reflect.set(e, t, n, r);
  }
};
function Vc(e) {
  return jn(e) ? e : new Proxy(e, tm);
}
class nm {
  constructor(t, n, r, i) {
    this._setter = n, this.dep = void 0, this.__v_isRef = !0, this.__v_isReadonly = !1, this._dirty = !0, this.effect = new Ga(t, () => {
      this._dirty || (this._dirty = !0, $c(this));
    }), this.effect.computed = this, this.effect.active = this._cacheable = !i, this.__v_isReadonly = r;
  }
  get value() {
    const t = se(this);
    return Lc(t), (t._dirty || !t._cacheable) && (t._dirty = !1, t._value = t.effect.run()), t._value;
  }
  set value(t) {
    this._setter(t);
  }
}
function rm(e, t, n = !1) {
  let r, i;
  const o = ae(e);
  return o ? (r = e, i = kt) : (r = e.get, i = e.set), new nm(r, i, o || !i, n);
}
function tn(e, t, n, r) {
  let i;
  try {
    i = r ? e(...r) : e();
  } catch (o) {
    so(o, t, n);
  }
  return i;
}
function pt(e, t, n, r) {
  if (ae(e)) {
    const o = tn(e, t, n, r);
    return o && yc(o) && o.catch((a) => {
      so(a, t, n);
    }), o;
  }
  const i = [];
  for (let o = 0; o < e.length; o++)
    i.push(pt(e[o], t, n, r));
  return i;
}
function so(e, t, n, r = !0) {
  const i = t ? t.vnode : null;
  if (t) {
    let o = t.parent;
    const a = t.proxy, s = n;
    for (; o; ) {
      const c = o.ec;
      if (c) {
        for (let u = 0; u < c.length; u++)
          if (c[u](e, a, s) === !1)
            return;
      }
      o = o.parent;
    }
    const l = t.appContext.config.errorHandler;
    if (l) {
      tn(
        l,
        null,
        10,
        [e, a, s]
      );
      return;
    }
  }
  im(e, n, i, r);
}
function im(e, t, n, r = !0) {
  console.error(e);
}
let Rr = !1, aa = !1;
const et = [];
let Ct = 0;
const Un = [];
let Dt = null, pn = 0;
const jc = /* @__PURE__ */ Promise.resolve();
let Qa = null;
function Uc(e) {
  const t = Qa || jc;
  return e ? t.then(this ? e.bind(this) : e) : t;
}
function om(e) {
  let t = Ct + 1, n = et.length;
  for (; t < n; ) {
    const r = t + n >>> 1;
    Dr(et[r]) < e ? t = r + 1 : n = r;
  }
  return t;
}
function Za(e) {
  (!et.length || !et.includes(
    e,
    Rr && e.allowRecurse ? Ct + 1 : Ct
  )) && (e.id == null ? et.push(e) : et.splice(om(e.id), 0, e), Hc());
}
function Hc() {
  !Rr && !aa && (aa = !0, Qa = jc.then(Gc));
}
function am(e) {
  const t = et.indexOf(e);
  t > Ct && et.splice(t, 1);
}
function sm(e) {
  Q(e) ? Un.push(...e) : (!Dt || !Dt.includes(
    e,
    e.allowRecurse ? pn + 1 : pn
  )) && Un.push(e), Hc();
}
function Ys(e, t = Rr ? Ct + 1 : 0) {
  for (; t < et.length; t++) {
    const n = et[t];
    n && n.pre && (et.splice(t, 1), t--, n());
  }
}
function Bc(e) {
  if (Un.length) {
    const t = [...new Set(Un)];
    if (Un.length = 0, Dt) {
      Dt.push(...t);
      return;
    }
    for (Dt = t, Dt.sort((n, r) => Dr(n) - Dr(r)), pn = 0; pn < Dt.length; pn++)
      Dt[pn]();
    Dt = null, pn = 0;
  }
}
const Dr = (e) => e.id == null ? 1 / 0 : e.id, lm = (e, t) => {
  const n = Dr(e) - Dr(t);
  if (n === 0) {
    if (e.pre && !t.pre)
      return -1;
    if (t.pre && !e.pre)
      return 1;
  }
  return n;
};
function Gc(e) {
  aa = !1, Rr = !0, et.sort(lm);
  const t = kt;
  try {
    for (Ct = 0; Ct < et.length; Ct++) {
      const n = et[Ct];
      n && n.active !== !1 && tn(n, null, 14);
    }
  } finally {
    Ct = 0, et.length = 0, Bc(), Rr = !1, Qa = null, (et.length || Un.length) && Gc();
  }
}
function cm(e, t, ...n) {
  if (e.isUnmounted)
    return;
  const r = e.vnode.props || Ae;
  let i = n;
  const o = t.startsWith("update:"), a = o && t.slice(7);
  if (a && a in r) {
    const u = `${a === "modelValue" ? "model" : a}Modifiers`, { number: f, trim: d } = r[u] || Ae;
    d && (i = n.map((m) => Le(m) ? m.trim() : m)), f && (i = n.map(zi));
  }
  let s, l = r[s = zo(t)] || // also try camelCase event handler (#2249)
  r[s = zo(Mt(t))];
  !l && o && (l = r[s = zo(tr(t))]), l && pt(
    l,
    e,
    6,
    i
  );
  const c = r[s + "Once"];
  if (c) {
    if (!e.emitted)
      e.emitted = {};
    else if (e.emitted[s])
      return;
    e.emitted[s] = !0, pt(
      c,
      e,
      6,
      i
    );
  }
}
function Yc(e, t, n = !1) {
  const r = t.emitsCache, i = r.get(e);
  if (i !== void 0)
    return i;
  const o = e.emits;
  let a = {}, s = !1;
  if (!ae(e)) {
    const l = (c) => {
      const u = Yc(c, t, !0);
      u && (s = !0, je(a, u));
    };
    !n && t.mixins.length && t.mixins.forEach(l), e.extends && l(e.extends), e.mixins && e.mixins.forEach(l);
  }
  return !o && !s ? (ke(e) && r.set(e, null), null) : (Q(o) ? o.forEach((l) => a[l] = null) : je(a, o), ke(e) && r.set(e, a), a);
}
function lo(e, t) {
  return !e || !ro(t) ? !1 : (t = t.slice(2).replace(/Once$/, ""), fe(e, t[0].toLowerCase() + t.slice(1)) || fe(e, tr(t)) || fe(e, t));
}
let Qe = null, Wc = null;
function $i(e) {
  const t = Qe;
  return Qe = e, Wc = e && e.type.__scopeId || null, t;
}
function ne(e, t = Qe, n) {
  if (!t || e._n)
    return e;
  const r = (...i) => {
    r._d && ol(-1);
    const o = $i(t);
    let a;
    try {
      a = e(...i);
    } finally {
      $i(o), r._d && ol(1);
    }
    return a;
  };
  return r._n = !0, r._c = !0, r._d = !0, r;
}
function Lo(e) {
  const {
    type: t,
    vnode: n,
    proxy: r,
    withProxy: i,
    props: o,
    propsOptions: [a],
    slots: s,
    attrs: l,
    emit: c,
    render: u,
    renderCache: f,
    data: d,
    setupState: m,
    ctx: p,
    inheritAttrs: h
  } = e;
  let _, y;
  const g = $i(e);
  try {
    if (n.shapeFlag & 4) {
      const x = i || r;
      _ = It(
        u.call(
          x,
          x,
          f,
          o,
          m,
          d,
          p
        )
      ), y = l;
    } else {
      const x = t;
      _ = It(
        x.length > 1 ? x(
          o,
          { attrs: l, slots: s, emit: c }
        ) : x(
          o,
          null
          /* we know it doesn't need it */
        )
      ), y = t.props ? l : um(l);
    }
  } catch (x) {
    Sr.length = 0, so(x, e, 1), _ = H(ht);
  }
  let w = _;
  if (y && h !== !1) {
    const x = Object.keys(y), { shapeFlag: I } = w;
    x.length && I & 7 && (a && x.some(Va) && (y = dm(
      y,
      a
    )), w = Ft(w, y));
  }
  return n.dirs && (w = Ft(w), w.dirs = w.dirs ? w.dirs.concat(n.dirs) : n.dirs), n.transition && (w.transition = n.transition), _ = w, $i(g), _;
}
const um = (e) => {
  let t;
  for (const n in e)
    (n === "class" || n === "style" || ro(n)) && ((t || (t = {}))[n] = e[n]);
  return t;
}, dm = (e, t) => {
  const n = {};
  for (const r in e)
    (!Va(r) || !(r.slice(9) in t)) && (n[r] = e[r]);
  return n;
};
function fm(e, t, n) {
  const { props: r, children: i, component: o } = e, { props: a, children: s, patchFlag: l } = t, c = o.emitsOptions;
  if (t.dirs || t.transition)
    return !0;
  if (n && l >= 0) {
    if (l & 1024)
      return !0;
    if (l & 16)
      return r ? Ws(r, a, c) : !!a;
    if (l & 8) {
      const u = t.dynamicProps;
      for (let f = 0; f < u.length; f++) {
        const d = u[f];
        if (a[d] !== r[d] && !lo(c, d))
          return !0;
      }
    }
  } else
    return (i || s) && (!s || !s.$stable) ? !0 : r === a ? !1 : r ? a ? Ws(r, a, c) : !0 : !!a;
  return !1;
}
function Ws(e, t, n) {
  const r = Object.keys(t);
  if (r.length !== Object.keys(e).length)
    return !0;
  for (let i = 0; i < r.length; i++) {
    const o = r[i];
    if (t[o] !== e[o] && !lo(n, o))
      return !0;
  }
  return !1;
}
function mm({ vnode: e, parent: t }, n) {
  for (; t && t.subTree === e; )
    (e = t.vnode).el = n, t = t.parent;
}
const pm = (e) => e.__isSuspense;
function bm(e, t) {
  t && t.pendingBranch ? Q(e) ? t.effects.push(...e) : t.effects.push(e) : sm(e);
}
function st(e, t) {
  return es(e, null, t);
}
const ui = {};
function bt(e, t, n) {
  return es(e, t, n);
}
function es(e, t, { immediate: n, deep: r, flush: i, onTrack: o, onTrigger: a } = Ae) {
  var s;
  const l = Of() === ((s = Ye) == null ? void 0 : s.scope) ? Ye : null;
  let c, u = !1, f = !1;
  if (Je(e) ? (c = () => e.value, u = Li(e)) : jn(e) ? (c = () => e, r = !0) : Q(e) ? (f = !0, u = e.some((x) => jn(x) || Li(x)), c = () => e.map((x) => {
    if (Je(x))
      return x.value;
    if (jn(x))
      return gn(x);
    if (ae(x))
      return tn(x, l, 2);
  })) : ae(e) ? t ? c = () => tn(e, l, 2) : c = () => {
    if (!(l && l.isUnmounted))
      return d && d(), pt(
        e,
        l,
        3,
        [m]
      );
  } : c = kt, t && r) {
    const x = c;
    c = () => gn(x());
  }
  let d, m = (x) => {
    d = g.onStop = () => {
      tn(x, l, 4);
    };
  }, p;
  if ($r)
    if (m = kt, t ? n && pt(t, l, 3, [
      c(),
      f ? [] : void 0,
      m
    ]) : c(), i === "sync") {
      const x = dp();
      p = x.__watcherHandles || (x.__watcherHandles = []);
    } else
      return kt;
  let h = f ? new Array(e.length).fill(ui) : ui;
  const _ = () => {
    if (g.active)
      if (t) {
        const x = g.run();
        (r || u || (f ? x.some(
          (I, U) => Pr(I, h[U])
        ) : Pr(x, h))) && (d && d(), pt(t, l, 3, [
          x,
          // pass undefined as the old value when it's changed for the first time
          h === ui ? void 0 : f && h[0] === ui ? [] : h,
          m
        ]), h = x);
      } else
        g.run();
  };
  _.allowRecurse = !!t;
  let y;
  i === "sync" ? y = _ : i === "post" ? y = () => ot(_, l && l.suspense) : (_.pre = !0, l && (_.id = l.uid), y = () => Za(_));
  const g = new Ga(c, y);
  t ? n ? _() : h = g.run() : i === "post" ? ot(
    g.run.bind(g),
    l && l.suspense
  ) : g.run();
  const w = () => {
    g.stop(), l && l.scope && ja(l.scope.effects, g);
  };
  return p && p.push(w), w;
}
function hm(e, t, n) {
  const r = this.proxy, i = Le(e) ? e.includes(".") ? qc(r, e) : () => r[e] : e.bind(r, r);
  let o;
  ae(t) ? o = t : (o = t.handler, n = t);
  const a = Ye;
  Yn(this);
  const s = es(i, o.bind(r), n);
  return a ? Yn(a) : En(), s;
}
function qc(e, t) {
  const n = t.split(".");
  return () => {
    let r = e;
    for (let i = 0; i < n.length && r; i++)
      r = r[n[i]];
    return r;
  };
}
function gn(e, t) {
  if (!ke(e) || e.__v_skip || (t = t || /* @__PURE__ */ new Set(), t.has(e)))
    return e;
  if (t.add(e), Je(e))
    gn(e.value, t);
  else if (Q(e))
    for (let n = 0; n < e.length; n++)
      gn(e[n], t);
  else if (er(e) || Vn(e))
    e.forEach((n) => {
      gn(n, t);
    });
  else if (wc(e))
    for (const n in e)
      gn(e[n], t);
  return e;
}
function Fi(e, t) {
  const n = Qe;
  if (n === null)
    return e;
  const r = po(n) || n.proxy, i = e.dirs || (e.dirs = []);
  for (let o = 0; o < t.length; o++) {
    let [a, s, l, c = Ae] = t[o];
    a && (ae(a) && (a = {
      mounted: a,
      updated: a
    }), a.deep && gn(s), i.push({
      dir: a,
      instance: r,
      value: s,
      oldValue: void 0,
      arg: l,
      modifiers: c
    }));
  }
  return e;
}
function cn(e, t, n, r) {
  const i = e.dirs, o = t && t.dirs;
  for (let a = 0; a < i.length; a++) {
    const s = i[a];
    o && (s.oldValue = o[a].value);
    let l = s.dir[r];
    l && (nr(), pt(l, n, 8, [
      e.el,
      s,
      e,
      t
    ]), rr());
  }
}
function vm() {
  const e = {
    isMounted: !1,
    isLeaving: !1,
    isUnmounting: !1,
    leavingVNodes: /* @__PURE__ */ new Map()
  };
  return ze(() => {
    e.isMounted = !0;
  }), Zc(() => {
    e.isUnmounting = !0;
  }), e;
}
const ft = [Function, Array], Kc = {
  mode: String,
  appear: Boolean,
  persisted: Boolean,
  // enter
  onBeforeEnter: ft,
  onEnter: ft,
  onAfterEnter: ft,
  onEnterCancelled: ft,
  // leave
  onBeforeLeave: ft,
  onLeave: ft,
  onAfterLeave: ft,
  onLeaveCancelled: ft,
  // appear
  onBeforeAppear: ft,
  onAppear: ft,
  onAfterAppear: ft,
  onAppearCancelled: ft
}, gm = {
  name: "BaseTransition",
  props: Kc,
  setup(e, { slots: t }) {
    const n = rp(), r = vm();
    let i;
    return () => {
      const o = t.default && Jc(t.default(), !0);
      if (!o || !o.length)
        return;
      let a = o[0];
      if (o.length > 1) {
        for (const h of o)
          if (h.type !== ht) {
            a = h;
            break;
          }
      }
      const s = se(e), { mode: l } = s;
      if (r.isLeaving)
        return $o(a);
      const c = qs(a);
      if (!c)
        return $o(a);
      const u = sa(
        c,
        s,
        r,
        n
      );
      la(c, u);
      const f = n.subTree, d = f && qs(f);
      let m = !1;
      const { getTransitionKey: p } = c.type;
      if (p) {
        const h = p();
        i === void 0 ? i = h : h !== i && (i = h, m = !0);
      }
      if (d && d.type !== ht && (!bn(c, d) || m)) {
        const h = sa(
          d,
          s,
          r,
          n
        );
        if (la(d, h), l === "out-in")
          return r.isLeaving = !0, h.afterLeave = () => {
            r.isLeaving = !1, n.update.active !== !1 && n.update();
          }, $o(a);
        l === "in-out" && c.type !== ht && (h.delayLeave = (_, y, g) => {
          const w = Xc(
            r,
            d
          );
          w[String(d.key)] = d, _._leaveCb = () => {
            y(), _._leaveCb = void 0, delete u.delayedLeave;
          }, u.delayedLeave = g;
        });
      }
      return a;
    };
  }
}, ym = gm;
function Xc(e, t) {
  const { leavingVNodes: n } = e;
  let r = n.get(t.type);
  return r || (r = /* @__PURE__ */ Object.create(null), n.set(t.type, r)), r;
}
function sa(e, t, n, r) {
  const {
    appear: i,
    mode: o,
    persisted: a = !1,
    onBeforeEnter: s,
    onEnter: l,
    onAfterEnter: c,
    onEnterCancelled: u,
    onBeforeLeave: f,
    onLeave: d,
    onAfterLeave: m,
    onLeaveCancelled: p,
    onBeforeAppear: h,
    onAppear: _,
    onAfterAppear: y,
    onAppearCancelled: g
  } = t, w = String(e.key), x = Xc(n, e), I = (C, R) => {
    C && pt(
      C,
      r,
      9,
      R
    );
  }, U = (C, R) => {
    const W = R[1];
    I(C, R), Q(C) ? C.every((F) => F.length <= 1) && W() : C.length <= 1 && W();
  }, M = {
    mode: o,
    persisted: a,
    beforeEnter(C) {
      let R = s;
      if (!n.isMounted)
        if (i)
          R = h || s;
        else
          return;
      C._leaveCb && C._leaveCb(
        !0
        /* cancelled */
      );
      const W = x[w];
      W && bn(e, W) && W.el._leaveCb && W.el._leaveCb(), I(R, [C]);
    },
    enter(C) {
      let R = l, W = c, F = u;
      if (!n.isMounted)
        if (i)
          R = _ || l, W = y || c, F = g || u;
        else
          return;
      let A = !1;
      const X = C._enterCb = (ce) => {
        A || (A = !0, ce ? I(F, [C]) : I(W, [C]), M.delayedLeave && M.delayedLeave(), C._enterCb = void 0);
      };
      R ? U(R, [C, X]) : X();
    },
    leave(C, R) {
      const W = String(e.key);
      if (C._enterCb && C._enterCb(
        !0
        /* cancelled */
      ), n.isUnmounting)
        return R();
      I(f, [C]);
      let F = !1;
      const A = C._leaveCb = (X) => {
        F || (F = !0, R(), X ? I(p, [C]) : I(m, [C]), C._leaveCb = void 0, x[W] === e && delete x[W]);
      };
      x[W] = e, d ? U(d, [C, A]) : A();
    },
    clone(C) {
      return sa(C, t, n, r);
    }
  };
  return M;
}
function $o(e) {
  if (co(e))
    return e = Ft(e), e.children = null, e;
}
function qs(e) {
  return co(e) ? e.children ? e.children[0] : void 0 : e;
}
function la(e, t) {
  e.shapeFlag & 6 && e.component ? la(e.component.subTree, t) : e.shapeFlag & 128 ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t;
}
function Jc(e, t = !1, n) {
  let r = [], i = 0;
  for (let o = 0; o < e.length; o++) {
    let a = e[o];
    const s = n == null ? a.key : String(n) + String(a.key != null ? a.key : o);
    a.type === De ? (a.patchFlag & 128 && i++, r = r.concat(
      Jc(a.children, t, s)
    )) : (t || a.type !== ht) && r.push(s != null ? Ft(a, { key: s }) : a);
  }
  if (i > 1)
    for (let o = 0; o < r.length; o++)
      r[o].patchFlag = -2;
  return r;
}
function de(e, t) {
  return ae(e) ? (
    // #8326: extend call and options.name access are considered side-effects
    // by Rollup, so we have to wrap it in a pure-annotated IIFE.
    /* @__PURE__ */ (() => je({ name: e.name }, t, { setup: e }))()
  ) : e;
}
const xr = (e) => !!e.type.__asyncLoader, co = (e) => e.type.__isKeepAlive;
function _m(e, t) {
  Qc(e, "a", t);
}
function wm(e, t) {
  Qc(e, "da", t);
}
function Qc(e, t, n = Ye) {
  const r = e.__wdc || (e.__wdc = () => {
    let i = n;
    for (; i; ) {
      if (i.isDeactivated)
        return;
      i = i.parent;
    }
    return e();
  });
  if (uo(t, r, n), n) {
    let i = n.parent;
    for (; i && i.parent; )
      co(i.parent.vnode) && xm(r, t, n, i), i = i.parent;
  }
}
function xm(e, t, n, r) {
  const i = uo(
    t,
    e,
    r,
    !0
    /* prepend */
  );
  Ze(() => {
    ja(r[t], i);
  }, n);
}
function uo(e, t, n = Ye, r = !1) {
  if (n) {
    const i = n[e] || (n[e] = []), o = t.__weh || (t.__weh = (...a) => {
      if (n.isUnmounted)
        return;
      nr(), Yn(n);
      const s = pt(t, n, e, a);
      return En(), rr(), s;
    });
    return r ? i.unshift(o) : i.push(o), o;
  }
}
const Ht = (e) => (t, n = Ye) => (
  // post-create lifecycle registrations are noops during SSR (except for serverPrefetch)
  (!$r || e === "sp") && uo(e, (...r) => t(...r), n)
), Em = Ht("bm"), ze = Ht("m"), km = Ht("bu"), Sm = Ht("u"), Zc = Ht("bum"), Ze = Ht("um"), Om = Ht("sp"), Am = Ht(
  "rtg"
), Nm = Ht(
  "rtc"
);
function Im(e, t = Ye) {
  uo("ec", e, t);
}
const ts = "components";
function te(e, t) {
  return tu(ts, e, !0, t) || e;
}
const eu = Symbol.for("v-ndc");
function Cm(e) {
  return Le(e) ? tu(ts, e, !1) || e : e || eu;
}
function tu(e, t, n = !0, r = !1) {
  const i = Qe || Ye;
  if (i) {
    const o = i.type;
    if (e === ts) {
      const s = lp(
        o,
        !1
        /* do not include inferred name to avoid breaking existing code */
      );
      if (s && (s === t || s === Mt(t) || s === oo(Mt(t))))
        return o;
    }
    const a = (
      // local registration
      // check instance[type] first which is resolved for options API
      Ks(i[e] || o[e], t) || // global registration
      Ks(i.appContext[e], t)
    );
    return !a && r ? o : a;
  }
}
function Ks(e, t) {
  return e && (e[t] || e[Mt(t)] || e[oo(Mt(t))]);
}
function zr(e, t, n, r) {
  let i;
  const o = n && n[r];
  if (Q(e) || Le(e)) {
    i = new Array(e.length);
    for (let a = 0, s = e.length; a < s; a++)
      i[a] = t(e[a], a, void 0, o && o[a]);
  } else if (typeof e == "number") {
    i = new Array(e);
    for (let a = 0; a < e; a++)
      i[a] = t(a + 1, a, void 0, o && o[a]);
  } else if (ke(e))
    if (e[Symbol.iterator])
      i = Array.from(
        e,
        (a, s) => t(a, s, void 0, o && o[s])
      );
    else {
      const a = Object.keys(e);
      i = new Array(a.length);
      for (let s = 0, l = a.length; s < l; s++) {
        const c = a[s];
        i[s] = t(e[c], c, s, o && o[s]);
      }
    }
  else
    i = [];
  return n && (n[r] = i), i;
}
function Vi(e, t, n = {}, r, i) {
  if (Qe.isCE || Qe.parent && xr(Qe.parent) && Qe.parent.isCE)
    return t !== "default" && (n.name = t), H("slot", n, r && r());
  let o = e[t];
  o && o._c && (o._d = !1), D();
  const a = o && nu(o(n)), s = $e(
    De,
    {
      key: n.key || // slot content array of a dynamic conditional slot may have a branch
      // key attached in the `createSlots` helper, respect that
      a && a.key || `_${t}`
    },
    a || (r ? r() : []),
    a && e._ === 1 ? 64 : -2
  );
  return !i && s.scopeId && (s.slotScopeIds = [s.scopeId + "-s"]), o && o._c && (o._d = !0), s;
}
function nu(e) {
  return e.some((t) => Hi(t) ? !(t.type === ht || t.type === De && !nu(t.children)) : !0) ? e : null;
}
const ca = (e) => e ? mu(e) ? po(e) || e.proxy : ca(e.parent) : null, Er = (
  // Move PURE marker to new line to workaround compiler discarding it
  // due to type annotation
  /* @__PURE__ */ je(/* @__PURE__ */ Object.create(null), {
    $: (e) => e,
    $el: (e) => e.vnode.el,
    $data: (e) => e.data,
    $props: (e) => e.props,
    $attrs: (e) => e.attrs,
    $slots: (e) => e.slots,
    $refs: (e) => e.refs,
    $parent: (e) => ca(e.parent),
    $root: (e) => ca(e.root),
    $emit: (e) => e.emit,
    $options: (e) => ns(e),
    $forceUpdate: (e) => e.f || (e.f = () => Za(e.update)),
    $nextTick: (e) => e.n || (e.n = Uc.bind(e.proxy)),
    $watch: (e) => hm.bind(e)
  })
), Fo = (e, t) => e !== Ae && !e.__isScriptSetup && fe(e, t), Tm = {
  get({ _: e }, t) {
    const { ctx: n, setupState: r, data: i, props: o, accessCache: a, type: s, appContext: l } = e;
    let c;
    if (t[0] !== "$") {
      const m = a[t];
      if (m !== void 0)
        switch (m) {
          case 1:
            return r[t];
          case 2:
            return i[t];
          case 4:
            return n[t];
          case 3:
            return o[t];
        }
      else {
        if (Fo(r, t))
          return a[t] = 1, r[t];
        if (i !== Ae && fe(i, t))
          return a[t] = 2, i[t];
        if (
          // only cache other properties when instance has declared (thus stable)
          // props
          (c = e.propsOptions[0]) && fe(c, t)
        )
          return a[t] = 3, o[t];
        if (n !== Ae && fe(n, t))
          return a[t] = 4, n[t];
        ua && (a[t] = 0);
      }
    }
    const u = Er[t];
    let f, d;
    if (u)
      return t === "$attrs" && at(e, "get", t), u(e);
    if (
      // css module (injected by vue-loader)
      (f = s.__cssModules) && (f = f[t])
    )
      return f;
    if (n !== Ae && fe(n, t))
      return a[t] = 4, n[t];
    if (
      // global properties
      d = l.config.globalProperties, fe(d, t)
    )
      return d[t];
  },
  set({ _: e }, t, n) {
    const { data: r, setupState: i, ctx: o } = e;
    return Fo(i, t) ? (i[t] = n, !0) : r !== Ae && fe(r, t) ? (r[t] = n, !0) : fe(e.props, t) || t[0] === "$" && t.slice(1) in e ? !1 : (o[t] = n, !0);
  },
  has({
    _: { data: e, setupState: t, accessCache: n, ctx: r, appContext: i, propsOptions: o }
  }, a) {
    let s;
    return !!n[a] || e !== Ae && fe(e, a) || Fo(t, a) || (s = o[0]) && fe(s, a) || fe(r, a) || fe(Er, a) || fe(i.config.globalProperties, a);
  },
  defineProperty(e, t, n) {
    return n.get != null ? e._.accessCache[t] = 0 : fe(n, "value") && this.set(e, t, n.value, null), Reflect.defineProperty(e, t, n);
  }
};
function Xs(e) {
  return Q(e) ? e.reduce(
    (t, n) => (t[n] = null, t),
    {}
  ) : e;
}
let ua = !0;
function Pm(e) {
  const t = ns(e), n = e.proxy, r = e.ctx;
  ua = !1, t.beforeCreate && Js(t.beforeCreate, e, "bc");
  const {
    // state
    data: i,
    computed: o,
    methods: a,
    watch: s,
    provide: l,
    inject: c,
    // lifecycle
    created: u,
    beforeMount: f,
    mounted: d,
    beforeUpdate: m,
    updated: p,
    activated: h,
    deactivated: _,
    beforeDestroy: y,
    beforeUnmount: g,
    destroyed: w,
    unmounted: x,
    render: I,
    renderTracked: U,
    renderTriggered: M,
    errorCaptured: C,
    serverPrefetch: R,
    // public API
    expose: W,
    inheritAttrs: F,
    // assets
    components: A,
    directives: X,
    filters: ce
  } = t;
  if (c && Mm(c, r, null), a)
    for (const V in a) {
      const G = a[V];
      ae(G) && (r[V] = G.bind(n));
    }
  if (i) {
    const V = i.call(n, n);
    ke(V) && (e.data = ir(V));
  }
  if (ua = !0, o)
    for (const V in o) {
      const G = o[V], me = ae(G) ? G.bind(n, n) : ae(G.get) ? G.get.bind(n, n) : kt, Ue = !ae(G) && ae(G.set) ? G.set.bind(n) : kt, Te = $({
        get: me,
        set: Ue
      });
      Object.defineProperty(r, V, {
        enumerable: !0,
        configurable: !0,
        get: () => Te.value,
        set: (Me) => Te.value = Me
      });
    }
  if (s)
    for (const V in s)
      ru(s[V], r, n, V);
  if (l) {
    const V = ae(l) ? l.call(n) : l;
    Reflect.ownKeys(V).forEach((G) => {
      rt(G, V[G]);
    });
  }
  u && Js(u, e, "c");
  function J(V, G) {
    Q(G) ? G.forEach((me) => V(me.bind(n))) : G && V(G.bind(n));
  }
  if (J(Em, f), J(ze, d), J(km, m), J(Sm, p), J(_m, h), J(wm, _), J(Im, C), J(Nm, U), J(Am, M), J(Zc, g), J(Ze, x), J(Om, R), Q(W))
    if (W.length) {
      const V = e.exposed || (e.exposed = {});
      W.forEach((G) => {
        Object.defineProperty(V, G, {
          get: () => n[G],
          set: (me) => n[G] = me
        });
      });
    } else
      e.exposed || (e.exposed = {});
  I && e.render === kt && (e.render = I), F != null && (e.inheritAttrs = F), A && (e.components = A), X && (e.directives = X);
}
function Mm(e, t, n = kt) {
  Q(e) && (e = da(e));
  for (const r in e) {
    const i = e[r];
    let o;
    ke(i) ? "default" in i ? o = Ve(
      i.from || r,
      i.default,
      !0
      /* treat default function as factory */
    ) : o = Ve(i.from || r) : o = Ve(i), Je(o) ? Object.defineProperty(t, r, {
      enumerable: !0,
      configurable: !0,
      get: () => o.value,
      set: (a) => o.value = a
    }) : t[r] = o;
  }
}
function Js(e, t, n) {
  pt(
    Q(e) ? e.map((r) => r.bind(t.proxy)) : e.bind(t.proxy),
    t,
    n
  );
}
function ru(e, t, n, r) {
  const i = r.includes(".") ? qc(n, r) : () => n[r];
  if (Le(e)) {
    const o = t[e];
    ae(o) && bt(i, o);
  } else if (ae(e))
    bt(i, e.bind(n));
  else if (ke(e))
    if (Q(e))
      e.forEach((o) => ru(o, t, n, r));
    else {
      const o = ae(e.handler) ? e.handler.bind(n) : t[e.handler];
      ae(o) && bt(i, o, e);
    }
}
function ns(e) {
  const t = e.type, { mixins: n, extends: r } = t, {
    mixins: i,
    optionsCache: o,
    config: { optionMergeStrategies: a }
  } = e.appContext, s = o.get(t);
  let l;
  return s ? l = s : !i.length && !n && !r ? l = t : (l = {}, i.length && i.forEach(
    (c) => ji(l, c, a, !0)
  ), ji(l, t, a)), ke(t) && o.set(t, l), l;
}
function ji(e, t, n, r = !1) {
  const { mixins: i, extends: o } = t;
  o && ji(e, o, n, !0), i && i.forEach(
    (a) => ji(e, a, n, !0)
  );
  for (const a in t)
    if (!(r && a === "expose")) {
      const s = Rm[a] || n && n[a];
      e[a] = s ? s(e[a], t[a]) : t[a];
    }
  return e;
}
const Rm = {
  data: Qs,
  props: Zs,
  emits: Zs,
  // objects
  methods: br,
  computed: br,
  // lifecycle
  beforeCreate: nt,
  created: nt,
  beforeMount: nt,
  mounted: nt,
  beforeUpdate: nt,
  updated: nt,
  beforeDestroy: nt,
  beforeUnmount: nt,
  destroyed: nt,
  unmounted: nt,
  activated: nt,
  deactivated: nt,
  errorCaptured: nt,
  serverPrefetch: nt,
  // assets
  components: br,
  directives: br,
  // watch
  watch: zm,
  // provide / inject
  provide: Qs,
  inject: Dm
};
function Qs(e, t) {
  return t ? e ? function() {
    return je(
      ae(e) ? e.call(this, this) : e,
      ae(t) ? t.call(this, this) : t
    );
  } : t : e;
}
function Dm(e, t) {
  return br(da(e), da(t));
}
function da(e) {
  if (Q(e)) {
    const t = {};
    for (let n = 0; n < e.length; n++)
      t[e[n]] = e[n];
    return t;
  }
  return e;
}
function nt(e, t) {
  return e ? [...new Set([].concat(e, t))] : t;
}
function br(e, t) {
  return e ? je(/* @__PURE__ */ Object.create(null), e, t) : t;
}
function Zs(e, t) {
  return e ? Q(e) && Q(t) ? [.../* @__PURE__ */ new Set([...e, ...t])] : je(
    /* @__PURE__ */ Object.create(null),
    Xs(e),
    Xs(t ?? {})
  ) : t;
}
function zm(e, t) {
  if (!e)
    return t;
  if (!t)
    return e;
  const n = je(/* @__PURE__ */ Object.create(null), e);
  for (const r in t)
    n[r] = nt(e[r], t[r]);
  return n;
}
function iu() {
  return {
    app: null,
    config: {
      isNativeTag: uf,
      performance: !1,
      globalProperties: {},
      optionMergeStrategies: {},
      errorHandler: void 0,
      warnHandler: void 0,
      compilerOptions: {}
    },
    mixins: [],
    components: {},
    directives: {},
    provides: /* @__PURE__ */ Object.create(null),
    optionsCache: /* @__PURE__ */ new WeakMap(),
    propsCache: /* @__PURE__ */ new WeakMap(),
    emitsCache: /* @__PURE__ */ new WeakMap()
  };
}
let Lm = 0;
function $m(e, t) {
  return function(r, i = null) {
    ae(r) || (r = je({}, r)), i != null && !ke(i) && (i = null);
    const o = iu(), a = /* @__PURE__ */ new Set();
    let s = !1;
    const l = o.app = {
      _uid: Lm++,
      _component: r,
      _props: i,
      _container: null,
      _context: o,
      _instance: null,
      version: fp,
      get config() {
        return o.config;
      },
      set config(c) {
      },
      use(c, ...u) {
        return a.has(c) || (c && ae(c.install) ? (a.add(c), c.install(l, ...u)) : ae(c) && (a.add(c), c(l, ...u))), l;
      },
      mixin(c) {
        return o.mixins.includes(c) || o.mixins.push(c), l;
      },
      component(c, u) {
        return u ? (o.components[c] = u, l) : o.components[c];
      },
      directive(c, u) {
        return u ? (o.directives[c] = u, l) : o.directives[c];
      },
      mount(c, u, f) {
        if (!s) {
          const d = H(
            r,
            i
          );
          return d.appContext = o, u && t ? t(d, c) : e(d, c, f), s = !0, l._container = c, c.__vue_app__ = l, po(d.component) || d.component.proxy;
        }
      },
      unmount() {
        s && (e(null, l._container), delete l._container.__vue_app__);
      },
      provide(c, u) {
        return o.provides[c] = u, l;
      },
      runWithContext(c) {
        Ui = l;
        try {
          return c();
        } finally {
          Ui = null;
        }
      }
    };
    return l;
  };
}
let Ui = null;
function rt(e, t) {
  if (Ye) {
    let n = Ye.provides;
    const r = Ye.parent && Ye.parent.provides;
    r === n && (n = Ye.provides = Object.create(r)), n[e] = t;
  }
}
function Ve(e, t, n = !1) {
  const r = Ye || Qe;
  if (r || Ui) {
    const i = r ? r.parent == null ? r.vnode.appContext && r.vnode.appContext.provides : r.parent.provides : Ui._context.provides;
    if (i && e in i)
      return i[e];
    if (arguments.length > 1)
      return n && ae(t) ? t.call(r && r.proxy) : t;
  }
}
function Fm(e, t, n, r = !1) {
  const i = {}, o = {};
  Di(o, mo, 1), e.propsDefaults = /* @__PURE__ */ Object.create(null), ou(e, t, i, o);
  for (const a in e.propsOptions[0])
    a in i || (i[a] = void 0);
  n ? e.props = r ? i : Zf(i) : e.type.props ? e.props = i : e.props = o, e.attrs = o;
}
function Vm(e, t, n, r) {
  const {
    props: i,
    attrs: o,
    vnode: { patchFlag: a }
  } = e, s = se(i), [l] = e.propsOptions;
  let c = !1;
  if (
    // always force full diff in dev
    // - #1942 if hmr is enabled with sfc component
    // - vite#872 non-sfc component used by sfc component
    (r || a > 0) && !(a & 16)
  ) {
    if (a & 8) {
      const u = e.vnode.dynamicProps;
      for (let f = 0; f < u.length; f++) {
        let d = u[f];
        if (lo(e.emitsOptions, d))
          continue;
        const m = t[d];
        if (l)
          if (fe(o, d))
            m !== o[d] && (o[d] = m, c = !0);
          else {
            const p = Mt(d);
            i[p] = fa(
              l,
              s,
              p,
              m,
              e,
              !1
              /* isAbsent */
            );
          }
        else
          m !== o[d] && (o[d] = m, c = !0);
      }
    }
  } else {
    ou(e, t, i, o) && (c = !0);
    let u;
    for (const f in s)
      (!t || // for camelCase
      !fe(t, f) && // it's possible the original props was passed in as kebab-case
      // and converted to camelCase (#955)
      ((u = tr(f)) === f || !fe(t, u))) && (l ? n && // for camelCase
      (n[f] !== void 0 || // for kebab-case
      n[u] !== void 0) && (i[f] = fa(
        l,
        s,
        f,
        void 0,
        e,
        !0
        /* isAbsent */
      )) : delete i[f]);
    if (o !== s)
      for (const f in o)
        (!t || !fe(t, f)) && (delete o[f], c = !0);
  }
  c && $t(e, "set", "$attrs");
}
function ou(e, t, n, r) {
  const [i, o] = e.propsOptions;
  let a = !1, s;
  if (t)
    for (let l in t) {
      if (Ai(l))
        continue;
      const c = t[l];
      let u;
      i && fe(i, u = Mt(l)) ? !o || !o.includes(u) ? n[u] = c : (s || (s = {}))[u] = c : lo(e.emitsOptions, l) || (!(l in r) || c !== r[l]) && (r[l] = c, a = !0);
    }
  if (o) {
    const l = se(n), c = s || Ae;
    for (let u = 0; u < o.length; u++) {
      const f = o[u];
      n[f] = fa(
        i,
        l,
        f,
        c[f],
        e,
        !fe(c, f)
      );
    }
  }
  return a;
}
function fa(e, t, n, r, i, o) {
  const a = e[n];
  if (a != null) {
    const s = fe(a, "default");
    if (s && r === void 0) {
      const l = a.default;
      if (a.type !== Function && !a.skipFactory && ae(l)) {
        const { propsDefaults: c } = i;
        n in c ? r = c[n] : (Yn(i), r = c[n] = l.call(
          null,
          t
        ), En());
      } else
        r = l;
    }
    a[
      0
      /* shouldCast */
    ] && (o && !s ? r = !1 : a[
      1
      /* shouldCastTrue */
    ] && (r === "" || r === tr(n)) && (r = !0));
  }
  return r;
}
function au(e, t, n = !1) {
  const r = t.propsCache, i = r.get(e);
  if (i)
    return i;
  const o = e.props, a = {}, s = [];
  let l = !1;
  if (!ae(e)) {
    const u = (f) => {
      l = !0;
      const [d, m] = au(f, t, !0);
      je(a, d), m && s.push(...m);
    };
    !n && t.mixins.length && t.mixins.forEach(u), e.extends && u(e.extends), e.mixins && e.mixins.forEach(u);
  }
  if (!o && !l)
    return ke(e) && r.set(e, Fn), Fn;
  if (Q(o))
    for (let u = 0; u < o.length; u++) {
      const f = Mt(o[u]);
      el(f) && (a[f] = Ae);
    }
  else if (o)
    for (const u in o) {
      const f = Mt(u);
      if (el(f)) {
        const d = o[u], m = a[f] = Q(d) || ae(d) ? { type: d } : je({}, d);
        if (m) {
          const p = rl(Boolean, m.type), h = rl(String, m.type);
          m[
            0
            /* shouldCast */
          ] = p > -1, m[
            1
            /* shouldCastTrue */
          ] = h < 0 || p < h, (p > -1 || fe(m, "default")) && s.push(f);
        }
      }
    }
  const c = [a, s];
  return ke(e) && r.set(e, c), c;
}
function el(e) {
  return e[0] !== "$";
}
function tl(e) {
  const t = e && e.toString().match(/^\s*(function|class) (\w+)/);
  return t ? t[2] : e === null ? "null" : "";
}
function nl(e, t) {
  return tl(e) === tl(t);
}
function rl(e, t) {
  return Q(t) ? t.findIndex((n) => nl(n, e)) : ae(t) && nl(t, e) ? 0 : -1;
}
const su = (e) => e[0] === "_" || e === "$stable", rs = (e) => Q(e) ? e.map(It) : [It(e)], jm = (e, t, n) => {
  if (t._n)
    return t;
  const r = ne((...i) => rs(t(...i)), n);
  return r._c = !1, r;
}, lu = (e, t, n) => {
  const r = e._ctx;
  for (const i in e) {
    if (su(i))
      continue;
    const o = e[i];
    if (ae(o))
      t[i] = jm(i, o, r);
    else if (o != null) {
      const a = rs(o);
      t[i] = () => a;
    }
  }
}, cu = (e, t) => {
  const n = rs(t);
  e.slots.default = () => n;
}, Um = (e, t) => {
  if (e.vnode.shapeFlag & 32) {
    const n = t._;
    n ? (e.slots = se(t), Di(t, "_", n)) : lu(
      t,
      e.slots = {}
    );
  } else
    e.slots = {}, t && cu(e, t);
  Di(e.slots, mo, 1);
}, Hm = (e, t, n) => {
  const { vnode: r, slots: i } = e;
  let o = !0, a = Ae;
  if (r.shapeFlag & 32) {
    const s = t._;
    s ? n && s === 1 ? o = !1 : (je(i, t), !n && s === 1 && delete i._) : (o = !t.$stable, lu(t, i)), a = t;
  } else
    t && (cu(e, t), a = { default: 1 });
  if (o)
    for (const s in i)
      !su(s) && !(s in a) && delete i[s];
};
function ma(e, t, n, r, i = !1) {
  if (Q(e)) {
    e.forEach(
      (d, m) => ma(
        d,
        t && (Q(t) ? t[m] : t),
        n,
        r,
        i
      )
    );
    return;
  }
  if (xr(r) && !i)
    return;
  const o = r.shapeFlag & 4 ? po(r.component) || r.component.proxy : r.el, a = i ? null : o, { i: s, r: l } = e, c = t && t.r, u = s.refs === Ae ? s.refs = {} : s.refs, f = s.setupState;
  if (c != null && c !== l && (Le(c) ? (u[c] = null, fe(f, c) && (f[c] = null)) : Je(c) && (c.value = null)), ae(l))
    tn(l, s, 12, [a, u]);
  else {
    const d = Le(l), m = Je(l);
    if (d || m) {
      const p = () => {
        if (e.f) {
          const h = d ? fe(f, l) ? f[l] : u[l] : l.value;
          i ? Q(h) && ja(h, o) : Q(h) ? h.includes(o) || h.push(o) : d ? (u[l] = [o], fe(f, l) && (f[l] = u[l])) : (l.value = [o], e.k && (u[e.k] = l.value));
        } else
          d ? (u[l] = a, fe(f, l) && (f[l] = a)) : m && (l.value = a, e.k && (u[e.k] = a));
      };
      a ? (p.id = -1, ot(p, n)) : p();
    }
  }
}
const ot = bm;
function Bm(e) {
  return Gm(e);
}
function Gm(e, t) {
  const n = ea();
  n.__VUE__ = !0;
  const {
    insert: r,
    remove: i,
    patchProp: o,
    createElement: a,
    createText: s,
    createComment: l,
    setText: c,
    setElementText: u,
    parentNode: f,
    nextSibling: d,
    setScopeId: m = kt,
    insertStaticContent: p
  } = e, h = (b, v, E, O = null, S = null, z = null, j = !1, P = null, L = !!v.dynamicChildren) => {
    if (b === v)
      return;
    b && !bn(b, v) && (O = ii(b), Me(b, S, z, !0), b = null), v.patchFlag === -2 && (L = !1, v.dynamicChildren = null);
    const { type: N, ref: Z, shapeFlag: q } = v;
    switch (N) {
      case fo:
        _(b, v, E, O);
        break;
      case ht:
        y(b, v, E, O);
        break;
      case Vo:
        b == null && g(v, E, O, j);
        break;
      case De:
        A(
          b,
          v,
          E,
          O,
          S,
          z,
          j,
          P,
          L
        );
        break;
      default:
        q & 1 ? I(
          b,
          v,
          E,
          O,
          S,
          z,
          j,
          P,
          L
        ) : q & 6 ? X(
          b,
          v,
          E,
          O,
          S,
          z,
          j,
          P,
          L
        ) : (q & 64 || q & 128) && N.process(
          b,
          v,
          E,
          O,
          S,
          z,
          j,
          P,
          L,
          In
        );
    }
    Z != null && S && ma(Z, b && b.ref, z, v || b, !v);
  }, _ = (b, v, E, O) => {
    if (b == null)
      r(
        v.el = s(v.children),
        E,
        O
      );
    else {
      const S = v.el = b.el;
      v.children !== b.children && c(S, v.children);
    }
  }, y = (b, v, E, O) => {
    b == null ? r(
      v.el = l(v.children || ""),
      E,
      O
    ) : v.el = b.el;
  }, g = (b, v, E, O) => {
    [b.el, b.anchor] = p(
      b.children,
      v,
      E,
      O,
      b.el,
      b.anchor
    );
  }, w = ({ el: b, anchor: v }, E, O) => {
    let S;
    for (; b && b !== v; )
      S = d(b), r(b, E, O), b = S;
    r(v, E, O);
  }, x = ({ el: b, anchor: v }) => {
    let E;
    for (; b && b !== v; )
      E = d(b), i(b), b = E;
    i(v);
  }, I = (b, v, E, O, S, z, j, P, L) => {
    j = j || v.type === "svg", b == null ? U(
      v,
      E,
      O,
      S,
      z,
      j,
      P,
      L
    ) : R(
      b,
      v,
      S,
      z,
      j,
      P,
      L
    );
  }, U = (b, v, E, O, S, z, j, P) => {
    let L, N;
    const { type: Z, props: q, shapeFlag: ee, transition: oe, dirs: le } = b;
    if (L = b.el = a(
      b.type,
      z,
      q && q.is,
      q
    ), ee & 8 ? u(L, b.children) : ee & 16 && C(
      b.children,
      L,
      null,
      O,
      S,
      z && Z !== "foreignObject",
      j,
      P
    ), le && cn(b, null, O, "created"), M(L, b, b.scopeId, j, O), q) {
      for (const we in q)
        we !== "value" && !Ai(we) && o(
          L,
          we,
          null,
          q[we],
          z,
          b.children,
          O,
          S,
          Rt
        );
      "value" in q && o(L, "value", null, q.value), (N = q.onVnodeBeforeMount) && At(N, O, b);
    }
    le && cn(b, null, O, "beforeMount");
    const Se = (!S || S && !S.pendingBranch) && oe && !oe.persisted;
    Se && oe.beforeEnter(L), r(L, v, E), ((N = q && q.onVnodeMounted) || Se || le) && ot(() => {
      N && At(N, O, b), Se && oe.enter(L), le && cn(b, null, O, "mounted");
    }, S);
  }, M = (b, v, E, O, S) => {
    if (E && m(b, E), O)
      for (let z = 0; z < O.length; z++)
        m(b, O[z]);
    if (S) {
      let z = S.subTree;
      if (v === z) {
        const j = S.vnode;
        M(
          b,
          j,
          j.scopeId,
          j.slotScopeIds,
          S.parent
        );
      }
    }
  }, C = (b, v, E, O, S, z, j, P, L = 0) => {
    for (let N = L; N < b.length; N++) {
      const Z = b[N] = P ? Xt(b[N]) : It(b[N]);
      h(
        null,
        Z,
        v,
        E,
        O,
        S,
        z,
        j,
        P
      );
    }
  }, R = (b, v, E, O, S, z, j) => {
    const P = v.el = b.el;
    let { patchFlag: L, dynamicChildren: N, dirs: Z } = v;
    L |= b.patchFlag & 16;
    const q = b.props || Ae, ee = v.props || Ae;
    let oe;
    E && un(E, !1), (oe = ee.onVnodeBeforeUpdate) && At(oe, E, v, b), Z && cn(v, b, E, "beforeUpdate"), E && un(E, !0);
    const le = S && v.type !== "foreignObject";
    if (N ? W(
      b.dynamicChildren,
      N,
      P,
      E,
      O,
      le,
      z
    ) : j || G(
      b,
      v,
      P,
      null,
      E,
      O,
      le,
      z,
      !1
    ), L > 0) {
      if (L & 16)
        F(
          P,
          v,
          q,
          ee,
          E,
          O,
          S
        );
      else if (L & 2 && q.class !== ee.class && o(P, "class", null, ee.class, S), L & 4 && o(P, "style", q.style, ee.style, S), L & 8) {
        const Se = v.dynamicProps;
        for (let we = 0; we < Se.length; we++) {
          const Fe = Se[we], gt = q[Fe], Cn = ee[Fe];
          (Cn !== gt || Fe === "value") && o(
            P,
            Fe,
            gt,
            Cn,
            S,
            b.children,
            E,
            O,
            Rt
          );
        }
      }
      L & 1 && b.children !== v.children && u(P, v.children);
    } else
      !j && N == null && F(
        P,
        v,
        q,
        ee,
        E,
        O,
        S
      );
    ((oe = ee.onVnodeUpdated) || Z) && ot(() => {
      oe && At(oe, E, v, b), Z && cn(v, b, E, "updated");
    }, O);
  }, W = (b, v, E, O, S, z, j) => {
    for (let P = 0; P < v.length; P++) {
      const L = b[P], N = v[P], Z = (
        // oldVNode may be an errored async setup() component inside Suspense
        // which will not have a mounted element
        L.el && // - In the case of a Fragment, we need to provide the actual parent
        // of the Fragment itself so it can move its children.
        (L.type === De || // - In the case of different nodes, there is going to be a replacement
        // which also requires the correct parent container
        !bn(L, N) || // - In the case of a component, it could contain anything.
        L.shapeFlag & 70) ? f(L.el) : (
          // In other cases, the parent container is not actually used so we
          // just pass the block element here to avoid a DOM parentNode call.
          E
        )
      );
      h(
        L,
        N,
        Z,
        null,
        O,
        S,
        z,
        j,
        !0
      );
    }
  }, F = (b, v, E, O, S, z, j) => {
    if (E !== O) {
      if (E !== Ae)
        for (const P in E)
          !Ai(P) && !(P in O) && o(
            b,
            P,
            E[P],
            null,
            j,
            v.children,
            S,
            z,
            Rt
          );
      for (const P in O) {
        if (Ai(P))
          continue;
        const L = O[P], N = E[P];
        L !== N && P !== "value" && o(
          b,
          P,
          N,
          L,
          j,
          v.children,
          S,
          z,
          Rt
        );
      }
      "value" in O && o(b, "value", E.value, O.value);
    }
  }, A = (b, v, E, O, S, z, j, P, L) => {
    const N = v.el = b ? b.el : s(""), Z = v.anchor = b ? b.anchor : s("");
    let { patchFlag: q, dynamicChildren: ee, slotScopeIds: oe } = v;
    oe && (P = P ? P.concat(oe) : oe), b == null ? (r(N, E, O), r(Z, E, O), C(
      v.children,
      E,
      Z,
      S,
      z,
      j,
      P,
      L
    )) : q > 0 && q & 64 && ee && // #2715 the previous fragment could've been a BAILed one as a result
    // of renderSlot() with no valid children
    b.dynamicChildren ? (W(
      b.dynamicChildren,
      ee,
      E,
      S,
      z,
      j,
      P
    ), // #2080 if the stable fragment has a key, it's a <template v-for> that may
    //  get moved around. Make sure all root level vnodes inherit el.
    // #2134 or if it's a component root, it may also get moved around
    // as the component is being moved.
    (v.key != null || S && v === S.subTree) && is(
      b,
      v,
      !0
      /* shallow */
    )) : G(
      b,
      v,
      E,
      Z,
      S,
      z,
      j,
      P,
      L
    );
  }, X = (b, v, E, O, S, z, j, P, L) => {
    v.slotScopeIds = P, b == null ? v.shapeFlag & 512 ? S.ctx.activate(
      v,
      E,
      O,
      j,
      L
    ) : ce(
      v,
      E,
      O,
      S,
      z,
      j,
      L
    ) : Ce(b, v, L);
  }, ce = (b, v, E, O, S, z, j) => {
    const P = b.component = np(
      b,
      O,
      S
    );
    if (co(b) && (P.ctx.renderer = In), ip(P), P.asyncDep) {
      if (S && S.registerDep(P, J), !b.el) {
        const L = P.subTree = H(ht);
        y(null, L, v, E);
      }
      return;
    }
    J(
      P,
      b,
      v,
      E,
      S,
      z,
      j
    );
  }, Ce = (b, v, E) => {
    const O = v.component = b.component;
    if (fm(b, v, E))
      if (O.asyncDep && !O.asyncResolved) {
        V(O, v, E);
        return;
      } else
        O.next = v, am(O.update), O.update();
    else
      v.el = b.el, O.vnode = v;
  }, J = (b, v, E, O, S, z, j) => {
    const P = () => {
      if (b.isMounted) {
        let { next: Z, bu: q, u: ee, parent: oe, vnode: le } = b, Se = Z, we;
        un(b, !1), Z ? (Z.el = le.el, V(b, Z, j)) : Z = le, q && Ni(q), (we = Z.props && Z.props.onVnodeBeforeUpdate) && At(we, oe, Z, le), un(b, !0);
        const Fe = Lo(b), gt = b.subTree;
        b.subTree = Fe, h(
          gt,
          Fe,
          // parent may have changed if it's in a teleport
          f(gt.el),
          // anchor may have changed if it's in a fragment
          ii(gt),
          b,
          S,
          z
        ), Z.el = Fe.el, Se === null && mm(b, Fe.el), ee && ot(ee, S), (we = Z.props && Z.props.onVnodeUpdated) && ot(
          () => At(we, oe, Z, le),
          S
        );
      } else {
        let Z;
        const { el: q, props: ee } = v, { bm: oe, m: le, parent: Se } = b, we = xr(v);
        if (un(b, !1), oe && Ni(oe), !we && (Z = ee && ee.onVnodeBeforeMount) && At(Z, Se, v), un(b, !0), q && Do) {
          const Fe = () => {
            b.subTree = Lo(b), Do(
              q,
              b.subTree,
              b,
              S,
              null
            );
          };
          we ? v.type.__asyncLoader().then(
            // note: we are moving the render call into an async callback,
            // which means it won't track dependencies - but it's ok because
            // a server-rendered async wrapper is already in resolved state
            // and it will never need to change.
            () => !b.isUnmounted && Fe()
          ) : Fe();
        } else {
          const Fe = b.subTree = Lo(b);
          h(
            null,
            Fe,
            E,
            O,
            b,
            S,
            z
          ), v.el = Fe.el;
        }
        if (le && ot(le, S), !we && (Z = ee && ee.onVnodeMounted)) {
          const Fe = v;
          ot(
            () => At(Z, Se, Fe),
            S
          );
        }
        (v.shapeFlag & 256 || Se && xr(Se.vnode) && Se.vnode.shapeFlag & 256) && b.a && ot(b.a, S), b.isMounted = !0, v = E = O = null;
      }
    }, L = b.effect = new Ga(
      P,
      () => Za(N),
      b.scope
      // track it in component's effect scope
    ), N = b.update = () => L.run();
    N.id = b.uid, un(b, !0), N();
  }, V = (b, v, E) => {
    v.component = b;
    const O = b.vnode.props;
    b.vnode = v, b.next = null, Vm(b, v.props, O, E), Hm(b, v.children, E), nr(), Ys(), rr();
  }, G = (b, v, E, O, S, z, j, P, L = !1) => {
    const N = b && b.children, Z = b ? b.shapeFlag : 0, q = v.children, { patchFlag: ee, shapeFlag: oe } = v;
    if (ee > 0) {
      if (ee & 128) {
        Ue(
          N,
          q,
          E,
          O,
          S,
          z,
          j,
          P,
          L
        );
        return;
      } else if (ee & 256) {
        me(
          N,
          q,
          E,
          O,
          S,
          z,
          j,
          P,
          L
        );
        return;
      }
    }
    oe & 8 ? (Z & 16 && Rt(N, S, z), q !== N && u(E, q)) : Z & 16 ? oe & 16 ? Ue(
      N,
      q,
      E,
      O,
      S,
      z,
      j,
      P,
      L
    ) : Rt(N, S, z, !0) : (Z & 8 && u(E, ""), oe & 16 && C(
      q,
      E,
      O,
      S,
      z,
      j,
      P,
      L
    ));
  }, me = (b, v, E, O, S, z, j, P, L) => {
    b = b || Fn, v = v || Fn;
    const N = b.length, Z = v.length, q = Math.min(N, Z);
    let ee;
    for (ee = 0; ee < q; ee++) {
      const oe = v[ee] = L ? Xt(v[ee]) : It(v[ee]);
      h(
        b[ee],
        oe,
        E,
        null,
        S,
        z,
        j,
        P,
        L
      );
    }
    N > Z ? Rt(
      b,
      S,
      z,
      !0,
      !1,
      q
    ) : C(
      v,
      E,
      O,
      S,
      z,
      j,
      P,
      L,
      q
    );
  }, Ue = (b, v, E, O, S, z, j, P, L) => {
    let N = 0;
    const Z = v.length;
    let q = b.length - 1, ee = Z - 1;
    for (; N <= q && N <= ee; ) {
      const oe = b[N], le = v[N] = L ? Xt(v[N]) : It(v[N]);
      if (bn(oe, le))
        h(
          oe,
          le,
          E,
          null,
          S,
          z,
          j,
          P,
          L
        );
      else
        break;
      N++;
    }
    for (; N <= q && N <= ee; ) {
      const oe = b[q], le = v[ee] = L ? Xt(v[ee]) : It(v[ee]);
      if (bn(oe, le))
        h(
          oe,
          le,
          E,
          null,
          S,
          z,
          j,
          P,
          L
        );
      else
        break;
      q--, ee--;
    }
    if (N > q) {
      if (N <= ee) {
        const oe = ee + 1, le = oe < Z ? v[oe].el : O;
        for (; N <= ee; )
          h(
            null,
            v[N] = L ? Xt(v[N]) : It(v[N]),
            E,
            le,
            S,
            z,
            j,
            P,
            L
          ), N++;
      }
    } else if (N > ee)
      for (; N <= q; )
        Me(b[N], S, z, !0), N++;
    else {
      const oe = N, le = N, Se = /* @__PURE__ */ new Map();
      for (N = le; N <= ee; N++) {
        const lt = v[N] = L ? Xt(v[N]) : It(v[N]);
        lt.key != null && Se.set(lt.key, N);
      }
      let we, Fe = 0;
      const gt = ee - le + 1;
      let Cn = !1, Rs = 0;
      const cr = new Array(gt);
      for (N = 0; N < gt; N++)
        cr[N] = 0;
      for (N = oe; N <= q; N++) {
        const lt = b[N];
        if (Fe >= gt) {
          Me(lt, S, z, !0);
          continue;
        }
        let Ot;
        if (lt.key != null)
          Ot = Se.get(lt.key);
        else
          for (we = le; we <= ee; we++)
            if (cr[we - le] === 0 && bn(lt, v[we])) {
              Ot = we;
              break;
            }
        Ot === void 0 ? Me(lt, S, z, !0) : (cr[Ot - le] = N + 1, Ot >= Rs ? Rs = Ot : Cn = !0, h(
          lt,
          v[Ot],
          E,
          null,
          S,
          z,
          j,
          P,
          L
        ), Fe++);
      }
      const Ds = Cn ? Ym(cr) : Fn;
      for (we = Ds.length - 1, N = gt - 1; N >= 0; N--) {
        const lt = le + N, Ot = v[lt], zs = lt + 1 < Z ? v[lt + 1].el : O;
        cr[N] === 0 ? h(
          null,
          Ot,
          E,
          zs,
          S,
          z,
          j,
          P,
          L
        ) : Cn && (we < 0 || N !== Ds[we] ? Te(Ot, E, zs, 2) : we--);
      }
    }
  }, Te = (b, v, E, O, S = null) => {
    const { el: z, type: j, transition: P, children: L, shapeFlag: N } = b;
    if (N & 6) {
      Te(b.component.subTree, v, E, O);
      return;
    }
    if (N & 128) {
      b.suspense.move(v, E, O);
      return;
    }
    if (N & 64) {
      j.move(b, v, E, In);
      return;
    }
    if (j === De) {
      r(z, v, E);
      for (let q = 0; q < L.length; q++)
        Te(L[q], v, E, O);
      r(b.anchor, v, E);
      return;
    }
    if (j === Vo) {
      w(b, v, E);
      return;
    }
    if (O !== 2 && N & 1 && P)
      if (O === 0)
        P.beforeEnter(z), r(z, v, E), ot(() => P.enter(z), S);
      else {
        const { leave: q, delayLeave: ee, afterLeave: oe } = P, le = () => r(z, v, E), Se = () => {
          q(z, () => {
            le(), oe && oe();
          });
        };
        ee ? ee(z, le, Se) : Se();
      }
    else
      r(z, v, E);
  }, Me = (b, v, E, O = !1, S = !1) => {
    const {
      type: z,
      props: j,
      ref: P,
      children: L,
      dynamicChildren: N,
      shapeFlag: Z,
      patchFlag: q,
      dirs: ee
    } = b;
    if (P != null && ma(P, null, E, b, !0), Z & 256) {
      v.ctx.deactivate(b);
      return;
    }
    const oe = Z & 1 && ee, le = !xr(b);
    let Se;
    if (le && (Se = j && j.onVnodeBeforeUnmount) && At(Se, v, b), Z & 6)
      Gt(b.component, E, O);
    else {
      if (Z & 128) {
        b.suspense.unmount(E, O);
        return;
      }
      oe && cn(b, null, v, "beforeUnmount"), Z & 64 ? b.type.remove(
        b,
        v,
        E,
        S,
        In,
        O
      ) : N && // #1153: fast path should not be taken for non-stable (v-for) fragments
      (z !== De || q > 0 && q & 64) ? Rt(
        N,
        v,
        E,
        !1,
        !0
      ) : (z === De && q & 384 || !S && Z & 16) && Rt(L, v, E), O && Nn(b);
    }
    (le && (Se = j && j.onVnodeUnmounted) || oe) && ot(() => {
      Se && At(Se, v, b), oe && cn(b, null, v, "unmounted");
    }, E);
  }, Nn = (b) => {
    const { type: v, el: E, anchor: O, transition: S } = b;
    if (v === De) {
      tt(E, O);
      return;
    }
    if (v === Vo) {
      x(b);
      return;
    }
    const z = () => {
      i(E), S && !S.persisted && S.afterLeave && S.afterLeave();
    };
    if (b.shapeFlag & 1 && S && !S.persisted) {
      const { leave: j, delayLeave: P } = S, L = () => j(E, z);
      P ? P(b.el, z, L) : L();
    } else
      z();
  }, tt = (b, v) => {
    let E;
    for (; b !== v; )
      E = d(b), i(b), b = E;
    i(v);
  }, Gt = (b, v, E) => {
    const { bum: O, scope: S, update: z, subTree: j, um: P } = b;
    O && Ni(O), S.stop(), z && (z.active = !1, Me(j, b, v, E)), P && ot(P, v), ot(() => {
      b.isUnmounted = !0;
    }, v), v && v.pendingBranch && !v.isUnmounted && b.asyncDep && !b.asyncResolved && b.suspenseId === v.pendingId && (v.deps--, v.deps === 0 && v.resolve());
  }, Rt = (b, v, E, O = !1, S = !1, z = 0) => {
    for (let j = z; j < b.length; j++)
      Me(b[j], v, E, O, S);
  }, ii = (b) => b.shapeFlag & 6 ? ii(b.component.subTree) : b.shapeFlag & 128 ? b.suspense.next() : d(b.anchor || b.el), Ms = (b, v, E) => {
    b == null ? v._vnode && Me(v._vnode, null, null, !0) : h(v._vnode || null, b, v, null, null, null, E), Ys(), Bc(), v._vnode = b;
  }, In = {
    p: h,
    um: Me,
    m: Te,
    r: Nn,
    mt: ce,
    mc: C,
    pc: G,
    pbc: W,
    n: ii,
    o: e
  };
  let Ro, Do;
  return t && ([Ro, Do] = t(
    In
  )), {
    render: Ms,
    hydrate: Ro,
    createApp: $m(Ms, Ro)
  };
}
function un({ effect: e, update: t }, n) {
  e.allowRecurse = t.allowRecurse = n;
}
function is(e, t, n = !1) {
  const r = e.children, i = t.children;
  if (Q(r) && Q(i))
    for (let o = 0; o < r.length; o++) {
      const a = r[o];
      let s = i[o];
      s.shapeFlag & 1 && !s.dynamicChildren && ((s.patchFlag <= 0 || s.patchFlag === 32) && (s = i[o] = Xt(i[o]), s.el = a.el), n || is(a, s)), s.type === fo && (s.el = a.el);
    }
}
function Ym(e) {
  const t = e.slice(), n = [0];
  let r, i, o, a, s;
  const l = e.length;
  for (r = 0; r < l; r++) {
    const c = e[r];
    if (c !== 0) {
      if (i = n[n.length - 1], e[i] < c) {
        t[r] = i, n.push(r);
        continue;
      }
      for (o = 0, a = n.length - 1; o < a; )
        s = o + a >> 1, e[n[s]] < c ? o = s + 1 : a = s;
      c < e[n[o]] && (o > 0 && (t[r] = n[o - 1]), n[o] = r);
    }
  }
  for (o = n.length, a = n[o - 1]; o-- > 0; )
    n[o] = a, a = t[a];
  return n;
}
const Wm = (e) => e.__isTeleport, kr = (e) => e && (e.disabled || e.disabled === ""), il = (e) => typeof SVGElement < "u" && e instanceof SVGElement, pa = (e, t) => {
  const n = e && e.to;
  return Le(n) ? t ? t(n) : null : n;
}, qm = {
  __isTeleport: !0,
  process(e, t, n, r, i, o, a, s, l, c) {
    const {
      mc: u,
      pc: f,
      pbc: d,
      o: { insert: m, querySelector: p, createText: h, createComment: _ }
    } = c, y = kr(t.props);
    let { shapeFlag: g, children: w, dynamicChildren: x } = t;
    if (e == null) {
      const I = t.el = h(""), U = t.anchor = h("");
      m(I, n, r), m(U, n, r);
      const M = t.target = pa(t.props, p), C = t.targetAnchor = h("");
      M && (m(C, M), a = a || il(M));
      const R = (W, F) => {
        g & 16 && u(
          w,
          W,
          F,
          i,
          o,
          a,
          s,
          l
        );
      };
      y ? R(n, U) : M && R(M, C);
    } else {
      t.el = e.el;
      const I = t.anchor = e.anchor, U = t.target = e.target, M = t.targetAnchor = e.targetAnchor, C = kr(e.props), R = C ? n : U, W = C ? I : M;
      if (a = a || il(U), x ? (d(
        e.dynamicChildren,
        x,
        R,
        i,
        o,
        a,
        s
      ), is(e, t, !0)) : l || f(
        e,
        t,
        R,
        W,
        i,
        o,
        a,
        s,
        !1
      ), y)
        C || di(
          t,
          n,
          I,
          c,
          1
        );
      else if ((t.props && t.props.to) !== (e.props && e.props.to)) {
        const F = t.target = pa(
          t.props,
          p
        );
        F && di(
          t,
          F,
          null,
          c,
          0
        );
      } else
        C && di(
          t,
          U,
          M,
          c,
          1
        );
    }
    uu(t);
  },
  remove(e, t, n, r, { um: i, o: { remove: o } }, a) {
    const { shapeFlag: s, children: l, anchor: c, targetAnchor: u, target: f, props: d } = e;
    if (f && o(u), (a || !kr(d)) && (o(c), s & 16))
      for (let m = 0; m < l.length; m++) {
        const p = l[m];
        i(
          p,
          t,
          n,
          !0,
          !!p.dynamicChildren
        );
      }
  },
  move: di,
  hydrate: Km
};
function di(e, t, n, { o: { insert: r }, m: i }, o = 2) {
  o === 0 && r(e.targetAnchor, t, n);
  const { el: a, anchor: s, shapeFlag: l, children: c, props: u } = e, f = o === 2;
  if (f && r(a, t, n), (!f || kr(u)) && l & 16)
    for (let d = 0; d < c.length; d++)
      i(
        c[d],
        t,
        n,
        2
      );
  f && r(s, t, n);
}
function Km(e, t, n, r, i, o, {
  o: { nextSibling: a, parentNode: s, querySelector: l }
}, c) {
  const u = t.target = pa(
    t.props,
    l
  );
  if (u) {
    const f = u._lpa || u.firstChild;
    if (t.shapeFlag & 16)
      if (kr(t.props))
        t.anchor = c(
          a(e),
          t,
          s(e),
          n,
          r,
          i,
          o
        ), t.targetAnchor = f;
      else {
        t.anchor = a(e);
        let d = f;
        for (; d; )
          if (d = a(d), d && d.nodeType === 8 && d.data === "teleport anchor") {
            t.targetAnchor = d, u._lpa = t.targetAnchor && a(t.targetAnchor);
            break;
          }
        c(
          f,
          t,
          u,
          n,
          r,
          i,
          o
        );
      }
    uu(t);
  }
  return t.anchor && a(t.anchor);
}
const Xm = qm;
function uu(e) {
  const t = e.ctx;
  if (t && t.ut) {
    let n = e.children[0].el;
    for (; n !== e.targetAnchor; )
      n.nodeType === 1 && n.setAttribute("data-v-owner", t.uid), n = n.nextSibling;
    t.ut();
  }
}
const De = Symbol.for("v-fgt"), fo = Symbol.for("v-txt"), ht = Symbol.for("v-cmt"), Vo = Symbol.for("v-stc"), Sr = [];
let xt = null;
function D(e = !1) {
  Sr.push(xt = e ? null : []);
}
function Jm() {
  Sr.pop(), xt = Sr[Sr.length - 1] || null;
}
let Lr = 1;
function ol(e) {
  Lr += e;
}
function du(e) {
  return e.dynamicChildren = Lr > 0 ? xt || Fn : null, Jm(), Lr > 0 && xt && xt.push(e), e;
}
function Y(e, t, n, r, i, o) {
  return du(
    k(
      e,
      t,
      n,
      r,
      i,
      o,
      !0
      /* isBlock */
    )
  );
}
function $e(e, t, n, r, i) {
  return du(
    H(
      e,
      t,
      n,
      r,
      i,
      !0
      /* isBlock: prevent a block from tracking itself */
    )
  );
}
function Hi(e) {
  return e ? e.__v_isVNode === !0 : !1;
}
function bn(e, t) {
  return e.type === t.type && e.key === t.key;
}
const mo = "__vInternal", fu = ({ key: e }) => e ?? null, Ii = ({
  ref: e,
  ref_key: t,
  ref_for: n
}) => (typeof e == "number" && (e = "" + e), e != null ? Le(e) || Je(e) || ae(e) ? { i: Qe, r: e, k: t, f: !!n } : e : null);
function k(e, t = null, n = null, r = 0, i = null, o = e === De ? 0 : 1, a = !1, s = !1) {
  const l = {
    __v_isVNode: !0,
    __v_skip: !0,
    type: e,
    props: t,
    key: t && fu(t),
    ref: t && Ii(t),
    scopeId: Wc,
    slotScopeIds: null,
    children: n,
    component: null,
    suspense: null,
    ssContent: null,
    ssFallback: null,
    dirs: null,
    transition: null,
    el: null,
    anchor: null,
    target: null,
    targetAnchor: null,
    staticCount: 0,
    shapeFlag: o,
    patchFlag: r,
    dynamicProps: i,
    dynamicChildren: null,
    appContext: null,
    ctx: Qe
  };
  return s ? (os(l, n), o & 128 && e.normalize(l)) : n && (l.shapeFlag |= Le(n) ? 8 : 16), Lr > 0 && // avoid a block node from tracking itself
  !a && // has current parent block
  xt && // presence of a patch flag indicates this node needs patching on updates.
  // component nodes also should always be patched, because even if the
  // component doesn't need to update, it needs to persist the instance on to
  // the next vnode so that it can be properly unmounted later.
  (l.patchFlag > 0 || o & 6) && // the EVENTS flag is only for hydration and if it is the only flag, the
  // vnode should not be considered dynamic due to handler caching.
  l.patchFlag !== 32 && xt.push(l), l;
}
const H = Qm;
function Qm(e, t = null, n = null, r = 0, i = null, o = !1) {
  if ((!e || e === eu) && (e = ht), Hi(e)) {
    const s = Ft(
      e,
      t,
      !0
      /* mergeRef: true */
    );
    return n && os(s, n), Lr > 0 && !o && xt && (s.shapeFlag & 6 ? xt[xt.indexOf(e)] = s : xt.push(s)), s.patchFlag |= -2, s;
  }
  if (cp(e) && (e = e.__vccOpts), t) {
    t = Zm(t);
    let { class: s, style: l } = t;
    s && !Le(s) && (t.class = _e(s)), ke(l) && (Dc(l) && !Q(l) && (l = je({}, l)), t.style = Kr(l));
  }
  const a = Le(e) ? 1 : pm(e) ? 128 : Wm(e) ? 64 : ke(e) ? 4 : ae(e) ? 2 : 0;
  return k(
    e,
    t,
    n,
    r,
    i,
    a,
    o,
    !0
  );
}
function Zm(e) {
  return e ? Dc(e) || mo in e ? je({}, e) : e : null;
}
function Ft(e, t, n = !1) {
  const { props: r, ref: i, patchFlag: o, children: a } = e, s = t ? Or(r || {}, t) : r;
  return {
    __v_isVNode: !0,
    __v_skip: !0,
    type: e.type,
    props: s,
    key: s && fu(s),
    ref: t && t.ref ? (
      // #2078 in the case of <component :is="vnode" ref="extra"/>
      // if the vnode itself already has a ref, cloneVNode will need to merge
      // the refs so the single vnode can be set on multiple refs
      n && i ? Q(i) ? i.concat(Ii(t)) : [i, Ii(t)] : Ii(t)
    ) : i,
    scopeId: e.scopeId,
    slotScopeIds: e.slotScopeIds,
    children: a,
    target: e.target,
    targetAnchor: e.targetAnchor,
    staticCount: e.staticCount,
    shapeFlag: e.shapeFlag,
    // if the vnode is cloned with extra props, we can no longer assume its
    // existing patch flag to be reliable and need to add the FULL_PROPS flag.
    // note: preserve flag for fragments since they use the flag for children
    // fast paths only.
    patchFlag: t && e.type !== De ? o === -1 ? 16 : o | 16 : o,
    dynamicProps: e.dynamicProps,
    dynamicChildren: e.dynamicChildren,
    appContext: e.appContext,
    dirs: e.dirs,
    transition: e.transition,
    // These should technically only be non-null on mounted VNodes. However,
    // they *should* be copied for kept-alive vnodes. So we just always copy
    // them since them being non-null during a mount doesn't affect the logic as
    // they will simply be overwritten.
    component: e.component,
    suspense: e.suspense,
    ssContent: e.ssContent && Ft(e.ssContent),
    ssFallback: e.ssFallback && Ft(e.ssFallback),
    el: e.el,
    anchor: e.anchor,
    ctx: e.ctx,
    ce: e.ce
  };
}
function ye(e = " ", t = 0) {
  return H(fo, null, e, t);
}
function xe(e = "", t = !1) {
  return t ? (D(), $e(ht, null, e)) : H(ht, null, e);
}
function It(e) {
  return e == null || typeof e == "boolean" ? H(ht) : Q(e) ? H(
    De,
    null,
    // #3666, avoid reference pollution when reusing vnode
    e.slice()
  ) : typeof e == "object" ? Xt(e) : H(fo, null, String(e));
}
function Xt(e) {
  return e.el === null && e.patchFlag !== -1 || e.memo ? e : Ft(e);
}
function os(e, t) {
  let n = 0;
  const { shapeFlag: r } = e;
  if (t == null)
    t = null;
  else if (Q(t))
    n = 16;
  else if (typeof t == "object")
    if (r & 65) {
      const i = t.default;
      i && (i._c && (i._d = !1), os(e, i()), i._c && (i._d = !0));
      return;
    } else {
      n = 32;
      const i = t._;
      !i && !(mo in t) ? t._ctx = Qe : i === 3 && Qe && (Qe.slots._ === 1 ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024));
    }
  else
    ae(t) ? (t = { default: t, _ctx: Qe }, n = 32) : (t = String(t), r & 64 ? (n = 16, t = [ye(t)]) : n = 8);
  e.children = t, e.shapeFlag |= n;
}
function Or(...e) {
  const t = {};
  for (let n = 0; n < e.length; n++) {
    const r = e[n];
    for (const i in r)
      if (i === "class")
        t.class !== r.class && (t.class = _e([t.class, r.class]));
      else if (i === "style")
        t.style = Kr([t.style, r.style]);
      else if (ro(i)) {
        const o = t[i], a = r[i];
        a && o !== a && !(Q(o) && o.includes(a)) && (t[i] = o ? [].concat(o, a) : a);
      } else
        i !== "" && (t[i] = r[i]);
  }
  return t;
}
function At(e, t, n, r = null) {
  pt(e, t, 7, [
    n,
    r
  ]);
}
const ep = iu();
let tp = 0;
function np(e, t, n) {
  const r = e.type, i = (t ? t.appContext : e.appContext) || ep, o = {
    uid: tp++,
    vnode: e,
    type: r,
    parent: t,
    appContext: i,
    root: null,
    // to be immediately set
    next: null,
    subTree: null,
    // will be set synchronously right after creation
    effect: null,
    update: null,
    // will be set synchronously right after creation
    scope: new kf(
      !0
      /* detached */
    ),
    render: null,
    proxy: null,
    exposed: null,
    exposeProxy: null,
    withProxy: null,
    provides: t ? t.provides : Object.create(i.provides),
    accessCache: null,
    renderCache: [],
    // local resolved assets
    components: null,
    directives: null,
    // resolved props and emits options
    propsOptions: au(r, i),
    emitsOptions: Yc(r, i),
    // emit
    emit: null,
    // to be set immediately
    emitted: null,
    // props default value
    propsDefaults: Ae,
    // inheritAttrs
    inheritAttrs: r.inheritAttrs,
    // state
    ctx: Ae,
    data: Ae,
    props: Ae,
    attrs: Ae,
    slots: Ae,
    refs: Ae,
    setupState: Ae,
    setupContext: null,
    attrsProxy: null,
    slotsProxy: null,
    // suspense related
    suspense: n,
    suspenseId: n ? n.pendingId : 0,
    asyncDep: null,
    asyncResolved: !1,
    // lifecycle hooks
    // not using enums here because it results in computed properties
    isMounted: !1,
    isUnmounted: !1,
    isDeactivated: !1,
    bc: null,
    c: null,
    bm: null,
    m: null,
    bu: null,
    u: null,
    um: null,
    bum: null,
    da: null,
    a: null,
    rtg: null,
    rtc: null,
    ec: null,
    sp: null
  };
  return o.ctx = { _: o }, o.root = t ? t.root : o, o.emit = cm.bind(null, o), e.ce && e.ce(o), o;
}
let Ye = null;
const rp = () => Ye || Qe;
let as, Tn, al = "__VUE_INSTANCE_SETTERS__";
(Tn = ea()[al]) || (Tn = ea()[al] = []), Tn.push((e) => Ye = e), as = (e) => {
  Tn.length > 1 ? Tn.forEach((t) => t(e)) : Tn[0](e);
};
const Yn = (e) => {
  as(e), e.scope.on();
}, En = () => {
  Ye && Ye.scope.off(), as(null);
};
function mu(e) {
  return e.vnode.shapeFlag & 4;
}
let $r = !1;
function ip(e, t = !1) {
  $r = t;
  const { props: n, children: r } = e.vnode, i = mu(e);
  Fm(e, n, i, t), Um(e, r);
  const o = i ? op(e, t) : void 0;
  return $r = !1, o;
}
function op(e, t) {
  const n = e.type;
  e.accessCache = /* @__PURE__ */ Object.create(null), e.proxy = zc(new Proxy(e.ctx, Tm));
  const { setup: r } = n;
  if (r) {
    const i = e.setupContext = r.length > 1 ? sp(e) : null;
    Yn(e), nr();
    const o = tn(
      r,
      e,
      0,
      [e.props, i]
    );
    if (rr(), En(), yc(o)) {
      if (o.then(En, En), t)
        return o.then((a) => {
          sl(e, a, t);
        }).catch((a) => {
          so(a, e, 0);
        });
      e.asyncDep = o;
    } else
      sl(e, o, t);
  } else
    pu(e, t);
}
function sl(e, t, n) {
  ae(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : ke(t) && (e.setupState = Vc(t)), pu(e, n);
}
let ll;
function pu(e, t, n) {
  const r = e.type;
  if (!e.render) {
    if (!t && ll && !r.render) {
      const i = r.template || ns(e).template;
      if (i) {
        const { isCustomElement: o, compilerOptions: a } = e.appContext.config, { delimiters: s, compilerOptions: l } = r, c = je(
          je(
            {
              isCustomElement: o,
              delimiters: s
            },
            a
          ),
          l
        );
        r.render = ll(i, c);
      }
    }
    e.render = r.render || kt;
  }
  Yn(e), nr(), Pm(e), rr(), En();
}
function ap(e) {
  return e.attrsProxy || (e.attrsProxy = new Proxy(
    e.attrs,
    {
      get(t, n) {
        return at(e, "get", "$attrs"), t[n];
      }
    }
  ));
}
function sp(e) {
  const t = (n) => {
    e.exposed = n || {};
  };
  return {
    get attrs() {
      return ap(e);
    },
    slots: e.slots,
    emit: e.emit,
    expose: t
  };
}
function po(e) {
  if (e.exposed)
    return e.exposeProxy || (e.exposeProxy = new Proxy(Vc(zc(e.exposed)), {
      get(t, n) {
        if (n in t)
          return t[n];
        if (n in Er)
          return Er[n](e);
      },
      has(t, n) {
        return n in t || n in Er;
      }
    }));
}
function lp(e, t = !0) {
  return ae(e) ? e.displayName || e.name : e.name || t && e.__name;
}
function cp(e) {
  return ae(e) && "__vccOpts" in e;
}
const $ = (e, t) => rm(e, t, $r);
function He(e, t, n) {
  const r = arguments.length;
  return r === 2 ? ke(t) && !Q(t) ? Hi(t) ? H(e, null, [t]) : H(e, t) : H(e, null, t) : (r > 3 ? n = Array.prototype.slice.call(arguments, 2) : r === 3 && Hi(n) && (n = [n]), H(e, t, n));
}
const up = Symbol.for("v-scx"), dp = () => Ve(up), fp = "3.3.4", mp = "http://www.w3.org/2000/svg", hn = typeof document < "u" ? document : null, cl = hn && /* @__PURE__ */ hn.createElement("template"), pp = {
  insert: (e, t, n) => {
    t.insertBefore(e, n || null);
  },
  remove: (e) => {
    const t = e.parentNode;
    t && t.removeChild(e);
  },
  createElement: (e, t, n, r) => {
    const i = t ? hn.createElementNS(mp, e) : hn.createElement(e, n ? { is: n } : void 0);
    return e === "select" && r && r.multiple != null && i.setAttribute("multiple", r.multiple), i;
  },
  createText: (e) => hn.createTextNode(e),
  createComment: (e) => hn.createComment(e),
  setText: (e, t) => {
    e.nodeValue = t;
  },
  setElementText: (e, t) => {
    e.textContent = t;
  },
  parentNode: (e) => e.parentNode,
  nextSibling: (e) => e.nextSibling,
  querySelector: (e) => hn.querySelector(e),
  setScopeId(e, t) {
    e.setAttribute(t, "");
  },
  // __UNSAFE__
  // Reason: innerHTML.
  // Static content here can only come from compiled templates.
  // As long as the user only uses trusted templates, this is safe.
  insertStaticContent(e, t, n, r, i, o) {
    const a = n ? n.previousSibling : t.lastChild;
    if (i && (i === o || i.nextSibling))
      for (; t.insertBefore(i.cloneNode(!0), n), !(i === o || !(i = i.nextSibling)); )
        ;
    else {
      cl.innerHTML = r ? `<svg>${e}</svg>` : e;
      const s = cl.content;
      if (r) {
        const l = s.firstChild;
        for (; l.firstChild; )
          s.appendChild(l.firstChild);
        s.removeChild(l);
      }
      t.insertBefore(s, n);
    }
    return [
      // first
      a ? a.nextSibling : t.firstChild,
      // last
      n ? n.previousSibling : t.lastChild
    ];
  }
};
function bp(e, t, n) {
  const r = e._vtc;
  r && (t = (t ? [t, ...r] : [...r]).join(" ")), t == null ? e.removeAttribute("class") : n ? e.setAttribute("class", t) : e.className = t;
}
function hp(e, t, n) {
  const r = e.style, i = Le(n);
  if (n && !i) {
    if (t && !Le(t))
      for (const o in t)
        n[o] == null && ba(r, o, "");
    for (const o in n)
      ba(r, o, n[o]);
  } else {
    const o = r.display;
    i ? t !== n && (r.cssText = n) : t && e.removeAttribute("style"), "_vod" in e && (r.display = o);
  }
}
const ul = /\s*!important$/;
function ba(e, t, n) {
  if (Q(n))
    n.forEach((r) => ba(e, t, r));
  else if (n == null && (n = ""), t.startsWith("--"))
    e.setProperty(t, n);
  else {
    const r = vp(e, t);
    ul.test(n) ? e.setProperty(
      tr(r),
      n.replace(ul, ""),
      "important"
    ) : e[r] = n;
  }
}
const dl = ["Webkit", "Moz", "ms"], jo = {};
function vp(e, t) {
  const n = jo[t];
  if (n)
    return n;
  let r = Mt(t);
  if (r !== "filter" && r in e)
    return jo[t] = r;
  r = oo(r);
  for (let i = 0; i < dl.length; i++) {
    const o = dl[i] + r;
    if (o in e)
      return jo[t] = o;
  }
  return t;
}
const fl = "http://www.w3.org/1999/xlink";
function gp(e, t, n, r, i) {
  if (r && t.startsWith("xlink:"))
    n == null ? e.removeAttributeNS(fl, t.slice(6, t.length)) : e.setAttributeNS(fl, t, n);
  else {
    const o = xf(t);
    n == null || o && !xc(n) ? e.removeAttribute(t) : e.setAttribute(t, o ? "" : n);
  }
}
function yp(e, t, n, r, i, o, a) {
  if (t === "innerHTML" || t === "textContent") {
    r && a(r, i, o), e[t] = n ?? "";
    return;
  }
  const s = e.tagName;
  if (t === "value" && s !== "PROGRESS" && // custom elements may use _value internally
  !s.includes("-")) {
    e._value = n;
    const c = s === "OPTION" ? e.getAttribute("value") : e.value, u = n ?? "";
    c !== u && (e.value = u), n == null && e.removeAttribute(t);
    return;
  }
  let l = !1;
  if (n === "" || n == null) {
    const c = typeof e[t];
    c === "boolean" ? n = xc(n) : n == null && c === "string" ? (n = "", l = !0) : c === "number" && (n = 0, l = !0);
  }
  try {
    e[t] = n;
  } catch {
  }
  l && e.removeAttribute(t);
}
function Jt(e, t, n, r) {
  e.addEventListener(t, n, r);
}
function _p(e, t, n, r) {
  e.removeEventListener(t, n, r);
}
function wp(e, t, n, r, i = null) {
  const o = e._vei || (e._vei = {}), a = o[t];
  if (r && a)
    a.value = r;
  else {
    const [s, l] = xp(t);
    if (r) {
      const c = o[t] = Sp(r, i);
      Jt(e, s, c, l);
    } else
      a && (_p(e, s, a, l), o[t] = void 0);
  }
}
const ml = /(?:Once|Passive|Capture)$/;
function xp(e) {
  let t;
  if (ml.test(e)) {
    t = {};
    let r;
    for (; r = e.match(ml); )
      e = e.slice(0, e.length - r[0].length), t[r[0].toLowerCase()] = !0;
  }
  return [e[2] === ":" ? e.slice(3) : tr(e.slice(2)), t];
}
let Uo = 0;
const Ep = /* @__PURE__ */ Promise.resolve(), kp = () => Uo || (Ep.then(() => Uo = 0), Uo = Date.now());
function Sp(e, t) {
  const n = (r) => {
    if (!r._vts)
      r._vts = Date.now();
    else if (r._vts <= n.attached)
      return;
    pt(
      Op(r, n.value),
      t,
      5,
      [r]
    );
  };
  return n.value = e, n.attached = kp(), n;
}
function Op(e, t) {
  if (Q(t)) {
    const n = e.stopImmediatePropagation;
    return e.stopImmediatePropagation = () => {
      n.call(e), e._stopped = !0;
    }, t.map((r) => (i) => !i._stopped && r && r(i));
  } else
    return t;
}
const pl = /^on[a-z]/, Ap = (e, t, n, r, i = !1, o, a, s, l) => {
  t === "class" ? bp(e, r, i) : t === "style" ? hp(e, n, r) : ro(t) ? Va(t) || wp(e, t, n, r, a) : (t[0] === "." ? (t = t.slice(1), !0) : t[0] === "^" ? (t = t.slice(1), !1) : Np(e, t, r, i)) ? yp(
    e,
    t,
    r,
    o,
    a,
    s,
    l
  ) : (t === "true-value" ? e._trueValue = r : t === "false-value" && (e._falseValue = r), gp(e, t, r, i));
};
function Np(e, t, n, r) {
  return r ? !!(t === "innerHTML" || t === "textContent" || t in e && pl.test(t) && ae(n)) : t === "spellcheck" || t === "draggable" || t === "translate" || t === "form" || t === "list" && e.tagName === "INPUT" || t === "type" && e.tagName === "TEXTAREA" || pl.test(t) && Le(n) ? !1 : t in e;
}
const Wt = "transition", ur = "animation", Wn = (e, { slots: t }) => He(ym, Ip(e), t);
Wn.displayName = "Transition";
const bu = {
  name: String,
  type: String,
  css: {
    type: Boolean,
    default: !0
  },
  duration: [String, Number, Object],
  enterFromClass: String,
  enterActiveClass: String,
  enterToClass: String,
  appearFromClass: String,
  appearActiveClass: String,
  appearToClass: String,
  leaveFromClass: String,
  leaveActiveClass: String,
  leaveToClass: String
};
Wn.props = /* @__PURE__ */ je(
  {},
  Kc,
  bu
);
const dn = (e, t = []) => {
  Q(e) ? e.forEach((n) => n(...t)) : e && e(...t);
}, bl = (e) => e ? Q(e) ? e.some((t) => t.length > 1) : e.length > 1 : !1;
function Ip(e) {
  const t = {};
  for (const A in e)
    A in bu || (t[A] = e[A]);
  if (e.css === !1)
    return t;
  const {
    name: n = "v",
    type: r,
    duration: i,
    enterFromClass: o = `${n}-enter-from`,
    enterActiveClass: a = `${n}-enter-active`,
    enterToClass: s = `${n}-enter-to`,
    appearFromClass: l = o,
    appearActiveClass: c = a,
    appearToClass: u = s,
    leaveFromClass: f = `${n}-leave-from`,
    leaveActiveClass: d = `${n}-leave-active`,
    leaveToClass: m = `${n}-leave-to`
  } = e, p = Cp(i), h = p && p[0], _ = p && p[1], {
    onBeforeEnter: y,
    onEnter: g,
    onEnterCancelled: w,
    onLeave: x,
    onLeaveCancelled: I,
    onBeforeAppear: U = y,
    onAppear: M = g,
    onAppearCancelled: C = w
  } = t, R = (A, X, ce) => {
    fn(A, X ? u : s), fn(A, X ? c : a), ce && ce();
  }, W = (A, X) => {
    A._isLeaving = !1, fn(A, f), fn(A, m), fn(A, d), X && X();
  }, F = (A) => (X, ce) => {
    const Ce = A ? M : g, J = () => R(X, A, ce);
    dn(Ce, [X, J]), hl(() => {
      fn(X, A ? l : o), qt(X, A ? u : s), bl(Ce) || vl(X, r, h, J);
    });
  };
  return je(t, {
    onBeforeEnter(A) {
      dn(y, [A]), qt(A, o), qt(A, a);
    },
    onBeforeAppear(A) {
      dn(U, [A]), qt(A, l), qt(A, c);
    },
    onEnter: F(!1),
    onAppear: F(!0),
    onLeave(A, X) {
      A._isLeaving = !0;
      const ce = () => W(A, X);
      qt(A, f), Mp(), qt(A, d), hl(() => {
        A._isLeaving && (fn(A, f), qt(A, m), bl(x) || vl(A, r, _, ce));
      }), dn(x, [A, ce]);
    },
    onEnterCancelled(A) {
      R(A, !1), dn(w, [A]);
    },
    onAppearCancelled(A) {
      R(A, !0), dn(C, [A]);
    },
    onLeaveCancelled(A) {
      W(A), dn(I, [A]);
    }
  });
}
function Cp(e) {
  if (e == null)
    return null;
  if (ke(e))
    return [Ho(e.enter), Ho(e.leave)];
  {
    const t = Ho(e);
    return [t, t];
  }
}
function Ho(e) {
  return hf(e);
}
function qt(e, t) {
  t.split(/\s+/).forEach((n) => n && e.classList.add(n)), (e._vtc || (e._vtc = /* @__PURE__ */ new Set())).add(t);
}
function fn(e, t) {
  t.split(/\s+/).forEach((r) => r && e.classList.remove(r));
  const { _vtc: n } = e;
  n && (n.delete(t), n.size || (e._vtc = void 0));
}
function hl(e) {
  requestAnimationFrame(() => {
    requestAnimationFrame(e);
  });
}
let Tp = 0;
function vl(e, t, n, r) {
  const i = e._endId = ++Tp, o = () => {
    i === e._endId && r();
  };
  if (n)
    return setTimeout(o, n);
  const { type: a, timeout: s, propCount: l } = Pp(e, t);
  if (!a)
    return r();
  const c = a + "end";
  let u = 0;
  const f = () => {
    e.removeEventListener(c, d), o();
  }, d = (m) => {
    m.target === e && ++u >= l && f();
  };
  setTimeout(() => {
    u < l && f();
  }, s + 1), e.addEventListener(c, d);
}
function Pp(e, t) {
  const n = window.getComputedStyle(e), r = (p) => (n[p] || "").split(", "), i = r(`${Wt}Delay`), o = r(`${Wt}Duration`), a = gl(i, o), s = r(`${ur}Delay`), l = r(`${ur}Duration`), c = gl(s, l);
  let u = null, f = 0, d = 0;
  t === Wt ? a > 0 && (u = Wt, f = a, d = o.length) : t === ur ? c > 0 && (u = ur, f = c, d = l.length) : (f = Math.max(a, c), u = f > 0 ? a > c ? Wt : ur : null, d = u ? u === Wt ? o.length : l.length : 0);
  const m = u === Wt && /\b(transform|all)(,|$)/.test(
    r(`${Wt}Property`).toString()
  );
  return {
    type: u,
    timeout: f,
    propCount: d,
    hasTransform: m
  };
}
function gl(e, t) {
  for (; e.length < t.length; )
    e = e.concat(e);
  return Math.max(...t.map((n, r) => yl(n) + yl(e[r])));
}
function yl(e) {
  return Number(e.slice(0, -1).replace(",", ".")) * 1e3;
}
function Mp() {
  return document.body.offsetHeight;
}
const qn = (e) => {
  const t = e.props["onUpdate:modelValue"] || !1;
  return Q(t) ? (n) => Ni(t, n) : t;
};
function Rp(e) {
  e.target.composing = !0;
}
function _l(e) {
  const t = e.target;
  t.composing && (t.composing = !1, t.dispatchEvent(new Event("input")));
}
const wl = {
  created(e, { modifiers: { lazy: t, trim: n, number: r } }, i) {
    e._assign = qn(i);
    const o = r || i.props && i.props.type === "number";
    Jt(e, t ? "change" : "input", (a) => {
      if (a.target.composing)
        return;
      let s = e.value;
      n && (s = s.trim()), o && (s = zi(s)), e._assign(s);
    }), n && Jt(e, "change", () => {
      e.value = e.value.trim();
    }), t || (Jt(e, "compositionstart", Rp), Jt(e, "compositionend", _l), Jt(e, "change", _l));
  },
  // set value on mounted so it's after min/max for type="range"
  mounted(e, { value: t }) {
    e.value = t ?? "";
  },
  beforeUpdate(e, { value: t, modifiers: { lazy: n, trim: r, number: i } }, o) {
    if (e._assign = qn(o), e.composing || document.activeElement === e && e.type !== "range" && (n || r && e.value.trim() === t || (i || e.type === "number") && zi(e.value) === t))
      return;
    const a = t ?? "";
    e.value !== a && (e.value = a);
  }
}, Dp = {
  // #4096 array checkboxes need to be deep traversed
  deep: !0,
  created(e, t, n) {
    e._assign = qn(n), Jt(e, "change", () => {
      const r = e._modelValue, i = Fr(e), o = e.checked, a = e._assign;
      if (Q(r)) {
        const s = Ha(r, i), l = s !== -1;
        if (o && !l)
          a(r.concat(i));
        else if (!o && l) {
          const c = [...r];
          c.splice(s, 1), a(c);
        }
      } else if (er(r)) {
        const s = new Set(r);
        o ? s.add(i) : s.delete(i), a(s);
      } else
        a(hu(e, o));
    });
  },
  // set initial checked on mount to wait for true-value/false-value
  mounted: xl,
  beforeUpdate(e, t, n) {
    e._assign = qn(n), xl(e, t, n);
  }
};
function xl(e, { value: t, oldValue: n }, r) {
  e._modelValue = t, Q(t) ? e.checked = Ha(t, r.props.value) > -1 : er(t) ? e.checked = t.has(r.props.value) : t !== n && (e.checked = Xr(t, hu(e, !0)));
}
const zp = {
  // <select multiple> value need to be deep traversed
  deep: !0,
  created(e, { value: t, modifiers: { number: n } }, r) {
    const i = er(t);
    Jt(e, "change", () => {
      const o = Array.prototype.filter.call(e.options, (a) => a.selected).map(
        (a) => n ? zi(Fr(a)) : Fr(a)
      );
      e._assign(
        e.multiple ? i ? new Set(o) : o : o[0]
      );
    }), e._assign = qn(r);
  },
  // set value in mounted & updated because <select> relies on its children
  // <option>s.
  mounted(e, { value: t }) {
    El(e, t);
  },
  beforeUpdate(e, t, n) {
    e._assign = qn(n);
  },
  updated(e, { value: t }) {
    El(e, t);
  }
};
function El(e, t) {
  const n = e.multiple;
  if (!(n && !Q(t) && !er(t))) {
    for (let r = 0, i = e.options.length; r < i; r++) {
      const o = e.options[r], a = Fr(o);
      if (n)
        Q(t) ? o.selected = Ha(t, a) > -1 : o.selected = t.has(a);
      else if (Xr(Fr(o), t)) {
        e.selectedIndex !== r && (e.selectedIndex = r);
        return;
      }
    }
    !n && e.selectedIndex !== -1 && (e.selectedIndex = -1);
  }
}
function Fr(e) {
  return "_value" in e ? e._value : e.value;
}
function hu(e, t) {
  const n = t ? "_trueValue" : "_falseValue";
  return n in e ? e[n] : t;
}
const Lp = /* @__PURE__ */ je({ patchProp: Ap }, pp);
let kl;
function $p() {
  return kl || (kl = Bm(Lp));
}
const Fp = (...e) => {
  const t = $p().createApp(...e), { mount: n } = t;
  return t.mount = (r) => {
    const i = Vp(r);
    if (!i)
      return;
    const o = t._component;
    !ae(o) && !o.render && !o.template && (o.template = i.innerHTML), i.innerHTML = "";
    const a = n(i, !1, i instanceof SVGElement);
    return i instanceof Element && (i.removeAttribute("v-cloak"), i.setAttribute("data-v-app", "")), a;
  }, t;
};
function Vp(e) {
  return Le(e) ? document.querySelector(e) : e;
}
function vt(e, t, ...n) {
  if (e in t) {
    let i = t[e];
    return typeof i == "function" ? i(...n) : i;
  }
  let r = new Error(`Tried to handle "${e}" but there is no handler defined. Only defined handlers are: ${Object.keys(t).map((i) => `"${i}"`).join(", ")}.`);
  throw Error.captureStackTrace && Error.captureStackTrace(r, vt), r;
}
var Kn = ((e) => (e[e.None = 0] = "None", e[e.RenderStrategy = 1] = "RenderStrategy", e[e.Static = 2] = "Static", e))(Kn || {}), Zt = ((e) => (e[e.Unmount = 0] = "Unmount", e[e.Hidden = 1] = "Hidden", e))(Zt || {});
function We({ visible: e = !0, features: t = 0, ourProps: n, theirProps: r, ...i }) {
  var o;
  let a = gu(r, n), s = Object.assign(i, { props: a });
  if (e || t & 2 && a.static)
    return Bo(s);
  if (t & 1) {
    let l = (o = a.unmount) == null || o ? 0 : 1;
    return vt(l, { 0() {
      return null;
    }, 1() {
      return Bo({ ...i, props: { ...a, hidden: !0, style: { display: "none" } } });
    } });
  }
  return Bo(s);
}
function Bo({ props: e, attrs: t, slots: n, slot: r, name: i }) {
  var o, a;
  let { as: s, ...l } = ss(e, ["unmount", "static"]), c = (o = n.default) == null ? void 0 : o.call(n, r), u = {};
  if (r) {
    let f = !1, d = [];
    for (let [m, p] of Object.entries(r))
      typeof p == "boolean" && (f = !0), p === !0 && d.push(m);
    f && (u["data-headlessui-state"] = d.join(" "));
  }
  if (s === "template") {
    if (c = vu(c ?? []), Object.keys(l).length > 0 || Object.keys(t).length > 0) {
      let [f, ...d] = c ?? [];
      if (!Up(f) || d.length > 0)
        throw new Error(['Passing props on "template"!', "", `The current component <${i} /> is rendering a "template".`, "However we need to passthrough the following props:", Object.keys(l).concat(Object.keys(t)).map((h) => h.trim()).filter((h, _, y) => y.indexOf(h) === _).sort((h, _) => h.localeCompare(_)).map((h) => `  - ${h}`).join(`
`), "", "You can apply a few solutions:", ['Add an `as="..."` prop, to ensure that we render an actual element instead of a "template".', "Render a single element as the child so that we can forward the props onto that element."].map((h) => `  - ${h}`).join(`
`)].join(`
`));
      let m = gu((a = f.props) != null ? a : {}, l), p = Ft(f, m);
      for (let h in m)
        h.startsWith("on") && (p.props || (p.props = {}), p.props[h] = m[h]);
      return p;
    }
    return Array.isArray(c) && c.length === 1 ? c[0] : c;
  }
  return He(s, Object.assign({}, l, u), { default: () => c });
}
function vu(e) {
  return e.flatMap((t) => t.type === De ? vu(t.children) : [t]);
}
function gu(...e) {
  if (e.length === 0)
    return {};
  if (e.length === 1)
    return e[0];
  let t = {}, n = {};
  for (let r of e)
    for (let i in r)
      i.startsWith("on") && typeof r[i] == "function" ? (n[i] != null || (n[i] = []), n[i].push(r[i])) : t[i] = r[i];
  if (t.disabled || t["aria-disabled"])
    return Object.assign(t, Object.fromEntries(Object.keys(n).map((r) => [r, void 0])));
  for (let r in n)
    Object.assign(t, { [r](i, ...o) {
      let a = n[r];
      for (let s of a) {
        if (i instanceof Event && i.defaultPrevented)
          return;
        s(i, ...o);
      }
    } });
  return t;
}
function jp(e) {
  let t = Object.assign({}, e);
  for (let n in t)
    t[n] === void 0 && delete t[n];
  return t;
}
function ss(e, t = []) {
  let n = Object.assign({}, e);
  for (let r of t)
    r in n && delete n[r];
  return n;
}
function Up(e) {
  return e == null ? !1 : typeof e.type == "string" || typeof e.type == "object" || typeof e.type == "function";
}
let Hp = 0;
function Bp() {
  return ++Hp;
}
function St() {
  return Bp();
}
var ct = ((e) => (e.Space = " ", e.Enter = "Enter", e.Escape = "Escape", e.Backspace = "Backspace", e.Delete = "Delete", e.ArrowLeft = "ArrowLeft", e.ArrowUp = "ArrowUp", e.ArrowRight = "ArrowRight", e.ArrowDown = "ArrowDown", e.Home = "Home", e.End = "End", e.PageUp = "PageUp", e.PageDown = "PageDown", e.Tab = "Tab", e))(ct || {});
function he(e) {
  var t;
  return e == null || e.value == null ? null : (t = e.value.$el) != null ? t : e.value;
}
let yu = Symbol("Context");
var Xe = ((e) => (e[e.Open = 1] = "Open", e[e.Closed = 2] = "Closed", e[e.Closing = 4] = "Closing", e[e.Opening = 8] = "Opening", e))(Xe || {});
function Gp() {
  return bo() !== null;
}
function bo() {
  return Ve(yu, null);
}
function _u(e) {
  rt(yu, e);
}
function Sl(e, t) {
  if (e)
    return e;
  let n = t ?? "button";
  if (typeof n == "string" && n.toLowerCase() === "button")
    return "button";
}
function Yp(e, t) {
  let n = re(Sl(e.value.type, e.value.as));
  return ze(() => {
    n.value = Sl(e.value.type, e.value.as);
  }), st(() => {
    var r;
    n.value || he(t) && he(t) instanceof HTMLButtonElement && !((r = he(t)) != null && r.hasAttribute("type")) && (n.value = "button");
  }), n;
}
var Wp = Object.defineProperty, qp = (e, t, n) => t in e ? Wp(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, Ol = (e, t, n) => (qp(e, typeof t != "symbol" ? t + "" : t, n), n);
let Kp = class {
  constructor() {
    Ol(this, "current", this.detect()), Ol(this, "currentId", 0);
  }
  set(t) {
    this.current !== t && (this.currentId = 0, this.current = t);
  }
  reset() {
    this.set(this.detect());
  }
  nextId() {
    return ++this.currentId;
  }
  get isServer() {
    return this.current === "server";
  }
  get isClient() {
    return this.current === "client";
  }
  detect() {
    return typeof window > "u" || typeof document > "u" ? "server" : "client";
  }
}, Jr = new Kp();
function Pt(e) {
  if (Jr.isServer)
    return null;
  if (e instanceof Node)
    return e.ownerDocument;
  if (e != null && e.hasOwnProperty("value")) {
    let t = he(e);
    if (t)
      return t.ownerDocument;
  }
  return document;
}
function Xp({ container: e, accept: t, walk: n, enabled: r }) {
  st(() => {
    let i = e.value;
    if (!i || r !== void 0 && !r.value)
      return;
    let o = Pt(e);
    if (!o)
      return;
    let a = Object.assign((l) => t(l), { acceptNode: t }), s = o.createTreeWalker(i, NodeFilter.SHOW_ELEMENT, a, !1);
    for (; s.nextNode(); )
      n(s.currentNode);
  });
}
let ha = ["[contentEditable=true]", "[tabindex]", "a[href]", "area[href]", "button:not([disabled])", "iframe", "input:not([disabled])", "select:not([disabled])", "textarea:not([disabled])"].map((e) => `${e}:not([tabindex='-1'])`).join(",");
var mt = ((e) => (e[e.First = 1] = "First", e[e.Previous = 2] = "Previous", e[e.Next = 4] = "Next", e[e.Last = 8] = "Last", e[e.WrapAround = 16] = "WrapAround", e[e.NoScroll = 32] = "NoScroll", e))(mt || {}), Bi = ((e) => (e[e.Error = 0] = "Error", e[e.Overflow = 1] = "Overflow", e[e.Success = 2] = "Success", e[e.Underflow = 3] = "Underflow", e))(Bi || {}), Jp = ((e) => (e[e.Previous = -1] = "Previous", e[e.Next = 1] = "Next", e))(Jp || {});
function Qp(e = document.body) {
  return e == null ? [] : Array.from(e.querySelectorAll(ha)).sort((t, n) => Math.sign((t.tabIndex || Number.MAX_SAFE_INTEGER) - (n.tabIndex || Number.MAX_SAFE_INTEGER)));
}
var wu = ((e) => (e[e.Strict = 0] = "Strict", e[e.Loose = 1] = "Loose", e))(wu || {});
function Zp(e, t = 0) {
  var n;
  return e === ((n = Pt(e)) == null ? void 0 : n.body) ? !1 : vt(t, { 0() {
    return e.matches(ha);
  }, 1() {
    let r = e;
    for (; r !== null; ) {
      if (r.matches(ha))
        return !0;
      r = r.parentElement;
    }
    return !1;
  } });
}
var e1 = ((e) => (e[e.Keyboard = 0] = "Keyboard", e[e.Mouse = 1] = "Mouse", e))(e1 || {});
typeof window < "u" && typeof document < "u" && (document.addEventListener("keydown", (e) => {
  e.metaKey || e.altKey || e.ctrlKey || (document.documentElement.dataset.headlessuiFocusVisible = "");
}, !0), document.addEventListener("click", (e) => {
  e.detail === 1 ? delete document.documentElement.dataset.headlessuiFocusVisible : e.detail === 0 && (document.documentElement.dataset.headlessuiFocusVisible = "");
}, !0));
function kn(e) {
  e == null || e.focus({ preventScroll: !0 });
}
let t1 = ["textarea", "input"].join(",");
function n1(e) {
  var t, n;
  return (n = (t = e == null ? void 0 : e.matches) == null ? void 0 : t.call(e, t1)) != null ? n : !1;
}
function xu(e, t = (n) => n) {
  return e.slice().sort((n, r) => {
    let i = t(n), o = t(r);
    if (i === null || o === null)
      return 0;
    let a = i.compareDocumentPosition(o);
    return a & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : a & Node.DOCUMENT_POSITION_PRECEDING ? 1 : 0;
  });
}
function Hn(e, t, { sorted: n = !0, relativeTo: r = null, skipElements: i = [] } = {}) {
  var o;
  let a = (o = Array.isArray(e) ? e.length > 0 ? e[0].ownerDocument : document : e == null ? void 0 : e.ownerDocument) != null ? o : document, s = Array.isArray(e) ? n ? xu(e) : e : Qp(e);
  i.length > 0 && s.length > 1 && (s = s.filter((p) => !i.includes(p))), r = r ?? a.activeElement;
  let l = (() => {
    if (t & 5)
      return 1;
    if (t & 10)
      return -1;
    throw new Error("Missing Focus.First, Focus.Previous, Focus.Next or Focus.Last");
  })(), c = (() => {
    if (t & 1)
      return 0;
    if (t & 2)
      return Math.max(0, s.indexOf(r)) - 1;
    if (t & 4)
      return Math.max(0, s.indexOf(r)) + 1;
    if (t & 8)
      return s.length - 1;
    throw new Error("Missing Focus.First, Focus.Previous, Focus.Next or Focus.Last");
  })(), u = t & 32 ? { preventScroll: !0 } : {}, f = 0, d = s.length, m;
  do {
    if (f >= d || f + d <= 0)
      return 0;
    let p = c + f;
    if (t & 16)
      p = (p + d) % d;
    else {
      if (p < 0)
        return 3;
      if (p >= d)
        return 1;
    }
    m = s[p], m == null || m.focus(u), f += l;
  } while (m !== a.activeElement);
  return t & 6 && n1(m) && m.select(), 2;
}
function Al(e, t, n) {
  Jr.isServer || st((r) => {
    document.addEventListener(e, t, n), r(() => document.removeEventListener(e, t, n));
  });
}
function Eu(e, t, n) {
  Jr.isServer || st((r) => {
    window.addEventListener(e, t, n), r(() => window.removeEventListener(e, t, n));
  });
}
function r1(e, t, n = $(() => !0)) {
  function r(o, a) {
    if (!n.value || o.defaultPrevented)
      return;
    let s = a(o);
    if (s === null || !s.getRootNode().contains(s))
      return;
    let l = function c(u) {
      return typeof u == "function" ? c(u()) : Array.isArray(u) || u instanceof Set ? u : [u];
    }(e);
    for (let c of l) {
      if (c === null)
        continue;
      let u = c instanceof HTMLElement ? c : he(c);
      if (u != null && u.contains(s) || o.composed && o.composedPath().includes(u))
        return;
    }
    return !Zp(s, wu.Loose) && s.tabIndex !== -1 && o.preventDefault(), t(o, s);
  }
  let i = re(null);
  Al("mousedown", (o) => {
    var a, s;
    n.value && (i.value = ((s = (a = o.composedPath) == null ? void 0 : a.call(o)) == null ? void 0 : s[0]) || o.target);
  }, !0), Al("click", (o) => {
    i.value && (r(o, () => i.value), i.value = null);
  }, !0), Eu("blur", (o) => r(o, () => window.document.activeElement instanceof HTMLIFrameElement ? window.document.activeElement : null), !0);
}
var Vr = ((e) => (e[e.None = 1] = "None", e[e.Focusable = 2] = "Focusable", e[e.Hidden = 4] = "Hidden", e))(Vr || {});
let Gi = de({ name: "Hidden", props: { as: { type: [Object, String], default: "div" }, features: { type: Number, default: 1 } }, setup(e, { slots: t, attrs: n }) {
  return () => {
    let { features: r, ...i } = e, o = { "aria-hidden": (r & 2) === 2 ? !0 : void 0, style: { position: "fixed", top: 1, left: 1, width: 1, height: 0, padding: 0, margin: -1, overflow: "hidden", clip: "rect(0, 0, 0, 0)", whiteSpace: "nowrap", borderWidth: "0", ...(r & 4) === 4 && (r & 2) !== 2 && { display: "none" } } };
    return We({ ourProps: o, theirProps: i, slot: {}, attrs: n, slots: t, name: "Hidden" });
  };
} });
function ku(e = {}, t = null, n = []) {
  for (let [r, i] of Object.entries(e))
    Ou(n, Su(t, r), i);
  return n;
}
function Su(e, t) {
  return e ? e + "[" + t + "]" : t;
}
function Ou(e, t, n) {
  if (Array.isArray(n))
    for (let [r, i] of n.entries())
      Ou(e, Su(t, r.toString()), i);
  else
    n instanceof Date ? e.push([t, n.toISOString()]) : typeof n == "boolean" ? e.push([t, n ? "1" : "0"]) : typeof n == "string" ? e.push([t, n]) : typeof n == "number" ? e.push([t, `${n}`]) : n == null ? e.push([t, ""]) : ku(n, t, e);
}
function i1(e) {
  var t;
  let n = (t = e == null ? void 0 : e.form) != null ? t : e.closest("form");
  if (n) {
    for (let r of n.elements)
      if (r.tagName === "INPUT" && r.type === "submit" || r.tagName === "BUTTON" && r.type === "submit" || r.nodeName === "INPUT" && r.type === "image") {
        r.click();
        return;
      }
  }
}
function o1(e, t, n) {
  let r = re(n == null ? void 0 : n.value), i = $(() => e.value !== void 0);
  return [$(() => i.value ? e.value : r.value), function(o) {
    return i.value || (r.value = o), t == null ? void 0 : t(o);
  }];
}
function a1() {
  return /iPhone/gi.test(window.navigator.platform) || /Mac/gi.test(window.navigator.platform) && window.navigator.maxTouchPoints > 0;
}
function ho() {
  let e = [], t = { addEventListener(n, r, i, o) {
    return n.addEventListener(r, i, o), t.add(() => n.removeEventListener(r, i, o));
  }, requestAnimationFrame(...n) {
    let r = requestAnimationFrame(...n);
    t.add(() => cancelAnimationFrame(r));
  }, nextFrame(...n) {
    t.requestAnimationFrame(() => {
      t.requestAnimationFrame(...n);
    });
  }, setTimeout(...n) {
    let r = setTimeout(...n);
    t.add(() => clearTimeout(r));
  }, style(n, r, i) {
    let o = n.style.getPropertyValue(r);
    return Object.assign(n.style, { [r]: i }), this.add(() => {
      Object.assign(n.style, { [r]: o });
    });
  }, group(n) {
    let r = ho();
    return n(r), this.add(() => r.dispose());
  }, add(n) {
    return e.push(n), () => {
      let r = e.indexOf(n);
      if (r >= 0)
        for (let i of e.splice(r, 1))
          i();
    };
  }, dispose() {
    for (let n of e.splice(0))
      n();
  } };
  return t;
}
var hr = ((e) => (e[e.Forwards = 0] = "Forwards", e[e.Backwards = 1] = "Backwards", e))(hr || {});
function s1() {
  let e = re(0);
  return Eu("keydown", (t) => {
    t.key === "Tab" && (e.value = t.shiftKey ? 1 : 0);
  }), e;
}
function Au(e, t, n, r) {
  Jr.isServer || st((i) => {
    e = e ?? window, e.addEventListener(t, n, r), i(() => e.removeEventListener(t, n, r));
  });
}
function Nu(e) {
  typeof queueMicrotask == "function" ? queueMicrotask(e) : Promise.resolve().then(e).catch((t) => setTimeout(() => {
    throw t;
  }));
}
function l1(e) {
  function t() {
    document.readyState !== "loading" && (e(), document.removeEventListener("DOMContentLoaded", t));
  }
  typeof window < "u" && typeof document < "u" && (document.addEventListener("DOMContentLoaded", t), t());
}
function Iu(e) {
  if (!e)
    return /* @__PURE__ */ new Set();
  if (typeof e == "function")
    return new Set(e());
  let t = /* @__PURE__ */ new Set();
  for (let n of e.value) {
    let r = he(n);
    r instanceof HTMLElement && t.add(r);
  }
  return t;
}
var Cu = ((e) => (e[e.None = 1] = "None", e[e.InitialFocus = 2] = "InitialFocus", e[e.TabLock = 4] = "TabLock", e[e.FocusLock = 8] = "FocusLock", e[e.RestoreFocus = 16] = "RestoreFocus", e[e.All = 30] = "All", e))(Cu || {});
let dr = Object.assign(de({ name: "FocusTrap", props: { as: { type: [Object, String], default: "div" }, initialFocus: { type: Object, default: null }, features: { type: Number, default: 30 }, containers: { type: [Object, Function], default: re(/* @__PURE__ */ new Set()) } }, inheritAttrs: !1, setup(e, { attrs: t, slots: n, expose: r }) {
  let i = re(null);
  r({ el: i, $el: i });
  let o = $(() => Pt(i)), a = re(!1);
  ze(() => a.value = !0), Ze(() => a.value = !1), u1({ ownerDocument: o }, $(() => a.value && !!(e.features & 16)));
  let s = d1({ ownerDocument: o, container: i, initialFocus: $(() => e.initialFocus) }, $(() => a.value && !!(e.features & 2)));
  f1({ ownerDocument: o, container: i, containers: e.containers, previousActiveElement: s }, $(() => a.value && !!(e.features & 8)));
  let l = s1();
  function c(m) {
    let p = he(i);
    p && ((h) => h())(() => {
      vt(l.value, { [hr.Forwards]: () => {
        Hn(p, mt.First, { skipElements: [m.relatedTarget] });
      }, [hr.Backwards]: () => {
        Hn(p, mt.Last, { skipElements: [m.relatedTarget] });
      } });
    });
  }
  let u = re(!1);
  function f(m) {
    m.key === "Tab" && (u.value = !0, requestAnimationFrame(() => {
      u.value = !1;
    }));
  }
  function d(m) {
    if (!a.value)
      return;
    let p = Iu(e.containers);
    he(i) instanceof HTMLElement && p.add(he(i));
    let h = m.relatedTarget;
    h instanceof HTMLElement && h.dataset.headlessuiFocusGuard !== "true" && (Tu(p, h) || (u.value ? Hn(he(i), vt(l.value, { [hr.Forwards]: () => mt.Next, [hr.Backwards]: () => mt.Previous }) | mt.WrapAround, { relativeTo: m.target }) : m.target instanceof HTMLElement && kn(m.target)));
  }
  return () => {
    let m = {}, p = { ref: i, onKeydown: f, onFocusout: d }, { features: h, initialFocus: _, containers: y, ...g } = e;
    return He(De, [!!(h & 4) && He(Gi, { as: "button", type: "button", "data-headlessui-focus-guard": !0, onFocus: c, features: Vr.Focusable }), We({ ourProps: p, theirProps: { ...t, ...g }, slot: m, attrs: t, slots: n, name: "FocusTrap" }), !!(h & 4) && He(Gi, { as: "button", type: "button", "data-headlessui-focus-guard": !0, onFocus: c, features: Vr.Focusable })]);
  };
} }), { features: Cu }), vn = [];
l1(() => {
  function e(t) {
    t.target instanceof HTMLElement && t.target !== document.body && vn[0] !== t.target && (vn.unshift(t.target), vn = vn.filter((n) => n != null && n.isConnected), vn.splice(10));
  }
  window.addEventListener("click", e, { capture: !0 }), window.addEventListener("mousedown", e, { capture: !0 }), window.addEventListener("focus", e, { capture: !0 }), document.body.addEventListener("click", e, { capture: !0 }), document.body.addEventListener("mousedown", e, { capture: !0 }), document.body.addEventListener("focus", e, { capture: !0 });
});
function c1(e) {
  let t = re(vn.slice());
  return bt([e], ([n], [r]) => {
    r === !0 && n === !1 ? Nu(() => {
      t.value.splice(0);
    }) : r === !1 && n === !0 && (t.value = vn.slice());
  }, { flush: "post" }), () => {
    var n;
    return (n = t.value.find((r) => r != null && r.isConnected)) != null ? n : null;
  };
}
function u1({ ownerDocument: e }, t) {
  let n = c1(t);
  ze(() => {
    st(() => {
      var r, i;
      t.value || ((r = e.value) == null ? void 0 : r.activeElement) === ((i = e.value) == null ? void 0 : i.body) && kn(n());
    }, { flush: "post" });
  }), Ze(() => {
    t.value && kn(n());
  });
}
function d1({ ownerDocument: e, container: t, initialFocus: n }, r) {
  let i = re(null), o = re(!1);
  return ze(() => o.value = !0), Ze(() => o.value = !1), ze(() => {
    bt([t, n, r], (a, s) => {
      if (a.every((c, u) => (s == null ? void 0 : s[u]) === c) || !r.value)
        return;
      let l = he(t);
      l && Nu(() => {
        var c, u;
        if (!o.value)
          return;
        let f = he(n), d = (c = e.value) == null ? void 0 : c.activeElement;
        if (f) {
          if (f === d) {
            i.value = d;
            return;
          }
        } else if (l.contains(d)) {
          i.value = d;
          return;
        }
        f ? kn(f) : Hn(l, mt.First | mt.NoScroll) === Bi.Error && console.warn("There are no focusable elements inside the <FocusTrap />"), i.value = (u = e.value) == null ? void 0 : u.activeElement;
      });
    }, { immediate: !0, flush: "post" });
  }), i;
}
function f1({ ownerDocument: e, container: t, containers: n, previousActiveElement: r }, i) {
  var o;
  Au((o = e.value) == null ? void 0 : o.defaultView, "focus", (a) => {
    if (!i.value)
      return;
    let s = Iu(n);
    he(t) instanceof HTMLElement && s.add(he(t));
    let l = r.value;
    if (!l)
      return;
    let c = a.target;
    c && c instanceof HTMLElement ? Tu(s, c) ? (r.value = c, kn(c)) : (a.preventDefault(), a.stopPropagation(), kn(l)) : kn(r.value);
  }, !0);
}
function Tu(e, t) {
  for (let n of e)
    if (n.contains(t))
      return !0;
  return !1;
}
let Go = /* @__PURE__ */ new Map(), fr = /* @__PURE__ */ new Map();
function Nl(e, t = re(!0)) {
  st((n) => {
    var r;
    if (!t.value)
      return;
    let i = he(e);
    if (!i)
      return;
    n(function() {
      var a;
      if (!i)
        return;
      let s = (a = fr.get(i)) != null ? a : 1;
      if (s === 1 ? fr.delete(i) : fr.set(i, s - 1), s !== 1)
        return;
      let l = Go.get(i);
      l && (l["aria-hidden"] === null ? i.removeAttribute("aria-hidden") : i.setAttribute("aria-hidden", l["aria-hidden"]), i.inert = l.inert, Go.delete(i));
    });
    let o = (r = fr.get(i)) != null ? r : 0;
    fr.set(i, o + 1), o === 0 && (Go.set(i, { "aria-hidden": i.getAttribute("aria-hidden"), inert: i.inert }), i.setAttribute("aria-hidden", "true"), i.inert = !0);
  });
}
let Pu = Symbol("ForcePortalRootContext");
function m1() {
  return Ve(Pu, !1);
}
let Il = de({ name: "ForcePortalRoot", props: { as: { type: [Object, String], default: "template" }, force: { type: Boolean, default: !1 } }, setup(e, { slots: t, attrs: n }) {
  return rt(Pu, e.force), () => {
    let { force: r, ...i } = e;
    return We({ theirProps: i, ourProps: {}, slot: {}, slots: t, attrs: n, name: "ForcePortalRoot" });
  };
} });
function p1(e) {
  let t = Pt(e);
  if (!t) {
    if (e === null)
      return null;
    throw new Error(`[Headless UI]: Cannot find ownerDocument for contextElement: ${e}`);
  }
  let n = t.getElementById("headlessui-portal-root");
  if (n)
    return n;
  let r = t.createElement("div");
  return r.setAttribute("id", "headlessui-portal-root"), t.body.appendChild(r);
}
let b1 = de({ name: "Portal", props: { as: { type: [Object, String], default: "div" } }, setup(e, { slots: t, attrs: n }) {
  let r = re(null), i = $(() => Pt(r)), o = m1(), a = Ve(Mu, null), s = re(o === !0 || a == null ? p1(r.value) : a.resolveTarget());
  st(() => {
    o || a != null && (s.value = a.resolveTarget());
  });
  let l = Ve(va, null);
  return ze(() => {
    let c = he(r);
    c && l && Ze(l.register(c));
  }), Ze(() => {
    var c, u;
    let f = (c = i.value) == null ? void 0 : c.getElementById("headlessui-portal-root");
    f && s.value === f && s.value.children.length <= 0 && ((u = s.value.parentElement) == null || u.removeChild(s.value));
  }), () => {
    if (s.value === null)
      return null;
    let c = { ref: r, "data-headlessui-portal": "" };
    return He(Xm, { to: s.value }, We({ ourProps: c, theirProps: e, slot: {}, attrs: n, slots: t, name: "Portal" }));
  };
} }), va = Symbol("PortalParentContext");
function h1() {
  let e = Ve(va, null), t = re([]);
  function n(o) {
    return t.value.push(o), e && e.register(o), () => r(o);
  }
  function r(o) {
    let a = t.value.indexOf(o);
    a !== -1 && t.value.splice(a, 1), e && e.unregister(o);
  }
  let i = { register: n, unregister: r, portals: t };
  return [t, de({ name: "PortalWrapper", setup(o, { slots: a }) {
    return rt(va, i), () => {
      var s;
      return (s = a.default) == null ? void 0 : s.call(a);
    };
  } })];
}
let Mu = Symbol("PortalGroupContext"), v1 = de({ name: "PortalGroup", props: { as: { type: [Object, String], default: "template" }, target: { type: Object, default: null } }, setup(e, { attrs: t, slots: n }) {
  let r = ir({ resolveTarget() {
    return e.target;
  } });
  return rt(Mu, r), () => {
    let { target: i, ...o } = e;
    return We({ theirProps: o, ourProps: {}, slot: {}, attrs: t, slots: n, name: "PortalGroup" });
  };
} }), Ru = Symbol("StackContext");
var ga = ((e) => (e[e.Add = 0] = "Add", e[e.Remove = 1] = "Remove", e))(ga || {});
function g1() {
  return Ve(Ru, () => {
  });
}
function y1({ type: e, enabled: t, element: n, onUpdate: r }) {
  let i = g1();
  function o(...a) {
    r == null || r(...a), i(...a);
  }
  ze(() => {
    bt(t, (a, s) => {
      a ? o(0, e, n) : s === !0 && o(1, e, n);
    }, { immediate: !0, flush: "sync" });
  }), Ze(() => {
    t.value && o(1, e, n);
  }), rt(Ru, o);
}
let Du = Symbol("DescriptionContext");
function _1() {
  let e = Ve(Du, null);
  if (e === null)
    throw new Error("Missing parent");
  return e;
}
function ls({ slot: e = re({}), name: t = "Description", props: n = {} } = {}) {
  let r = re([]);
  function i(o) {
    return r.value.push(o), () => {
      let a = r.value.indexOf(o);
      a !== -1 && r.value.splice(a, 1);
    };
  }
  return rt(Du, { register: i, slot: e, name: t, props: n }), $(() => r.value.length > 0 ? r.value.join(" ") : void 0);
}
let zu = de({ name: "Description", props: { as: { type: [Object, String], default: "p" }, id: { type: String, default: () => `headlessui-description-${St()}` } }, setup(e, { attrs: t, slots: n }) {
  let r = _1();
  return ze(() => Ze(r.register(e.id))), () => {
    let { name: i = "Description", slot: o = re({}), props: a = {} } = r, { id: s, ...l } = e, c = { ...Object.entries(a).reduce((u, [f, d]) => Object.assign(u, { [f]: Ja(d) }), {}), id: s };
    return We({ ourProps: c, theirProps: l, slot: o.value, attrs: t, slots: n, name: i });
  };
} });
function w1(e) {
  let t = oa(e.getSnapshot());
  return Ze(e.subscribe(() => {
    t.value = e.getSnapshot();
  })), t;
}
function x1(e, t) {
  let n = e(), r = /* @__PURE__ */ new Set();
  return { getSnapshot() {
    return n;
  }, subscribe(i) {
    return r.add(i), () => r.delete(i);
  }, dispatch(i, ...o) {
    let a = t[i].call(n, ...o);
    a && (n = a, r.forEach((s) => s()));
  } };
}
function E1() {
  let e;
  return { before({ doc: t }) {
    var n;
    let r = t.documentElement;
    e = ((n = t.defaultView) != null ? n : window).innerWidth - r.clientWidth;
  }, after({ doc: t, d: n }) {
    let r = t.documentElement, i = r.clientWidth - r.offsetWidth, o = e - i;
    n.style(r, "paddingRight", `${o}px`);
  } };
}
function k1() {
  if (!a1())
    return {};
  let e;
  return { before() {
    e = window.pageYOffset;
  }, after({ doc: t, d: n, meta: r }) {
    function i(a) {
      return r.containers.flatMap((s) => s()).some((s) => s.contains(a));
    }
    n.style(t.body, "marginTop", `-${e}px`), window.scrollTo(0, 0);
    let o = null;
    n.addEventListener(t, "click", (a) => {
      if (a.target instanceof HTMLElement)
        try {
          let s = a.target.closest("a");
          if (!s)
            return;
          let { hash: l } = new URL(s.href), c = t.querySelector(l);
          c && !i(c) && (o = c);
        } catch {
        }
    }, !0), n.addEventListener(t, "touchmove", (a) => {
      a.target instanceof HTMLElement && !i(a.target) && a.preventDefault();
    }, { passive: !1 }), n.add(() => {
      window.scrollTo(0, window.pageYOffset + e), o && o.isConnected && (o.scrollIntoView({ block: "nearest" }), o = null);
    });
  } };
}
function S1() {
  return { before({ doc: e, d: t }) {
    t.style(e.documentElement, "overflow", "hidden");
  } };
}
function O1(e) {
  let t = {};
  for (let n of e)
    Object.assign(t, n(t));
  return t;
}
let yn = x1(() => /* @__PURE__ */ new Map(), { PUSH(e, t) {
  var n;
  let r = (n = this.get(e)) != null ? n : { doc: e, count: 0, d: ho(), meta: /* @__PURE__ */ new Set() };
  return r.count++, r.meta.add(t), this.set(e, r), this;
}, POP(e, t) {
  let n = this.get(e);
  return n && (n.count--, n.meta.delete(t)), this;
}, SCROLL_PREVENT({ doc: e, d: t, meta: n }) {
  let r = { doc: e, d: t, meta: O1(n) }, i = [k1(), E1(), S1()];
  i.forEach(({ before: o }) => o == null ? void 0 : o(r)), i.forEach(({ after: o }) => o == null ? void 0 : o(r));
}, SCROLL_ALLOW({ d: e }) {
  e.dispose();
}, TEARDOWN({ doc: e }) {
  this.delete(e);
} });
yn.subscribe(() => {
  let e = yn.getSnapshot(), t = /* @__PURE__ */ new Map();
  for (let [n] of e)
    t.set(n, n.documentElement.style.overflow);
  for (let n of e.values()) {
    let r = t.get(n.doc) === "hidden", i = n.count !== 0;
    (i && !r || !i && r) && yn.dispatch(n.count > 0 ? "SCROLL_PREVENT" : "SCROLL_ALLOW", n), n.count === 0 && yn.dispatch("TEARDOWN", n);
  }
});
function A1(e, t, n) {
  let r = w1(yn), i = $(() => {
    let o = e.value ? r.value.get(e.value) : void 0;
    return o ? o.count > 0 : !1;
  });
  return bt([e, t], ([o, a], [s], l) => {
    if (!o || !a)
      return;
    yn.dispatch("PUSH", o, n);
    let c = !1;
    l(() => {
      c || (yn.dispatch("POP", s ?? o, n), c = !0);
    });
  }, { immediate: !0 }), i;
}
function N1({ defaultContainers: e = [], portals: t } = {}) {
  let n = re(null), r = Pt(n);
  function i() {
    var o;
    let a = [];
    for (let s of e)
      s !== null && (s instanceof HTMLElement ? a.push(s) : "value" in s && s.value instanceof HTMLElement && a.push(s.value));
    if (t != null && t.value)
      for (let s of t.value)
        a.push(s);
    for (let s of (o = r == null ? void 0 : r.querySelectorAll("html > *, body > *")) != null ? o : [])
      s !== document.body && s !== document.head && s instanceof HTMLElement && s.id !== "headlessui-portal-root" && (s.contains(he(n)) || a.some((l) => s.contains(l)) || a.push(s));
    return a;
  }
  return { resolveContainers: i, contains(o) {
    return i().some((a) => a.contains(o));
  }, mainTreeNodeRef: n, MainTreeNode() {
    return He(Gi, { features: Vr.Hidden, ref: n });
  } };
}
var I1 = ((e) => (e[e.Open = 0] = "Open", e[e.Closed = 1] = "Closed", e))(I1 || {});
let ya = Symbol("DialogContext");
function vo(e) {
  let t = Ve(ya, null);
  if (t === null) {
    let n = new Error(`<${e} /> is missing a parent <Dialog /> component.`);
    throw Error.captureStackTrace && Error.captureStackTrace(n, vo), n;
  }
  return t;
}
let fi = "DC8F892D-2EBD-447C-A4C8-A03058436FF4", C1 = de({ name: "Dialog", inheritAttrs: !1, props: { as: { type: [Object, String], default: "div" }, static: { type: Boolean, default: !1 }, unmount: { type: Boolean, default: !0 }, open: { type: [Boolean, String], default: fi }, initialFocus: { type: Object, default: null }, id: { type: String, default: () => `headlessui-dialog-${St()}` } }, emits: { close: (e) => !0 }, setup(e, { emit: t, attrs: n, slots: r, expose: i }) {
  var o;
  let a = re(!1);
  ze(() => {
    a.value = !0;
  });
  let s = re(0), l = bo(), c = $(() => e.open === fi && l !== null ? (l.value & Xe.Open) === Xe.Open : e.open), u = re(null), f = $(() => Pt(u));
  if (i({ el: u, $el: u }), !(e.open !== fi || l !== null))
    throw new Error("You forgot to provide an `open` prop to the `Dialog`.");
  if (typeof c.value != "boolean")
    throw new Error(`You provided an \`open\` prop to the \`Dialog\`, but the value is not a boolean. Received: ${c.value === fi ? void 0 : e.open}`);
  let d = $(() => a.value && c.value ? 0 : 1), m = $(() => d.value === 0), p = $(() => s.value > 1), h = Ve(ya, null) !== null, [_, y] = h1(), { resolveContainers: g, mainTreeNodeRef: w, MainTreeNode: x } = N1({ portals: _, defaultContainers: [$(() => {
    var V;
    return (V = X.panelRef.value) != null ? V : u.value;
  })] }), I = $(() => p.value ? "parent" : "leaf"), U = $(() => l !== null ? (l.value & Xe.Closing) === Xe.Closing : !1), M = $(() => h || U.value ? !1 : m.value), C = $(() => {
    var V, G, me;
    return (me = Array.from((G = (V = f.value) == null ? void 0 : V.querySelectorAll("body > *")) != null ? G : []).find((Ue) => Ue.id === "headlessui-portal-root" ? !1 : Ue.contains(he(w)) && Ue instanceof HTMLElement)) != null ? me : null;
  });
  Nl(C, M);
  let R = $(() => p.value ? !0 : m.value), W = $(() => {
    var V, G, me;
    return (me = Array.from((G = (V = f.value) == null ? void 0 : V.querySelectorAll("[data-headlessui-portal]")) != null ? G : []).find((Ue) => Ue.contains(he(w)) && Ue instanceof HTMLElement)) != null ? me : null;
  });
  Nl(W, R), y1({ type: "Dialog", enabled: $(() => d.value === 0), element: u, onUpdate: (V, G) => {
    if (G === "Dialog")
      return vt(V, { [ga.Add]: () => s.value += 1, [ga.Remove]: () => s.value -= 1 });
  } });
  let F = ls({ name: "DialogDescription", slot: $(() => ({ open: c.value })) }), A = re(null), X = { titleId: A, panelRef: re(null), dialogState: d, setTitleId(V) {
    A.value !== V && (A.value = V);
  }, close() {
    t("close", !1);
  } };
  rt(ya, X);
  let ce = $(() => !(!m.value || p.value));
  r1(g, (V, G) => {
    X.close(), Uc(() => G == null ? void 0 : G.focus());
  }, ce);
  let Ce = $(() => !(p.value || d.value !== 0));
  Au((o = f.value) == null ? void 0 : o.defaultView, "keydown", (V) => {
    Ce.value && (V.defaultPrevented || V.key === ct.Escape && (V.preventDefault(), V.stopPropagation(), X.close()));
  });
  let J = $(() => !(U.value || d.value !== 0 || h));
  return A1(f, J, (V) => {
    var G;
    return { containers: [...(G = V.containers) != null ? G : [], g] };
  }), st((V) => {
    if (d.value !== 0)
      return;
    let G = he(u);
    if (!G)
      return;
    let me = new ResizeObserver((Ue) => {
      for (let Te of Ue) {
        let Me = Te.target.getBoundingClientRect();
        Me.x === 0 && Me.y === 0 && Me.width === 0 && Me.height === 0 && X.close();
      }
    });
    me.observe(G), V(() => me.disconnect());
  }), () => {
    let { id: V, open: G, initialFocus: me, ...Ue } = e, Te = { ...n, ref: u, id: V, role: "dialog", "aria-modal": d.value === 0 ? !0 : void 0, "aria-labelledby": A.value, "aria-describedby": F.value }, Me = { open: d.value === 0 };
    return He(Il, { force: !0 }, () => [He(b1, () => He(v1, { target: u.value }, () => He(Il, { force: !1 }, () => He(dr, { initialFocus: me, containers: g, features: m.value ? vt(I.value, { parent: dr.features.RestoreFocus, leaf: dr.features.All & ~dr.features.FocusLock }) : dr.features.None }, () => He(y, {}, () => We({ ourProps: Te, theirProps: { ...Ue, ...n }, slot: Me, attrs: n, slots: r, visible: d.value === 0, features: Kn.RenderStrategy | Kn.Static, name: "Dialog" })))))), He(x)]);
  };
} }), T1 = de({ name: "DialogOverlay", props: { as: { type: [Object, String], default: "div" }, id: { type: String, default: () => `headlessui-dialog-overlay-${St()}` } }, setup(e, { attrs: t, slots: n }) {
  let r = vo("DialogOverlay");
  function i(o) {
    o.target === o.currentTarget && (o.preventDefault(), o.stopPropagation(), r.close());
  }
  return () => {
    let { id: o, ...a } = e;
    return We({ ourProps: { id: o, "aria-hidden": !0, onClick: i }, theirProps: a, slot: { open: r.dialogState.value === 0 }, attrs: t, slots: n, name: "DialogOverlay" });
  };
} }), P1 = de({ name: "DialogPanel", props: { as: { type: [Object, String], default: "div" }, id: { type: String, default: () => `headlessui-dialog-panel-${St()}` } }, setup(e, { attrs: t, slots: n, expose: r }) {
  let i = vo("DialogPanel");
  r({ el: i.panelRef, $el: i.panelRef });
  function o(a) {
    a.stopPropagation();
  }
  return () => {
    let { id: a, ...s } = e, l = { id: a, ref: i.panelRef, onClick: o };
    return We({ ourProps: l, theirProps: s, slot: { open: i.dialogState.value === 0 }, attrs: t, slots: n, name: "DialogPanel" });
  };
} }), ln = de({ name: "DialogTitle", props: { as: { type: [Object, String], default: "h2" }, id: { type: String, default: () => `headlessui-dialog-title-${St()}` } }, setup(e, { attrs: t, slots: n }) {
  let r = vo("DialogTitle");
  return ze(() => {
    r.setTitleId(e.id), Ze(() => r.setTitleId(null));
  }), () => {
    let { id: i, ...o } = e;
    return We({ ourProps: { id: i }, theirProps: o, slot: { open: r.dialogState.value === 0 }, attrs: t, slots: n, name: "DialogTitle" });
  };
} }), Lu = zu;
var M1 = ((e) => (e[e.Open = 0] = "Open", e[e.Closed = 1] = "Closed", e))(M1 || {});
let $u = Symbol("DisclosureContext");
function cs(e) {
  let t = Ve($u, null);
  if (t === null) {
    let n = new Error(`<${e} /> is missing a parent <Disclosure /> component.`);
    throw Error.captureStackTrace && Error.captureStackTrace(n, cs), n;
  }
  return t;
}
let Fu = Symbol("DisclosurePanelContext");
function R1() {
  return Ve(Fu, null);
}
let D1 = de({ name: "Disclosure", props: { as: { type: [Object, String], default: "template" }, defaultOpen: { type: [Boolean], default: !1 } }, setup(e, { slots: t, attrs: n }) {
  let r = re(e.defaultOpen ? 0 : 1), i = re(null), o = re(null), a = { buttonId: re(null), panelId: re(null), disclosureState: r, panel: i, button: o, toggleDisclosure() {
    r.value = vt(r.value, { 0: 1, 1: 0 });
  }, closeDisclosure() {
    r.value !== 1 && (r.value = 1);
  }, close(s) {
    a.closeDisclosure();
    let l = (() => s ? s instanceof HTMLElement ? s : s.value instanceof HTMLElement ? he(s) : he(a.button) : he(a.button))();
    l == null || l.focus();
  } };
  return rt($u, a), _u($(() => vt(r.value, { 0: Xe.Open, 1: Xe.Closed }))), () => {
    let { defaultOpen: s, ...l } = e, c = { open: r.value === 0, close: a.close };
    return We({ theirProps: l, ourProps: {}, slot: c, slots: t, attrs: n, name: "Disclosure" });
  };
} }), z1 = de({ name: "DisclosureButton", props: { as: { type: [Object, String], default: "button" }, disabled: { type: [Boolean], default: !1 }, id: { type: String, default: () => `headlessui-disclosure-button-${St()}` } }, setup(e, { attrs: t, slots: n, expose: r }) {
  let i = cs("DisclosureButton");
  ze(() => {
    i.buttonId.value = e.id;
  }), Ze(() => {
    i.buttonId.value = null;
  });
  let o = R1(), a = $(() => o === null ? !1 : o.value === i.panelId.value), s = re(null);
  r({ el: s, $el: s }), a.value || st(() => {
    i.button.value = s.value;
  });
  let l = Yp($(() => ({ as: e.as, type: t.type })), s);
  function c() {
    var d;
    e.disabled || (a.value ? (i.toggleDisclosure(), (d = he(i.button)) == null || d.focus()) : i.toggleDisclosure());
  }
  function u(d) {
    var m;
    if (!e.disabled)
      if (a.value)
        switch (d.key) {
          case ct.Space:
          case ct.Enter:
            d.preventDefault(), d.stopPropagation(), i.toggleDisclosure(), (m = he(i.button)) == null || m.focus();
            break;
        }
      else
        switch (d.key) {
          case ct.Space:
          case ct.Enter:
            d.preventDefault(), d.stopPropagation(), i.toggleDisclosure();
            break;
        }
  }
  function f(d) {
    switch (d.key) {
      case ct.Space:
        d.preventDefault();
        break;
    }
  }
  return () => {
    let d = { open: i.disclosureState.value === 0 }, { id: m, ...p } = e, h = a.value ? { ref: s, type: l.value, onClick: c, onKeydown: u } : { id: m, ref: s, type: l.value, "aria-expanded": e.disabled ? void 0 : i.disclosureState.value === 0, "aria-controls": he(i.panel) ? i.panelId.value : void 0, disabled: e.disabled ? !0 : void 0, onClick: c, onKeydown: u, onKeyup: f };
    return We({ ourProps: h, theirProps: p, slot: d, attrs: t, slots: n, name: "DisclosureButton" });
  };
} }), L1 = de({ name: "DisclosurePanel", props: { as: { type: [Object, String], default: "div" }, static: { type: Boolean, default: !1 }, unmount: { type: Boolean, default: !0 }, id: { type: String, default: () => `headlessui-disclosure-panel-${St()}` } }, setup(e, { attrs: t, slots: n, expose: r }) {
  let i = cs("DisclosurePanel");
  ze(() => {
    i.panelId.value = e.id;
  }), Ze(() => {
    i.panelId.value = null;
  }), r({ el: i.panel, $el: i.panel }), rt(Fu, i.panelId);
  let o = bo(), a = $(() => o !== null ? (o.value & Xe.Open) === Xe.Open : i.disclosureState.value === 0);
  return () => {
    let s = { open: i.disclosureState.value === 0, close: i.close }, { id: l, ...c } = e, u = { id: l, ref: i.panel };
    return We({ ourProps: u, theirProps: c, slot: s, attrs: t, slots: n, features: Kn.RenderStrategy | Kn.Static, visible: a.value, name: "DisclosurePanel" });
  };
} }), Vu = Symbol("LabelContext");
function ju() {
  let e = Ve(Vu, null);
  if (e === null) {
    let t = new Error("You used a <Label /> component, but it is not inside a parent.");
    throw Error.captureStackTrace && Error.captureStackTrace(t, ju), t;
  }
  return e;
}
function Uu({ slot: e = {}, name: t = "Label", props: n = {} } = {}) {
  let r = re([]);
  function i(o) {
    return r.value.push(o), () => {
      let a = r.value.indexOf(o);
      a !== -1 && r.value.splice(a, 1);
    };
  }
  return rt(Vu, { register: i, slot: e, name: t, props: n }), $(() => r.value.length > 0 ? r.value.join(" ") : void 0);
}
let $1 = de({ name: "Label", props: { as: { type: [Object, String], default: "label" }, passive: { type: [Boolean], default: !1 }, id: { type: String, default: () => `headlessui-label-${St()}` } }, setup(e, { slots: t, attrs: n }) {
  let r = ju();
  return ze(() => Ze(r.register(e.id))), () => {
    let { name: i = "Label", slot: o = {}, props: a = {} } = r, { id: s, passive: l, ...c } = e, u = { ...Object.entries(a).reduce((f, [d, m]) => Object.assign(f, { [d]: Ja(m) }), {}), id: s };
    return l && (delete u.onClick, delete u.htmlFor, delete c.onClick), We({ ourProps: u, theirProps: c, slot: o, attrs: n, slots: t, name: i });
  };
} });
function F1(e, t) {
  return e === t;
}
let Hu = Symbol("RadioGroupContext");
function Bu(e) {
  let t = Ve(Hu, null);
  if (t === null) {
    let n = new Error(`<${e} /> is missing a parent <RadioGroup /> component.`);
    throw Error.captureStackTrace && Error.captureStackTrace(n, Bu), n;
  }
  return t;
}
let Gu = de({ name: "RadioGroup", emits: { "update:modelValue": (e) => !0 }, props: { as: { type: [Object, String], default: "div" }, disabled: { type: [Boolean], default: !1 }, by: { type: [String, Function], default: () => F1 }, modelValue: { type: [Object, String, Number, Boolean], default: void 0 }, defaultValue: { type: [Object, String, Number, Boolean], default: void 0 }, form: { type: String, optional: !0 }, name: { type: String, optional: !0 }, id: { type: String, default: () => `headlessui-radiogroup-${St()}` } }, inheritAttrs: !1, setup(e, { emit: t, attrs: n, slots: r, expose: i }) {
  let o = re(null), a = re([]), s = Uu({ name: "RadioGroupLabel" }), l = ls({ name: "RadioGroupDescription" });
  i({ el: o, $el: o });
  let [c, u] = o1($(() => e.modelValue), (p) => t("update:modelValue", p), $(() => e.defaultValue)), f = { options: a, value: c, disabled: $(() => e.disabled), firstOption: $(() => a.value.find((p) => !p.propsRef.disabled)), containsCheckedOption: $(() => a.value.some((p) => f.compare(se(p.propsRef.value), se(e.modelValue)))), compare(p, h) {
    if (typeof e.by == "string") {
      let _ = e.by;
      return (p == null ? void 0 : p[_]) === (h == null ? void 0 : h[_]);
    }
    return e.by(p, h);
  }, change(p) {
    var h;
    if (e.disabled || f.compare(se(c.value), se(p)))
      return !1;
    let _ = (h = a.value.find((y) => f.compare(se(y.propsRef.value), se(p)))) == null ? void 0 : h.propsRef;
    return _ != null && _.disabled ? !1 : (u(p), !0);
  }, registerOption(p) {
    a.value.push(p), a.value = xu(a.value, (h) => h.element);
  }, unregisterOption(p) {
    let h = a.value.findIndex((_) => _.id === p);
    h !== -1 && a.value.splice(h, 1);
  } };
  rt(Hu, f), Xp({ container: $(() => he(o)), accept(p) {
    return p.getAttribute("role") === "radio" ? NodeFilter.FILTER_REJECT : p.hasAttribute("role") ? NodeFilter.FILTER_SKIP : NodeFilter.FILTER_ACCEPT;
  }, walk(p) {
    p.setAttribute("role", "none");
  } });
  function d(p) {
    if (!o.value || !o.value.contains(p.target))
      return;
    let h = a.value.filter((_) => _.propsRef.disabled === !1).map((_) => _.element);
    switch (p.key) {
      case ct.Enter:
        i1(p.currentTarget);
        break;
      case ct.ArrowLeft:
      case ct.ArrowUp:
        if (p.preventDefault(), p.stopPropagation(), Hn(h, mt.Previous | mt.WrapAround) === Bi.Success) {
          let _ = a.value.find((y) => {
            var g;
            return y.element === ((g = Pt(o)) == null ? void 0 : g.activeElement);
          });
          _ && f.change(_.propsRef.value);
        }
        break;
      case ct.ArrowRight:
      case ct.ArrowDown:
        if (p.preventDefault(), p.stopPropagation(), Hn(h, mt.Next | mt.WrapAround) === Bi.Success) {
          let _ = a.value.find((y) => {
            var g;
            return y.element === ((g = Pt(y.element)) == null ? void 0 : g.activeElement);
          });
          _ && f.change(_.propsRef.value);
        }
        break;
      case ct.Space:
        {
          p.preventDefault(), p.stopPropagation();
          let _ = a.value.find((y) => {
            var g;
            return y.element === ((g = Pt(y.element)) == null ? void 0 : g.activeElement);
          });
          _ && f.change(_.propsRef.value);
        }
        break;
    }
  }
  let m = $(() => {
    var p;
    return (p = he(o)) == null ? void 0 : p.closest("form");
  });
  return ze(() => {
    bt([m], () => {
      if (!m.value || e.defaultValue === void 0)
        return;
      function p() {
        f.change(e.defaultValue);
      }
      return m.value.addEventListener("reset", p), () => {
        var h;
        (h = m.value) == null || h.removeEventListener("reset", p);
      };
    }, { immediate: !0 });
  }), () => {
    let { disabled: p, name: h, id: _, form: y, ...g } = e, w = { ref: o, id: _, role: "radiogroup", "aria-labelledby": s.value, "aria-describedby": l.value, onKeydown: d };
    return He(De, [...h != null && c.value != null ? ku({ [h]: c.value }).map(([x, I]) => He(Gi, jp({ features: Vr.Hidden, key: x, as: "input", type: "hidden", hidden: !0, readOnly: !0, form: y, name: x, value: I }))) : [], We({ ourProps: w, theirProps: { ...n, ...ss(g, ["modelValue", "defaultValue", "by"]) }, slot: {}, attrs: n, slots: r, name: "RadioGroup" })]);
  };
} });
var V1 = ((e) => (e[e.Empty = 1] = "Empty", e[e.Active = 2] = "Active", e))(V1 || {});
let Yu = de({ name: "RadioGroupOption", props: { as: { type: [Object, String], default: "div" }, value: { type: [Object, String, Number, Boolean] }, disabled: { type: Boolean, default: !1 }, id: { type: String, default: () => `headlessui-radiogroup-option-${St()}` } }, setup(e, { attrs: t, slots: n, expose: r }) {
  let i = Bu("RadioGroupOption"), o = Uu({ name: "RadioGroupLabel" }), a = ls({ name: "RadioGroupDescription" }), s = re(null), l = $(() => ({ value: e.value, disabled: e.disabled })), c = re(1);
  r({ el: s, $el: s });
  let u = $(() => he(s));
  ze(() => i.registerOption({ id: e.id, element: u, propsRef: l })), Ze(() => i.unregisterOption(e.id));
  let f = $(() => {
    var g;
    return ((g = i.firstOption.value) == null ? void 0 : g.id) === e.id;
  }), d = $(() => i.disabled.value || e.disabled), m = $(() => i.compare(se(i.value.value), se(e.value))), p = $(() => d.value ? -1 : m.value || !i.containsCheckedOption.value && f.value ? 0 : -1);
  function h() {
    var g;
    i.change(e.value) && (c.value |= 2, (g = he(s)) == null || g.focus());
  }
  function _() {
    c.value |= 2;
  }
  function y() {
    c.value &= -3;
  }
  return () => {
    let { id: g, value: w, disabled: x, ...I } = e, U = { checked: m.value, disabled: d.value, active: !!(c.value & 2) }, M = { id: g, ref: s, role: "radio", "aria-checked": m.value ? "true" : "false", "aria-labelledby": o.value, "aria-describedby": a.value, "aria-disabled": d.value ? !0 : void 0, tabIndex: p.value, onClick: d.value ? void 0 : h, onFocus: d.value ? void 0 : _, onBlur: d.value ? void 0 : y };
    return We({ ourProps: M, theirProps: I, slot: U, attrs: t, slots: n, name: "RadioGroupOption" });
  };
} }), Wu = $1, qu = zu;
function j1(e) {
  let t = { called: !1 };
  return (...n) => {
    if (!t.called)
      return t.called = !0, e(...n);
  };
}
function Yo(e, ...t) {
  e && t.length > 0 && e.classList.add(...t);
}
function mi(e, ...t) {
  e && t.length > 0 && e.classList.remove(...t);
}
var _a = ((e) => (e.Finished = "finished", e.Cancelled = "cancelled", e))(_a || {});
function U1(e, t) {
  let n = ho();
  if (!e)
    return n.dispose;
  let { transitionDuration: r, transitionDelay: i } = getComputedStyle(e), [o, a] = [r, i].map((s) => {
    let [l = 0] = s.split(",").filter(Boolean).map((c) => c.includes("ms") ? parseFloat(c) : parseFloat(c) * 1e3).sort((c, u) => u - c);
    return l;
  });
  return o !== 0 ? n.setTimeout(() => t("finished"), o + a) : t("finished"), n.add(() => t("cancelled")), n.dispose;
}
function Cl(e, t, n, r, i, o) {
  let a = ho(), s = o !== void 0 ? j1(o) : () => {
  };
  return mi(e, ...i), Yo(e, ...t, ...n), a.nextFrame(() => {
    mi(e, ...n), Yo(e, ...r), a.add(U1(e, (l) => (mi(e, ...r, ...t), Yo(e, ...i), s(l))));
  }), a.add(() => mi(e, ...t, ...n, ...r, ...i)), a.add(() => s("cancelled")), a.dispose;
}
function mn(e = "") {
  return e.split(" ").filter((t) => t.trim().length > 1);
}
let us = Symbol("TransitionContext");
var H1 = ((e) => (e.Visible = "visible", e.Hidden = "hidden", e))(H1 || {});
function B1() {
  return Ve(us, null) !== null;
}
function G1() {
  let e = Ve(us, null);
  if (e === null)
    throw new Error("A <TransitionChild /> is used but it is missing a parent <TransitionRoot />.");
  return e;
}
function Y1() {
  let e = Ve(ds, null);
  if (e === null)
    throw new Error("A <TransitionChild /> is used but it is missing a parent <TransitionRoot />.");
  return e;
}
let ds = Symbol("NestingContext");
function go(e) {
  return "children" in e ? go(e.children) : e.value.filter(({ state: t }) => t === "visible").length > 0;
}
function Ku(e) {
  let t = re([]), n = re(!1);
  ze(() => n.value = !0), Ze(() => n.value = !1);
  function r(o, a = Zt.Hidden) {
    let s = t.value.findIndex(({ id: l }) => l === o);
    s !== -1 && (vt(a, { [Zt.Unmount]() {
      t.value.splice(s, 1);
    }, [Zt.Hidden]() {
      t.value[s].state = "hidden";
    } }), !go(t) && n.value && (e == null || e()));
  }
  function i(o) {
    let a = t.value.find(({ id: s }) => s === o);
    return a ? a.state !== "visible" && (a.state = "visible") : t.value.push({ id: o, state: "visible" }), () => r(o, Zt.Unmount);
  }
  return { children: t, register: i, unregister: r };
}
let Xu = Kn.RenderStrategy, Ju = de({ props: { as: { type: [Object, String], default: "div" }, show: { type: [Boolean], default: null }, unmount: { type: [Boolean], default: !0 }, appear: { type: [Boolean], default: !1 }, enter: { type: [String], default: "" }, enterFrom: { type: [String], default: "" }, enterTo: { type: [String], default: "" }, entered: { type: [String], default: "" }, leave: { type: [String], default: "" }, leaveFrom: { type: [String], default: "" }, leaveTo: { type: [String], default: "" } }, emits: { beforeEnter: () => !0, afterEnter: () => !0, beforeLeave: () => !0, afterLeave: () => !0 }, setup(e, { emit: t, attrs: n, slots: r, expose: i }) {
  let o = re(0);
  function a() {
    o.value |= Xe.Opening, t("beforeEnter");
  }
  function s() {
    o.value &= ~Xe.Opening, t("afterEnter");
  }
  function l() {
    o.value |= Xe.Closing, t("beforeLeave");
  }
  function c() {
    o.value &= ~Xe.Closing, t("afterLeave");
  }
  if (!B1() && Gp())
    return () => He(Qu, { ...e, onBeforeEnter: a, onAfterEnter: s, onBeforeLeave: l, onAfterLeave: c }, r);
  let u = re(null), f = $(() => e.unmount ? Zt.Unmount : Zt.Hidden);
  i({ el: u, $el: u });
  let { show: d, appear: m } = G1(), { register: p, unregister: h } = Y1(), _ = re(d.value ? "visible" : "hidden"), y = { value: !0 }, g = St(), w = { value: !1 }, x = Ku(() => {
    !w.value && _.value !== "hidden" && (_.value = "hidden", h(g), c());
  });
  ze(() => {
    let X = p(g);
    Ze(X);
  }), st(() => {
    if (f.value === Zt.Hidden && g) {
      if (d.value && _.value !== "visible") {
        _.value = "visible";
        return;
      }
      vt(_.value, { hidden: () => h(g), visible: () => p(g) });
    }
  });
  let I = mn(e.enter), U = mn(e.enterFrom), M = mn(e.enterTo), C = mn(e.entered), R = mn(e.leave), W = mn(e.leaveFrom), F = mn(e.leaveTo);
  ze(() => {
    st(() => {
      if (_.value === "visible") {
        let X = he(u);
        if (X instanceof Comment && X.data === "")
          throw new Error("Did you forget to passthrough the `ref` to the actual DOM node?");
      }
    });
  });
  function A(X) {
    let ce = y.value && !m.value, Ce = he(u);
    !Ce || !(Ce instanceof HTMLElement) || ce || (w.value = !0, d.value && a(), d.value || l(), X(d.value ? Cl(Ce, I, U, M, C, (J) => {
      w.value = !1, J === _a.Finished && s();
    }) : Cl(Ce, R, W, F, C, (J) => {
      w.value = !1, J === _a.Finished && (go(x) || (_.value = "hidden", h(g), c()));
    })));
  }
  return ze(() => {
    bt([d], (X, ce, Ce) => {
      A(Ce), y.value = !1;
    }, { immediate: !0 });
  }), rt(ds, x), _u($(() => vt(_.value, { visible: Xe.Open, hidden: Xe.Closed }) | o.value)), () => {
    let { appear: X, show: ce, enter: Ce, enterFrom: J, enterTo: V, entered: G, leave: me, leaveFrom: Ue, leaveTo: Te, ...Me } = e, Nn = { ref: u }, tt = { ...Me, ...m.value && d.value && Jr.isServer ? { class: _e([n.class, Me.class, ...I, ...U]) } : {} };
    return We({ theirProps: tt, ourProps: Nn, slot: {}, slots: r, attrs: n, features: Xu, visible: _.value === "visible", name: "TransitionChild" });
  };
} }), W1 = Ju, Qu = de({ inheritAttrs: !1, props: { as: { type: [Object, String], default: "div" }, show: { type: [Boolean], default: null }, unmount: { type: [Boolean], default: !0 }, appear: { type: [Boolean], default: !1 }, enter: { type: [String], default: "" }, enterFrom: { type: [String], default: "" }, enterTo: { type: [String], default: "" }, entered: { type: [String], default: "" }, leave: { type: [String], default: "" }, leaveFrom: { type: [String], default: "" }, leaveTo: { type: [String], default: "" } }, emits: { beforeEnter: () => !0, afterEnter: () => !0, beforeLeave: () => !0, afterLeave: () => !0 }, setup(e, { emit: t, attrs: n, slots: r }) {
  let i = bo(), o = $(() => e.show === null && i !== null ? (i.value & Xe.Open) === Xe.Open : e.show);
  st(() => {
    if (![!0, !1].includes(o.value))
      throw new Error('A <Transition /> is used but it is missing a `:show="true | false"` prop.');
  });
  let a = re(o.value ? "visible" : "hidden"), s = Ku(() => {
    a.value = "hidden";
  }), l = re(!0), c = { show: o, appear: $(() => e.appear || !l.value) };
  return ze(() => {
    st(() => {
      l.value = !1, o.value ? a.value = "visible" : go(s) || (a.value = "hidden");
    });
  }), rt(ds, s), rt(us, c), () => {
    let u = ss(e, ["show", "appear", "unmount", "onBeforeEnter", "onBeforeLeave", "onAfterEnter", "onAfterLeave"]), f = { unmount: e.unmount };
    return We({ ourProps: { ...f, as: "template" }, theirProps: {}, slot: {}, slots: { ...r, default: () => [He(W1, { onBeforeEnter: () => t("beforeEnter"), onAfterEnter: () => t("afterEnter"), onBeforeLeave: () => t("beforeLeave"), onAfterLeave: () => t("afterLeave"), ...n, ...f, ...u }, r.default)] }, attrs: {}, features: Xu, visible: a.value === "visible", name: "Transition" });
  };
} });
function Tl() {
  const { state: e, send: t } = ut();
  document.querySelectorAll("button[data-sell-store][data-sell-product]").forEach((n) => {
    n.addEventListener("click", () => {
      var f, d, m, p, h, _;
      if (!e.value.matches("closed"))
        return;
      const r = n.attributes["data-sell-store"].value, i = n.attributes["data-sell-product"].value, o = (f = n.attributes["data-sell-variant"]) == null ? void 0 : f.value, a = (d = n.attributes["data-sell-coupon"]) == null ? void 0 : d.value, s = (m = n.attributes["data-sell-quantity"]) == null ? void 0 : m.value, l = (p = n.attributes["data-sell-email"]) == null ? void 0 : p.value, c = ((h = n.attributes["data-sell-darkmode"]) == null ? void 0 : h.value) === "true", u = (_ = n.attributes["data-sell-theme"]) == null ? void 0 : _.value;
      t({
        type: "OPEN",
        store_id: r,
        product_id: i,
        variant_id: o,
        coupon: a,
        quantity: s,
        email: l,
        customization: {
          darkMode: c,
          theme: u
        }
      });
    });
  });
}
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
var T = function() {
  return T = Object.assign || function(t) {
    for (var n, r = 1, i = arguments.length; r < i; r++) {
      n = arguments[r];
      for (var o in n)
        Object.prototype.hasOwnProperty.call(n, o) && (t[o] = n[o]);
    }
    return t;
  }, T.apply(this, arguments);
};
function fs(e, t) {
  var n = {};
  for (var r in e)
    Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
  if (e != null && typeof Object.getOwnPropertySymbols == "function")
    for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
      t.indexOf(r[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[i]) && (n[r[i]] = e[r[i]]);
  return n;
}
function ue(e) {
  var t = typeof Symbol == "function" && Symbol.iterator, n = t && e[t], r = 0;
  if (n)
    return n.call(e);
  if (e && typeof e.length == "number")
    return {
      next: function() {
        return e && r >= e.length && (e = void 0), { value: e && e[r++], done: !e };
      }
    };
  throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.");
}
function pe(e, t) {
  var n = typeof Symbol == "function" && e[Symbol.iterator];
  if (!n)
    return e;
  var r = n.call(e), i, o = [], a;
  try {
    for (; (t === void 0 || t-- > 0) && !(i = r.next()).done; )
      o.push(i.value);
  } catch (s) {
    a = { error: s };
  } finally {
    try {
      i && !i.done && (n = r.return) && n.call(r);
    } finally {
      if (a)
        throw a.error;
    }
  }
  return o;
}
function Oe(e, t, n) {
  if (n || arguments.length === 2)
    for (var r = 0, i = t.length, o; r < i; r++)
      (o || !(r in t)) && (o || (o = Array.prototype.slice.call(t, 0, r)), o[r] = t[r]);
  return e.concat(o || Array.prototype.slice.call(t));
}
var ge;
(function(e) {
  e.Start = "xstate.start", e.Stop = "xstate.stop", e.Raise = "xstate.raise", e.Send = "xstate.send", e.Cancel = "xstate.cancel", e.NullEvent = "", e.Assign = "xstate.assign", e.After = "xstate.after", e.DoneState = "done.state", e.DoneInvoke = "done.invoke", e.Log = "xstate.log", e.Init = "xstate.init", e.Invoke = "xstate.invoke", e.ErrorExecution = "error.execution", e.ErrorCommunication = "error.communication", e.ErrorPlatform = "error.platform", e.ErrorCustom = "xstate.error", e.Update = "xstate.update", e.Pure = "xstate.pure", e.Choose = "xstate.choose";
})(ge || (ge = {}));
var rn;
(function(e) {
  e.Parent = "#_parent", e.Internal = "#_internal";
})(rn || (rn = {}));
var Yi = ge.Start, yo = ge.Stop, or = ge.Raise, Qr = ge.Send, ms = ge.Cancel, Zu = ge.NullEvent, _o = ge.Assign, q1 = ge.After, K1 = ge.DoneState, wo = ge.Log, ed = ge.Init, Wi = ge.Invoke, X1 = ge.ErrorExecution, wa = ge.ErrorPlatform, ps = ge.ErrorCustom, xo = ge.Update, td = ge.Choose, nd = ge.Pure;
const J1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  after: q1,
  assign: _o,
  cancel: ms,
  choose: td,
  doneState: K1,
  error: ps,
  errorExecution: X1,
  errorPlatform: wa,
  init: ed,
  invoke: Wi,
  log: wo,
  nullEvent: Zu,
  pure: nd,
  raise: or,
  send: Qr,
  start: Yi,
  stop: yo,
  update: xo
}, Symbol.toStringTag, { value: "Module" }));
var rd = ".", Pl = {}, xa = "xstate.guard", Q1 = "", pi;
function bs(e, t, n) {
  n === void 0 && (n = rd);
  var r = Ar(e, n), i = Ar(t, n);
  return ve(i) ? ve(r) ? i === r : !1 : ve(r) ? r in i : Object.keys(r).every(function(o) {
    return o in i ? bs(r[o], i[o]) : !1;
  });
}
function id(e) {
  try {
    return ve(e) || typeof e == "number" ? "".concat(e) : e.type;
  } catch {
    throw new Error("Events must be strings or objects with a string event.type property.");
  }
}
function Ea(e, t) {
  try {
    return ar(e) ? e : e.toString().split(t);
  } catch {
    throw new Error("'".concat(e, "' is not a valid state path."));
  }
}
function Z1(e) {
  return typeof e == "object" && "value" in e && "context" in e && "event" in e && "_event" in e;
}
function Ar(e, t) {
  if (Z1(e))
    return e.value;
  if (ar(e))
    return qi(e);
  if (typeof e != "string")
    return e;
  var n = Ea(e, t);
  return qi(n);
}
function qi(e) {
  if (e.length === 1)
    return e[0];
  for (var t = {}, n = t, r = 0; r < e.length - 1; r++)
    r === e.length - 2 ? n[e[r]] = e[r + 1] : (n[e[r]] = {}, n = n[e[r]]);
  return t;
}
function vr(e, t) {
  for (var n = {}, r = Object.keys(e), i = 0; i < r.length; i++) {
    var o = r[i];
    n[o] = t(e[o], o, e, i);
  }
  return n;
}
function Ml(e, t, n) {
  var r, i, o = {};
  try {
    for (var a = ue(Object.keys(e)), s = a.next(); !s.done; s = a.next()) {
      var l = s.value, c = e[l];
      n(c) && (o[l] = t(c, l, e));
    }
  } catch (u) {
    r = {
      error: u
    };
  } finally {
    try {
      s && !s.done && (i = a.return) && i.call(a);
    } finally {
      if (r)
        throw r.error;
    }
  }
  return o;
}
var eb = function(e) {
  return function(t) {
    var n, r, i = t;
    try {
      for (var o = ue(e), a = o.next(); !a.done; a = o.next()) {
        var s = a.value;
        i = i[s];
      }
    } catch (l) {
      n = {
        error: l
      };
    } finally {
      try {
        a && !a.done && (r = o.return) && r.call(o);
      } finally {
        if (n)
          throw n.error;
      }
    }
    return i;
  };
};
function tb(e, t) {
  return function(n) {
    var r, i, o = n;
    try {
      for (var a = ue(e), s = a.next(); !s.done; s = a.next()) {
        var l = s.value;
        o = o[t][l];
      }
    } catch (c) {
      r = {
        error: c
      };
    } finally {
      try {
        s && !s.done && (i = a.return) && i.call(a);
      } finally {
        if (r)
          throw r.error;
      }
    }
    return o;
  };
}
function Ci(e) {
  if (!e)
    return [[]];
  if (ve(e))
    return [[e]];
  var t = Pe(Object.keys(e).map(function(n) {
    var r = e[n];
    return typeof r != "string" && (!r || !Object.keys(r).length) ? [[n]] : Ci(e[n]).map(function(i) {
      return [n].concat(i);
    });
  }));
  return t;
}
function Pe(e) {
  var t;
  return (t = []).concat.apply(t, Oe([], pe(e), !1));
}
function od(e) {
  return ar(e) ? e : [e];
}
function _t(e) {
  return e === void 0 ? [] : od(e);
}
function Ki(e, t, n) {
  var r, i;
  if (be(e))
    return e(t, n.data);
  var o = {};
  try {
    for (var a = ue(Object.keys(e)), s = a.next(); !s.done; s = a.next()) {
      var l = s.value, c = e[l];
      be(c) ? o[l] = c(t, n.data) : o[l] = c;
    }
  } catch (u) {
    r = {
      error: u
    };
  } finally {
    try {
      s && !s.done && (i = a.return) && i.call(a);
    } finally {
      if (r)
        throw r.error;
    }
  }
  return o;
}
function nb(e) {
  return /^(done|error)\./.test(e);
}
function Rl(e) {
  return !!(e instanceof Promise || e !== null && (be(e) || typeof e == "object") && be(e.then));
}
function rb(e) {
  return e !== null && typeof e == "object" && "transition" in e && typeof e.transition == "function";
}
function ib(e, t) {
  var n, r, i = pe([[], []], 2), o = i[0], a = i[1];
  try {
    for (var s = ue(e), l = s.next(); !l.done; l = s.next()) {
      var c = l.value;
      t(c) ? o.push(c) : a.push(c);
    }
  } catch (u) {
    n = {
      error: u
    };
  } finally {
    try {
      l && !l.done && (r = s.return) && r.call(s);
    } finally {
      if (n)
        throw n.error;
    }
  }
  return [o, a];
}
function ad(e, t) {
  return vr(e.states, function(n, r) {
    if (n) {
      var i = (ve(t) ? void 0 : t[r]) || (n ? n.current : void 0);
      if (i)
        return {
          current: i,
          states: ad(n, i)
        };
    }
  });
}
function ob(e, t) {
  return {
    current: t,
    states: ad(e, t)
  };
}
function Dl(e, t, n, r) {
  var i = e && n.reduce(function(o, a) {
    var s, l, c = a.assignment, u = {
      state: r,
      action: a,
      _event: t
    }, f = {};
    if (be(c))
      f = c(o, t.data, u);
    else
      try {
        for (var d = ue(Object.keys(c)), m = d.next(); !m.done; m = d.next()) {
          var p = m.value, h = c[p];
          f[p] = be(h) ? h(o, t.data, u) : h;
        }
      } catch (_) {
        s = {
          error: _
        };
      } finally {
        try {
          m && !m.done && (l = d.return) && l.call(d);
        } finally {
          if (s)
            throw s.error;
        }
      }
    return Object.assign({}, o, f);
  }, e);
  return i;
}
var ab = function() {
};
function ar(e) {
  return Array.isArray(e);
}
function be(e) {
  return typeof e == "function";
}
function ve(e) {
  return typeof e == "string";
}
function sd(e, t) {
  if (e)
    return ve(e) ? {
      type: xa,
      name: e,
      predicate: t ? t[e] : void 0
    } : be(e) ? {
      type: xa,
      name: e.name,
      predicate: e
    } : e;
}
function sb(e) {
  try {
    return "subscribe" in e && be(e.subscribe);
  } catch {
    return !1;
  }
}
var Qt = /* @__PURE__ */ function() {
  return typeof Symbol == "function" && Symbol.observable || "@@observable";
}();
pi = {}, pi[Qt] = function() {
  return this;
}, pi[Symbol.observable] = function() {
  return this;
};
function Xn(e) {
  return !!e && "__xstatenode" in e;
}
function lb(e) {
  return !!e && typeof e.send == "function";
}
function Eo(e, t) {
  return ve(e) || typeof e == "number" ? T({
    type: e
  }, t) : e;
}
function Ke(e, t) {
  if (!ve(e) && "$$type" in e && e.$$type === "scxml")
    return e;
  var n = Eo(e);
  return T({
    name: n.type,
    data: n,
    $$type: "scxml",
    type: "external"
  }, t);
}
function Pn(e, t) {
  var n = od(t).map(function(r) {
    return typeof r > "u" || typeof r == "string" || Xn(r) ? {
      target: r,
      event: e
    } : T(T({}, r), {
      event: e
    });
  });
  return n;
}
function cb(e) {
  if (!(e === void 0 || e === Q1))
    return _t(e);
}
function ld(e, t, n, r, i) {
  var o = e.options.guards, a = {
    state: i,
    cond: t,
    _event: r
  };
  if (t.type === xa)
    return ((o == null ? void 0 : o[t.name]) || t.predicate)(n, r.data, a);
  var s = o == null ? void 0 : o[t.type];
  if (!s)
    throw new Error("Guard '".concat(t.type, "' is not implemented on machine '").concat(e.id, "'."));
  return s(n, r.data, a);
}
function cd(e) {
  return typeof e == "string" ? {
    type: e
  } : e;
}
function Ti(e, t, n) {
  var r = function() {
  }, i = typeof e == "object", o = i ? e : null;
  return {
    next: ((i ? e.next : e) || r).bind(o),
    error: ((i ? e.error : t) || r).bind(o),
    complete: ((i ? e.complete : n) || r).bind(o)
  };
}
function bi(e, t) {
  return "".concat(e, ":invocation[").concat(t, "]");
}
function ka(e) {
  return (e.type === or || e.type === Qr && e.to === rn.Internal) && typeof e.delay != "number";
}
var Sn = /* @__PURE__ */ Ke({
  type: ed
});
function Xi(e, t) {
  return t && t[e] || void 0;
}
function Jn(e, t) {
  var n;
  if (ve(e) || typeof e == "number") {
    var r = Xi(e, t);
    be(r) ? n = {
      type: e,
      exec: r
    } : r ? n = r : n = {
      type: e,
      exec: void 0
    };
  } else if (be(e))
    n = {
      // Convert action to string if unnamed
      type: e.name || e.toString(),
      exec: e
    };
  else {
    var r = Xi(e.type, t);
    if (be(r))
      n = T(T({}, e), {
        exec: r
      });
    else if (r) {
      var i = r.type || e.type;
      n = T(T(T({}, r), e), {
        type: i
      });
    } else
      n = e;
  }
  return n;
}
var zt = function(e, t) {
  if (!e)
    return [];
  var n = ar(e) ? e : [e];
  return n.map(function(r) {
    return Jn(r, t);
  });
};
function ko(e) {
  var t = Jn(e);
  return T(T({
    id: ve(e) ? e : t.id
  }, t), {
    type: t.type
  });
}
function ud(e, t) {
  return {
    type: or,
    event: typeof e == "function" ? e : Eo(e),
    delay: t ? t.delay : void 0,
    id: t == null ? void 0 : t.id
  };
}
function dd(e, t, n, r) {
  var i = {
    _event: n
  }, o = Ke(be(e.event) ? e.event(t, n.data, i) : e.event), a;
  if (ve(e.delay)) {
    var s = r && r[e.delay];
    a = be(s) ? s(t, n.data, i) : s;
  } else
    a = be(e.delay) ? e.delay(t, n.data, i) : e.delay;
  return T(T({}, e), {
    type: or,
    _event: o,
    delay: a
  });
}
function sr(e, t) {
  return {
    to: t ? t.to : void 0,
    type: Qr,
    event: be(e) ? e : Eo(e),
    delay: t ? t.delay : void 0,
    // TODO: don't auto-generate IDs here like that
    // there is too big chance of the ID collision
    id: t && t.id !== void 0 ? t.id : be(e) ? e.name : id(e)
  };
}
function fd(e, t, n, r) {
  var i = {
    _event: n
  }, o = Ke(be(e.event) ? e.event(t, n.data, i) : e.event), a;
  if (ve(e.delay)) {
    var s = r && r[e.delay];
    a = be(s) ? s(t, n.data, i) : s;
  } else
    a = be(e.delay) ? e.delay(t, n.data, i) : e.delay;
  var l = be(e.to) ? e.to(t, n.data, i) : e.to;
  return T(T({}, e), {
    to: l,
    _event: o,
    event: o.data,
    delay: a
  });
}
function hs(e, t) {
  return sr(e, T(T({}, t), {
    to: rn.Parent
  }));
}
function ub(e, t, n) {
  return sr(t, T(T({}, n), {
    to: e
  }));
}
function db() {
  return hs(xo);
}
function fb(e, t) {
  return sr(e, T(T({}, t), {
    to: function(n, r, i) {
      var o = i._event;
      return o.origin;
    }
  }));
}
var mb = function(e, t) {
  return {
    context: e,
    event: t
  };
};
function pb(e, t) {
  return e === void 0 && (e = mb), {
    type: wo,
    label: t,
    expr: e
  };
}
var md = function(e, t, n) {
  return T(T({}, e), {
    value: ve(e.expr) ? e.expr : e.expr(t, n.data, {
      _event: n
    })
  });
}, pd = function(e) {
  return {
    type: ms,
    sendId: e
  };
};
function bd(e) {
  var t = ko(e);
  return {
    type: ge.Start,
    activity: t,
    exec: void 0
  };
}
function hd(e) {
  var t = be(e) ? e : ko(e);
  return {
    type: ge.Stop,
    activity: t,
    exec: void 0
  };
}
function vd(e, t, n) {
  var r = be(e.activity) ? e.activity(t, n.data) : e.activity, i = typeof r == "string" ? {
    id: r
  } : r, o = {
    type: ge.Stop,
    activity: i
  };
  return o;
}
var gd = function(e) {
  return {
    type: _o,
    assignment: e
  };
};
function bb(e) {
  return typeof e == "object" && "type" in e;
}
function yd(e, t) {
  var n = t ? "#".concat(t) : "";
  return "".concat(ge.After, "(").concat(e, ")").concat(n);
}
function gr(e, t) {
  var n = "".concat(ge.DoneState, ".").concat(e), r = {
    type: n,
    data: t
  };
  return r.toString = function() {
    return n;
  }, r;
}
function Nr(e, t) {
  var n = "".concat(ge.DoneInvoke, ".").concat(e), r = {
    type: n,
    data: t
  };
  return r.toString = function() {
    return n;
  }, r;
}
function zn(e, t) {
  var n = "".concat(ge.ErrorPlatform, ".").concat(e), r = {
    type: n,
    data: t
  };
  return r.toString = function() {
    return n;
  }, r;
}
function hb(e) {
  return {
    type: ge.Pure,
    get: e
  };
}
function vb(e, t) {
  return sr(function(n, r) {
    return r;
  }, T(T({}, t), {
    to: e
  }));
}
function gb(e, t) {
  return hs(function(n, r, i) {
    return {
      type: ps,
      data: be(e) ? e(n, r, i) : e
    };
  }, T(T({}, t), {
    to: rn.Parent
  }));
}
function yb(e) {
  return {
    type: ge.Choose,
    conds: e
  };
}
var _b = function(e) {
  var t, n, r = [];
  try {
    for (var i = ue(e), o = i.next(); !o.done; o = i.next())
      for (var a = o.value, s = 0; s < a.actions.length; ) {
        if (a.actions[s].type === _o) {
          r.push(a.actions[s]), a.actions.splice(s, 1);
          continue;
        }
        s++;
      }
  } catch (l) {
    t = {
      error: l
    };
  } finally {
    try {
      o && !o.done && (n = i.return) && n.call(i);
    } finally {
      if (t)
        throw t.error;
    }
  }
  return r;
};
function jr(e, t, n, r, i, o, a) {
  a === void 0 && (a = !1);
  var s = a ? [] : _b(i), l = s.length ? Dl(n, r, s, t) : n, c = a ? [n] : void 0, u = [];
  function f(p, h) {
    var _;
    switch (h.type) {
      case or: {
        var y = dd(h, l, r, e.options.delays);
        return o && typeof y.delay == "number" && o(y, l, r), y;
      }
      case Qr:
        var g = fd(h, l, r, e.options.delays);
        return o && g.to !== rn.Internal && (p === "entry" ? u.push(g) : o(g, l, r)), g;
      case wo: {
        var w = md(h, l, r);
        return o == null || o(w, l, r), w;
      }
      case td: {
        var x = h, I = (_ = x.conds.find(function(J) {
          var V = sd(J.cond, e.options.guards);
          return !V || ld(e, V, l, r, o ? void 0 : t);
        })) === null || _ === void 0 ? void 0 : _.actions;
        if (!I)
          return [];
        var U = pe(jr(e, t, l, r, [{
          type: p,
          actions: zt(_t(I), e.options.actions)
        }], o, a), 2), M = U[0], C = U[1];
        return l = C, c == null || c.push(l), M;
      }
      case nd: {
        var I = h.get(l, r.data);
        if (!I)
          return [];
        var R = pe(jr(e, t, l, r, [{
          type: p,
          actions: zt(_t(I), e.options.actions)
        }], o, a), 2), W = R[0], F = R[1];
        return l = F, c == null || c.push(l), W;
      }
      case yo: {
        var w = vd(h, l, r);
        return o == null || o(w, n, r), w;
      }
      case _o: {
        l = Dl(l, r, [h], o ? void 0 : t), c == null || c.push(l);
        break;
      }
      default:
        var A = Jn(h, e.options.actions), X = A.exec;
        if (o)
          o(A, l, r);
        else if (X && c) {
          var ce = c.length - 1, Ce = T(T({}, A), {
            exec: function(J) {
              for (var V = [], G = 1; G < arguments.length; G++)
                V[G - 1] = arguments[G];
              X.apply(void 0, Oe([c[ce]], pe(V), !1));
            }
          });
          A = Ce;
        }
        return A;
    }
  }
  function d(p) {
    var h, _, y = [];
    try {
      for (var g = ue(p.actions), w = g.next(); !w.done; w = g.next()) {
        var x = w.value, I = f(p.type, x);
        I && (y = y.concat(I));
      }
    } catch (U) {
      h = {
        error: U
      };
    } finally {
      try {
        w && !w.done && (_ = g.return) && _.call(g);
      } finally {
        if (h)
          throw h.error;
      }
    }
    return u.forEach(function(U) {
      o(U, l, r);
    }), u.length = 0, y;
  }
  var m = Pe(i.map(d));
  return [m, l];
}
const So = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  actionTypes: J1,
  after: yd,
  assign: gd,
  cancel: pd,
  choose: yb,
  done: gr,
  doneInvoke: Nr,
  error: zn,
  escalate: gb,
  forwardTo: vb,
  getActionFunction: Xi,
  initEvent: Sn,
  isActionObject: bb,
  log: pb,
  pure: hb,
  raise: ud,
  resolveActions: jr,
  resolveLog: md,
  resolveRaise: dd,
  resolveSend: fd,
  resolveStop: vd,
  respond: fb,
  send: sr,
  sendParent: hs,
  sendTo: ub,
  sendUpdate: db,
  start: bd,
  stop: hd,
  toActionObject: Jn,
  toActionObjects: zt,
  toActivityDefinition: ko
}, Symbol.toStringTag, { value: "Module" }));
var zl = [], Dn = function(e, t) {
  zl.push(e);
  var n = t(e);
  return zl.pop(), n;
};
function _d(e) {
  var t;
  return t = {
    id: e,
    send: function() {
    },
    subscribe: function() {
      return {
        unsubscribe: function() {
        }
      };
    },
    getSnapshot: function() {
    },
    toJSON: function() {
      return {
        id: e
      };
    }
  }, t[Qt] = function() {
    return this;
  }, t;
}
function wb(e, t, n, r) {
  var i, o = cd(e.src), a = (i = t == null ? void 0 : t.options.services) === null || i === void 0 ? void 0 : i[o.type], s = e.data ? Ki(e.data, n, r) : void 0, l = a ? wd(a, e.id, s) : _d(e.id);
  return l.meta = e, l;
}
function wd(e, t, n) {
  var r = _d(t);
  if (r.deferred = !0, Xn(e)) {
    var i = r.state = Dn(void 0, function() {
      return (n ? e.withContext(n) : e).initialState;
    });
    r.getSnapshot = function() {
      return i;
    };
  }
  return r;
}
function xb(e) {
  try {
    return typeof e.send == "function";
  } catch {
    return !1;
  }
}
function Eb(e) {
  return xb(e) && "id" in e;
}
function kb(e) {
  var t;
  return T((t = {
    subscribe: function() {
      return {
        unsubscribe: function() {
        }
      };
    },
    id: "anonymous",
    getSnapshot: function() {
    }
  }, t[Qt] = function() {
    return this;
  }, t), e);
}
var Ji = function(e) {
  return e.type === "atomic" || e.type === "final";
};
function xd(e) {
  return Object.keys(e.states).map(function(t) {
    return e.states[t];
  });
}
function Ur(e) {
  return xd(e).filter(function(t) {
    return t.type !== "history";
  });
}
function Ed(e) {
  var t = [e];
  return Ji(e) ? t : t.concat(Pe(Ur(e).map(Ed)));
}
function yr(e, t) {
  var n, r, i, o, a, s, l, c, u = new Set(e), f = Sa(u), d = new Set(t);
  try {
    for (var m = ue(d), p = m.next(); !p.done; p = m.next())
      for (var h = p.value, _ = h.parent; _ && !d.has(_); )
        d.add(_), _ = _.parent;
  } catch (R) {
    n = {
      error: R
    };
  } finally {
    try {
      p && !p.done && (r = m.return) && r.call(m);
    } finally {
      if (n)
        throw n.error;
    }
  }
  var y = Sa(d);
  try {
    for (var g = ue(d), w = g.next(); !w.done; w = g.next()) {
      var h = w.value;
      if (h.type === "compound" && (!y.get(h) || !y.get(h).length))
        f.get(h) ? f.get(h).forEach(function(W) {
          return d.add(W);
        }) : h.initialStateNodes.forEach(function(W) {
          return d.add(W);
        });
      else if (h.type === "parallel")
        try {
          for (var x = (a = void 0, ue(Ur(h))), I = x.next(); !I.done; I = x.next()) {
            var U = I.value;
            d.has(U) || (d.add(U), f.get(U) ? f.get(U).forEach(function(W) {
              return d.add(W);
            }) : U.initialStateNodes.forEach(function(W) {
              return d.add(W);
            }));
          }
        } catch (W) {
          a = {
            error: W
          };
        } finally {
          try {
            I && !I.done && (s = x.return) && s.call(x);
          } finally {
            if (a)
              throw a.error;
          }
        }
    }
  } catch (R) {
    i = {
      error: R
    };
  } finally {
    try {
      w && !w.done && (o = g.return) && o.call(g);
    } finally {
      if (i)
        throw i.error;
    }
  }
  try {
    for (var M = ue(d), C = M.next(); !C.done; C = M.next())
      for (var h = C.value, _ = h.parent; _ && !d.has(_); )
        d.add(_), _ = _.parent;
  } catch (R) {
    l = {
      error: R
    };
  } finally {
    try {
      C && !C.done && (c = M.return) && c.call(M);
    } finally {
      if (l)
        throw l.error;
    }
  }
  return d;
}
function kd(e, t) {
  var n = t.get(e);
  if (!n)
    return {};
  if (e.type === "compound") {
    var r = n[0];
    if (r) {
      if (Ji(r))
        return r.key;
    } else
      return {};
  }
  var i = {};
  return n.forEach(function(o) {
    i[o.key] = kd(o, t);
  }), i;
}
function Sa(e) {
  var t, n, r = /* @__PURE__ */ new Map();
  try {
    for (var i = ue(e), o = i.next(); !o.done; o = i.next()) {
      var a = o.value;
      r.has(a) || r.set(a, []), a.parent && (r.has(a.parent) || r.set(a.parent, []), r.get(a.parent).push(a));
    }
  } catch (s) {
    t = {
      error: s
    };
  } finally {
    try {
      o && !o.done && (n = i.return) && n.call(i);
    } finally {
      if (t)
        throw t.error;
    }
  }
  return r;
}
function Sb(e, t) {
  var n = yr([e], t);
  return kd(e, Sa(n));
}
function _r(e, t) {
  return Array.isArray(e) ? e.some(function(n) {
    return n === t;
  }) : e instanceof Set ? e.has(t) : !1;
}
function Ob(e) {
  return Oe([], pe(new Set(Pe(Oe([], pe(e.map(function(t) {
    return t.ownEvents;
  })), !1)))), !1);
}
function Pi(e, t) {
  return t.type === "compound" ? Ur(t).some(function(n) {
    return n.type === "final" && _r(e, n);
  }) : t.type === "parallel" ? Ur(t).every(function(n) {
    return Pi(e, n);
  }) : !1;
}
function Ab(e) {
  return e === void 0 && (e = []), e.reduce(function(t, n) {
    return n.meta !== void 0 && (t[n.id] = n.meta), t;
  }, {});
}
function Ll(e) {
  return new Set(Pe(e.map(function(t) {
    return t.tags;
  })));
}
function Sd(e, t) {
  if (e === t)
    return !0;
  if (e === void 0 || t === void 0)
    return !1;
  if (ve(e) || ve(t))
    return e === t;
  var n = Object.keys(e), r = Object.keys(t);
  return n.length === r.length && n.every(function(i) {
    return Sd(e[i], t[i]);
  });
}
function Nb(e) {
  return typeof e != "object" || e === null ? !1 : "value" in e && "_event" in e;
}
function Ib(e, t) {
  var n = e.exec, r = T(T({}, e), {
    exec: n !== void 0 ? function() {
      return n(t.context, t.event, {
        action: e,
        state: t,
        _event: t._event
      });
    } : void 0
  });
  return r;
}
var Nt = (
  /** @class */
  /* @__PURE__ */ function() {
    function e(t) {
      var n = this, r;
      this.actions = [], this.activities = Pl, this.meta = {}, this.events = [], this.value = t.value, this.context = t.context, this._event = t._event, this._sessionid = t._sessionid, this.event = this._event.data, this.historyValue = t.historyValue, this.history = t.history, this.actions = t.actions || [], this.activities = t.activities || Pl, this.meta = Ab(t.configuration), this.events = t.events || [], this.matches = this.matches.bind(this), this.toStrings = this.toStrings.bind(this), this.configuration = t.configuration, this.transitions = t.transitions, this.children = t.children, this.done = !!t.done, this.tags = (r = Array.isArray(t.tags) ? new Set(t.tags) : t.tags) !== null && r !== void 0 ? r : /* @__PURE__ */ new Set(), this.machine = t.machine, Object.defineProperty(this, "nextEvents", {
        get: function() {
          return Ob(n.configuration);
        }
      });
    }
    return e.from = function(t, n) {
      if (t instanceof e)
        return t.context !== n ? new e({
          value: t.value,
          context: n,
          _event: t._event,
          _sessionid: null,
          historyValue: t.historyValue,
          history: t.history,
          actions: [],
          activities: t.activities,
          meta: {},
          events: [],
          configuration: [],
          transitions: [],
          children: {}
        }) : t;
      var r = Sn;
      return new e({
        value: t,
        context: n,
        _event: r,
        _sessionid: null,
        historyValue: void 0,
        history: void 0,
        actions: [],
        activities: void 0,
        meta: void 0,
        events: [],
        configuration: [],
        transitions: [],
        children: {}
      });
    }, e.create = function(t) {
      return new e(t);
    }, e.inert = function(t, n) {
      if (t instanceof e) {
        if (!t.actions.length)
          return t;
        var r = Sn;
        return new e({
          value: t.value,
          context: n,
          _event: r,
          _sessionid: null,
          historyValue: t.historyValue,
          history: t.history,
          activities: t.activities,
          configuration: t.configuration,
          transitions: [],
          children: {}
        });
      }
      return e.from(t, n);
    }, e.prototype.toStrings = function(t, n) {
      var r = this;
      if (t === void 0 && (t = this.value), n === void 0 && (n = "."), ve(t))
        return [t];
      var i = Object.keys(t);
      return i.concat.apply(i, Oe([], pe(i.map(function(o) {
        return r.toStrings(t[o], n).map(function(a) {
          return o + n + a;
        });
      })), !1));
    }, e.prototype.toJSON = function() {
      var t = this;
      t.configuration, t.transitions;
      var n = t.tags;
      t.machine;
      var r = fs(t, ["configuration", "transitions", "tags", "machine"]);
      return T(T({}, r), {
        tags: Array.from(n)
      });
    }, e.prototype.matches = function(t) {
      return bs(t, this.value);
    }, e.prototype.hasTag = function(t) {
      return this.tags.has(t);
    }, e.prototype.can = function(t) {
      var n;
      ab(!!this.machine);
      var r = (n = this.machine) === null || n === void 0 ? void 0 : n.getTransitionData(this, t);
      return !!(r != null && r.transitions.length) && // Check that at least one transition is not forbidden
      r.transitions.some(function(i) {
        return i.target !== void 0 || i.actions.length;
      });
    }, e;
  }()
), Cb = {
  deferEvents: !1
}, $l = (
  /** @class */
  /* @__PURE__ */ function() {
    function e(t) {
      this.processingEvent = !1, this.queue = [], this.initialized = !1, this.options = T(T({}, Cb), t);
    }
    return e.prototype.initialize = function(t) {
      if (this.initialized = !0, t) {
        if (!this.options.deferEvents) {
          this.schedule(t);
          return;
        }
        this.process(t);
      }
      this.flushEvents();
    }, e.prototype.schedule = function(t) {
      if (!this.initialized || this.processingEvent) {
        this.queue.push(t);
        return;
      }
      if (this.queue.length !== 0)
        throw new Error("Event queue should be empty when it is not processing events");
      this.process(t), this.flushEvents();
    }, e.prototype.clear = function() {
      this.queue = [];
    }, e.prototype.flushEvents = function() {
      for (var t = this.queue.shift(); t; )
        this.process(t), t = this.queue.shift();
    }, e.prototype.process = function(t) {
      this.processingEvent = !0;
      try {
        t();
      } catch (n) {
        throw this.clear(), n;
      } finally {
        this.processingEvent = !1;
      }
    }, e;
  }()
), Wo = /* @__PURE__ */ new Map(), Tb = 0, mr = {
  bookId: function() {
    return "x:".concat(Tb++);
  },
  register: function(e, t) {
    return Wo.set(e, t), e;
  },
  get: function(e) {
    return Wo.get(e);
  },
  free: function(e) {
    Wo.delete(e);
  }
};
function vs() {
  if (typeof globalThis < "u")
    return globalThis;
  if (typeof self < "u")
    return self;
  if (typeof window < "u")
    return window;
  if (typeof global < "u")
    return global;
}
function Pb() {
  var e = vs();
  if (e && "__xstate__" in e)
    return e.__xstate__;
}
function Mb(e) {
  if (vs()) {
    var t = Pb();
    t && t.register(e);
  }
}
function Rb(e, t) {
  t === void 0 && (t = {});
  var n = e.initialState, r = /* @__PURE__ */ new Set(), i = [], o = !1, a = function() {
    if (!o) {
      for (o = !0; i.length > 0; ) {
        var c = i.shift();
        n = e.transition(n, c, l), r.forEach(function(u) {
          return u.next(n);
        });
      }
      o = !1;
    }
  }, s = kb({
    id: t.id,
    send: function(c) {
      i.push(c), a();
    },
    getSnapshot: function() {
      return n;
    },
    subscribe: function(c, u, f) {
      var d = Ti(c, u, f);
      return r.add(d), d.next(n), {
        unsubscribe: function() {
          r.delete(d);
        }
      };
    }
  }), l = {
    parent: t.parent,
    self: s,
    id: t.id || "anonymous",
    observers: r
  };
  return n = e.start ? e.start(l) : n, s;
}
var Db = {
  sync: !1,
  autoForward: !1
}, Ge;
(function(e) {
  e[e.NotStarted = 0] = "NotStarted", e[e.Running = 1] = "Running", e[e.Stopped = 2] = "Stopped";
})(Ge || (Ge = {}));
var zb = (
  /** @class */
  /* @__PURE__ */ function() {
    function e(t, n) {
      n === void 0 && (n = e.defaultOptions);
      var r = this;
      this.machine = t, this.delayedEventsMap = {}, this.listeners = /* @__PURE__ */ new Set(), this.contextListeners = /* @__PURE__ */ new Set(), this.stopListeners = /* @__PURE__ */ new Set(), this.doneListeners = /* @__PURE__ */ new Set(), this.eventListeners = /* @__PURE__ */ new Set(), this.sendListeners = /* @__PURE__ */ new Set(), this.initialized = !1, this.status = Ge.NotStarted, this.children = /* @__PURE__ */ new Map(), this.forwardTo = /* @__PURE__ */ new Set(), this._outgoingQueue = [], this.init = this.start, this.send = function(u, f) {
        if (ar(u))
          return r.batch(u), r.state;
        var d = Ke(Eo(u, f));
        if (r.status === Ge.Stopped)
          return r.state;
        if (r.status !== Ge.Running && !r.options.deferEvents)
          throw new Error('Event "'.concat(d.name, '" was sent to uninitialized service "').concat(
            r.machine.id,
            `". Make sure .start() is called for this service, or set { deferEvents: true } in the service options.
Event: `
          ).concat(JSON.stringify(d.data)));
        return r.scheduler.schedule(function() {
          r.forward(d);
          var m = r._nextState(d);
          r.update(m, d);
        }), r._state;
      }, this.sendTo = function(u, f, d) {
        var m = r.parent && (f === rn.Parent || r.parent.id === f), p = m ? r.parent : ve(f) ? f === rn.Internal ? r : r.children.get(f) || mr.get(f) : lb(f) ? f : void 0;
        if (!p) {
          if (!m)
            throw new Error("Unable to send event to child '".concat(f, "' from service '").concat(r.id, "'."));
          return;
        }
        if ("machine" in p) {
          if (r.status !== Ge.Stopped || r.parent !== p || // we need to send events to the parent from exit handlers of a machine that reached its final state
          r.state.done) {
            var h = T(T({}, u), {
              name: u.name === ps ? "".concat(zn(r.id)) : u.name,
              origin: r.sessionId
            });
            !d && r.machine.config.predictableActionArguments ? r._outgoingQueue.push([p, h]) : p.send(h);
          }
        } else
          !d && r.machine.config.predictableActionArguments ? r._outgoingQueue.push([p, u.data]) : p.send(u.data);
      }, this._exec = function(u, f, d, m) {
        m === void 0 && (m = r.machine.options.actions);
        var p = u.exec || Xi(u.type, m), h = be(p) ? p : p ? p.exec : u.exec;
        if (h)
          try {
            return h(f, d.data, r.machine.config.predictableActionArguments ? {
              action: u,
              _event: d
            } : {
              action: u,
              state: r.state,
              _event: d
            });
          } catch (ce) {
            throw r.parent && r.parent.send({
              type: "xstate.error",
              data: ce
            }), ce;
          }
        switch (u.type) {
          case or: {
            var _ = u;
            r.defer(_);
            break;
          }
          case Qr:
            var y = u;
            if (typeof y.delay == "number") {
              r.defer(y);
              return;
            } else
              y.to ? r.sendTo(y._event, y.to, d === Sn) : r.send(y._event);
            break;
          case ms:
            r.cancel(u.sendId);
            break;
          case Yi: {
            if (r.status !== Ge.Running)
              return;
            var g = u.activity;
            if (
              // in v4 with `predictableActionArguments` invokes are called eagerly when the `this.state` still points to the previous state
              !r.machine.config.predictableActionArguments && !r.state.activities[g.id || g.type]
            )
              break;
            if (g.type === ge.Invoke) {
              var w = cd(g.src), x = r.machine.options.services ? r.machine.options.services[w.type] : void 0, I = g.id, U = g.data, M = "autoForward" in g ? g.autoForward : !!g.forward;
              if (!x)
                return;
              var C = U ? Ki(U, f, d) : void 0;
              if (typeof x == "string")
                return;
              var R = be(x) ? x(f, d.data, {
                data: C,
                src: w,
                meta: g.meta
              }) : x;
              if (!R)
                return;
              var W = void 0;
              Xn(R) && (R = C ? R.withContext(C) : R, W = {
                autoForward: M
              }), r.spawn(R, I, W);
            } else
              r.spawnActivity(g);
            break;
          }
          case yo: {
            r.stopChild(u.activity.id);
            break;
          }
          case wo:
            var F = u, A = F.label, X = F.value;
            A ? r.logger(A, X) : r.logger(X);
            break;
        }
      };
      var i = T(T({}, e.defaultOptions), n), o = i.clock, a = i.logger, s = i.parent, l = i.id, c = l !== void 0 ? l : t.id;
      this.id = c, this.logger = a, this.clock = o, this.parent = s, this.options = i, this.scheduler = new $l({
        deferEvents: this.options.deferEvents
      }), this.sessionId = mr.bookId();
    }
    return Object.defineProperty(e.prototype, "initialState", {
      get: function() {
        var t = this;
        return this._initialState ? this._initialState : Dn(this, function() {
          return t._initialState = t.machine.initialState, t._initialState;
        });
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(e.prototype, "state", {
      /**
       * @deprecated Use `.getSnapshot()` instead.
       */
      get: function() {
        return this._state;
      },
      enumerable: !1,
      configurable: !0
    }), e.prototype.execute = function(t, n) {
      var r, i;
      try {
        for (var o = ue(t.actions), a = o.next(); !a.done; a = o.next()) {
          var s = a.value;
          this.exec(s, t, n);
        }
      } catch (l) {
        r = {
          error: l
        };
      } finally {
        try {
          a && !a.done && (i = o.return) && i.call(o);
        } finally {
          if (r)
            throw r.error;
        }
      }
    }, e.prototype.update = function(t, n) {
      var r, i, o, a, s, l, c, u, f = this;
      if (t._sessionid = this.sessionId, this._state = t, (!this.machine.config.predictableActionArguments || // this is currently required to execute initial actions as the `initialState` gets cached
      // we can't just recompute it (and execute actions while doing so) because we try to preserve identity of actors created within initial assigns
      n === Sn) && this.options.execute)
        this.execute(this.state);
      else
        for (var d = void 0; d = this._outgoingQueue.shift(); )
          d[0].send(d[1]);
      if (this.children.forEach(function(R) {
        f.state.children[R.id] = R;
      }), this.devTools && this.devTools.send(n.data, t), t.event)
        try {
          for (var m = ue(this.eventListeners), p = m.next(); !p.done; p = m.next()) {
            var h = p.value;
            h(t.event);
          }
        } catch (R) {
          r = {
            error: R
          };
        } finally {
          try {
            p && !p.done && (i = m.return) && i.call(m);
          } finally {
            if (r)
              throw r.error;
          }
        }
      try {
        for (var _ = ue(this.listeners), y = _.next(); !y.done; y = _.next()) {
          var h = y.value;
          h(t, t.event);
        }
      } catch (R) {
        o = {
          error: R
        };
      } finally {
        try {
          y && !y.done && (a = _.return) && a.call(_);
        } finally {
          if (o)
            throw o.error;
        }
      }
      try {
        for (var g = ue(this.contextListeners), w = g.next(); !w.done; w = g.next()) {
          var x = w.value;
          x(this.state.context, this.state.history ? this.state.history.context : void 0);
        }
      } catch (R) {
        s = {
          error: R
        };
      } finally {
        try {
          w && !w.done && (l = g.return) && l.call(g);
        } finally {
          if (s)
            throw s.error;
        }
      }
      if (this.state.done) {
        var I = t.configuration.find(function(R) {
          return R.type === "final" && R.parent === f.machine;
        }), U = I && I.doneData ? Ki(I.doneData, t.context, n) : void 0;
        this._doneEvent = Nr(this.id, U);
        try {
          for (var M = ue(this.doneListeners), C = M.next(); !C.done; C = M.next()) {
            var h = C.value;
            h(this._doneEvent);
          }
        } catch (R) {
          c = {
            error: R
          };
        } finally {
          try {
            C && !C.done && (u = M.return) && u.call(M);
          } finally {
            if (c)
              throw c.error;
          }
        }
        this._stop(), this._stopChildren(), mr.free(this.sessionId);
      }
    }, e.prototype.onTransition = function(t) {
      return this.listeners.add(t), this.status === Ge.Running && t(this.state, this.state.event), this;
    }, e.prototype.subscribe = function(t, n, r) {
      var i = this, o = Ti(t, n, r);
      this.listeners.add(o.next), this.status !== Ge.NotStarted && o.next(this.state);
      var a = function() {
        i.doneListeners.delete(a), i.stopListeners.delete(a), o.complete();
      };
      return this.status === Ge.Stopped ? o.complete() : (this.onDone(a), this.onStop(a)), {
        unsubscribe: function() {
          i.listeners.delete(o.next), i.doneListeners.delete(a), i.stopListeners.delete(a);
        }
      };
    }, e.prototype.onEvent = function(t) {
      return this.eventListeners.add(t), this;
    }, e.prototype.onSend = function(t) {
      return this.sendListeners.add(t), this;
    }, e.prototype.onChange = function(t) {
      return this.contextListeners.add(t), this;
    }, e.prototype.onStop = function(t) {
      return this.stopListeners.add(t), this;
    }, e.prototype.onDone = function(t) {
      return this.status === Ge.Stopped && this._doneEvent ? t(this._doneEvent) : this.doneListeners.add(t), this;
    }, e.prototype.off = function(t) {
      return this.listeners.delete(t), this.eventListeners.delete(t), this.sendListeners.delete(t), this.stopListeners.delete(t), this.doneListeners.delete(t), this.contextListeners.delete(t), this;
    }, e.prototype.start = function(t) {
      var n = this;
      if (this.status === Ge.Running)
        return this;
      this.machine._init(), mr.register(this.sessionId, this), this.initialized = !0, this.status = Ge.Running;
      var r = t === void 0 ? this.initialState : Dn(this, function() {
        return Nb(t) ? n.machine.resolveState(t) : n.machine.resolveState(Nt.from(t, n.machine.context));
      });
      return this.options.devTools && this.attachDev(), this.scheduler.initialize(function() {
        n.update(r, Sn);
      }), this;
    }, e.prototype._stopChildren = function() {
      this.children.forEach(function(t) {
        be(t.stop) && t.stop();
      }), this.children.clear();
    }, e.prototype._stop = function() {
      var t, n, r, i, o, a, s, l, c, u;
      try {
        for (var f = ue(this.listeners), d = f.next(); !d.done; d = f.next()) {
          var m = d.value;
          this.listeners.delete(m);
        }
      } catch (M) {
        t = {
          error: M
        };
      } finally {
        try {
          d && !d.done && (n = f.return) && n.call(f);
        } finally {
          if (t)
            throw t.error;
        }
      }
      try {
        for (var p = ue(this.stopListeners), h = p.next(); !h.done; h = p.next()) {
          var m = h.value;
          m(), this.stopListeners.delete(m);
        }
      } catch (M) {
        r = {
          error: M
        };
      } finally {
        try {
          h && !h.done && (i = p.return) && i.call(p);
        } finally {
          if (r)
            throw r.error;
        }
      }
      try {
        for (var _ = ue(this.contextListeners), y = _.next(); !y.done; y = _.next()) {
          var m = y.value;
          this.contextListeners.delete(m);
        }
      } catch (M) {
        o = {
          error: M
        };
      } finally {
        try {
          y && !y.done && (a = _.return) && a.call(_);
        } finally {
          if (o)
            throw o.error;
        }
      }
      try {
        for (var g = ue(this.doneListeners), w = g.next(); !w.done; w = g.next()) {
          var m = w.value;
          this.doneListeners.delete(m);
        }
      } catch (M) {
        s = {
          error: M
        };
      } finally {
        try {
          w && !w.done && (l = g.return) && l.call(g);
        } finally {
          if (s)
            throw s.error;
        }
      }
      if (!this.initialized)
        return this;
      this.initialized = !1, this.status = Ge.Stopped, this._initialState = void 0;
      try {
        for (var x = ue(Object.keys(this.delayedEventsMap)), I = x.next(); !I.done; I = x.next()) {
          var U = I.value;
          this.clock.clearTimeout(this.delayedEventsMap[U]);
        }
      } catch (M) {
        c = {
          error: M
        };
      } finally {
        try {
          I && !I.done && (u = x.return) && u.call(x);
        } finally {
          if (c)
            throw c.error;
        }
      }
      this.scheduler.clear(), this.scheduler = new $l({
        deferEvents: this.options.deferEvents
      });
    }, e.prototype.stop = function() {
      var t = this, n = this.scheduler;
      return this._stop(), n.schedule(function() {
        var r = Ke({
          type: "xstate.stop"
        }), i = Dn(t, function() {
          var o = Pe(Oe([], pe(t.state.configuration), !1).sort(function(u, f) {
            return f.order - u.order;
          }).map(function(u) {
            return zt(u.onExit, t.machine.options.actions);
          })), a = pe(jr(t.machine, t.state, t.state.context, r, [{
            type: "exit",
            actions: o
          }], t.machine.config.predictableActionArguments ? t._exec : void 0, t.machine.config.predictableActionArguments || t.machine.config.preserveActionOrder), 2), s = a[0], l = a[1], c = new Nt({
            value: t.state.value,
            context: l,
            _event: r,
            _sessionid: t.sessionId,
            historyValue: void 0,
            history: t.state,
            actions: s.filter(function(u) {
              return !ka(u);
            }),
            activities: {},
            events: [],
            configuration: [],
            transitions: [],
            children: {},
            done: t.state.done,
            tags: t.state.tags,
            machine: t.machine
          });
          return c.changed = !0, c;
        });
        t.update(i, r), t._stopChildren(), mr.free(t.sessionId);
      }), this;
    }, e.prototype.batch = function(t) {
      var n = this;
      if (!(this.status === Ge.NotStarted && this.options.deferEvents)) {
        if (this.status !== Ge.Running)
          throw new Error(
            // tslint:disable-next-line:max-line-length
            "".concat(t.length, ' event(s) were sent to uninitialized service "').concat(this.machine.id, '". Make sure .start() is called for this service, or set { deferEvents: true } in the service options.')
          );
      }
      if (t.length) {
        var r = !!this.machine.config.predictableActionArguments && this._exec;
        this.scheduler.schedule(function() {
          var i, o, a = n.state, s = !1, l = [], c = function(m) {
            var p = Ke(m);
            n.forward(p), a = Dn(n, function() {
              return n.machine.transition(a, p, void 0, r || void 0);
            }), l.push.apply(l, Oe([], pe(n.machine.config.predictableActionArguments ? a.actions : a.actions.map(function(h) {
              return Ib(h, a);
            })), !1)), s = s || !!a.changed;
          };
          try {
            for (var u = ue(t), f = u.next(); !f.done; f = u.next()) {
              var d = f.value;
              c(d);
            }
          } catch (m) {
            i = {
              error: m
            };
          } finally {
            try {
              f && !f.done && (o = u.return) && o.call(u);
            } finally {
              if (i)
                throw i.error;
            }
          }
          a.changed = s, a.actions = l, n.update(a, Ke(t[t.length - 1]));
        });
      }
    }, e.prototype.sender = function(t) {
      return this.send.bind(this, t);
    }, e.prototype._nextState = function(t, n) {
      var r = this;
      n === void 0 && (n = !!this.machine.config.predictableActionArguments && this._exec);
      var i = Ke(t);
      if (i.name.indexOf(wa) === 0 && !this.state.nextEvents.some(function(a) {
        return a.indexOf(wa) === 0;
      }))
        throw i.data.data;
      var o = Dn(this, function() {
        return r.machine.transition(r.state, i, void 0, n || void 0);
      });
      return o;
    }, e.prototype.nextState = function(t) {
      return this._nextState(t, !1);
    }, e.prototype.forward = function(t) {
      var n, r;
      try {
        for (var i = ue(this.forwardTo), o = i.next(); !o.done; o = i.next()) {
          var a = o.value, s = this.children.get(a);
          if (!s)
            throw new Error("Unable to forward event '".concat(t, "' from interpreter '").concat(this.id, "' to nonexistant child '").concat(a, "'."));
          s.send(t);
        }
      } catch (l) {
        n = {
          error: l
        };
      } finally {
        try {
          o && !o.done && (r = i.return) && r.call(i);
        } finally {
          if (n)
            throw n.error;
        }
      }
    }, e.prototype.defer = function(t) {
      var n = this, r = this.clock.setTimeout(function() {
        "to" in t && t.to ? n.sendTo(t._event, t.to, !0) : n.send(t._event);
      }, t.delay);
      t.id && (this.delayedEventsMap[t.id] = r);
    }, e.prototype.cancel = function(t) {
      this.clock.clearTimeout(this.delayedEventsMap[t]), delete this.delayedEventsMap[t];
    }, e.prototype.exec = function(t, n, r) {
      r === void 0 && (r = this.machine.options.actions), this._exec(t, n.context, n._event, r);
    }, e.prototype.removeChild = function(t) {
      var n;
      this.children.delete(t), this.forwardTo.delete(t), (n = this.state) === null || n === void 0 || delete n.children[t];
    }, e.prototype.stopChild = function(t) {
      var n = this.children.get(t);
      n && (this.removeChild(t), be(n.stop) && n.stop());
    }, e.prototype.spawn = function(t, n, r) {
      if (this.status !== Ge.Running)
        return wd(t, n);
      if (Rl(t))
        return this.spawnPromise(Promise.resolve(t), n);
      if (be(t))
        return this.spawnCallback(t, n);
      if (Eb(t))
        return this.spawnActor(t, n);
      if (sb(t))
        return this.spawnObservable(t, n);
      if (Xn(t))
        return this.spawnMachine(t, T(T({}, r), {
          id: n
        }));
      if (rb(t))
        return this.spawnBehavior(t, n);
      throw new Error('Unable to spawn entity "'.concat(n, '" of type "').concat(typeof t, '".'));
    }, e.prototype.spawnMachine = function(t, n) {
      var r = this;
      n === void 0 && (n = {});
      var i = new e(t, T(T({}, this.options), {
        parent: this,
        id: n.id || t.id
      })), o = T(T({}, Db), n);
      o.sync && i.onTransition(function(s) {
        r.send(xo, {
          state: s,
          id: i.id
        });
      });
      var a = i;
      return this.children.set(i.id, a), o.autoForward && this.forwardTo.add(i.id), i.onDone(function(s) {
        r.removeChild(i.id), r.send(Ke(s, {
          origin: i.id
        }));
      }).start(), a;
    }, e.prototype.spawnBehavior = function(t, n) {
      var r = Rb(t, {
        id: n,
        parent: this
      });
      return this.children.set(n, r), r;
    }, e.prototype.spawnPromise = function(t, n) {
      var r, i = this, o = !1, a;
      t.then(function(l) {
        o || (a = l, i.removeChild(n), i.send(Ke(Nr(n, l), {
          origin: n
        })));
      }, function(l) {
        if (!o) {
          i.removeChild(n);
          var c = zn(n, l);
          try {
            i.send(Ke(c, {
              origin: n
            }));
          } catch {
            i.devTools && i.devTools.send(c, i.state), i.machine.strict && i.stop();
          }
        }
      });
      var s = (r = {
        id: n,
        send: function() {
        },
        subscribe: function(l, c, u) {
          var f = Ti(l, c, u), d = !1;
          return t.then(function(m) {
            d || (f.next(m), !d && f.complete());
          }, function(m) {
            d || f.error(m);
          }), {
            unsubscribe: function() {
              return d = !0;
            }
          };
        },
        stop: function() {
          o = !0;
        },
        toJSON: function() {
          return {
            id: n
          };
        },
        getSnapshot: function() {
          return a;
        }
      }, r[Qt] = function() {
        return this;
      }, r);
      return this.children.set(n, s), s;
    }, e.prototype.spawnCallback = function(t, n) {
      var r, i = this, o = !1, a = /* @__PURE__ */ new Set(), s = /* @__PURE__ */ new Set(), l, c = function(d) {
        l = d, s.forEach(function(m) {
          return m(d);
        }), !o && i.send(Ke(d, {
          origin: n
        }));
      }, u;
      try {
        u = t(c, function(d) {
          a.add(d);
        });
      } catch (d) {
        this.send(zn(n, d));
      }
      if (Rl(u))
        return this.spawnPromise(u, n);
      var f = (r = {
        id: n,
        send: function(d) {
          return a.forEach(function(m) {
            return m(d);
          });
        },
        subscribe: function(d) {
          var m = Ti(d);
          return s.add(m.next), {
            unsubscribe: function() {
              s.delete(m.next);
            }
          };
        },
        stop: function() {
          o = !0, be(u) && u();
        },
        toJSON: function() {
          return {
            id: n
          };
        },
        getSnapshot: function() {
          return l;
        }
      }, r[Qt] = function() {
        return this;
      }, r);
      return this.children.set(n, f), f;
    }, e.prototype.spawnObservable = function(t, n) {
      var r, i = this, o, a = t.subscribe(function(l) {
        o = l, i.send(Ke(l, {
          origin: n
        }));
      }, function(l) {
        i.removeChild(n), i.send(Ke(zn(n, l), {
          origin: n
        }));
      }, function() {
        i.removeChild(n), i.send(Ke(Nr(n), {
          origin: n
        }));
      }), s = (r = {
        id: n,
        send: function() {
        },
        subscribe: function(l, c, u) {
          return t.subscribe(l, c, u);
        },
        stop: function() {
          return a.unsubscribe();
        },
        getSnapshot: function() {
          return o;
        },
        toJSON: function() {
          return {
            id: n
          };
        }
      }, r[Qt] = function() {
        return this;
      }, r);
      return this.children.set(n, s), s;
    }, e.prototype.spawnActor = function(t, n) {
      return this.children.set(n, t), t;
    }, e.prototype.spawnActivity = function(t) {
      var n = this.machine.options && this.machine.options.activities ? this.machine.options.activities[t.type] : void 0;
      if (n) {
        var r = n(this.state.context, t);
        this.spawnEffect(t.id, r);
      }
    }, e.prototype.spawnEffect = function(t, n) {
      var r;
      this.children.set(t, (r = {
        id: t,
        send: function() {
        },
        subscribe: function() {
          return {
            unsubscribe: function() {
            }
          };
        },
        stop: n || void 0,
        getSnapshot: function() {
        },
        toJSON: function() {
          return {
            id: t
          };
        }
      }, r[Qt] = function() {
        return this;
      }, r));
    }, e.prototype.attachDev = function() {
      var t = vs();
      if (this.options.devTools && t) {
        if (t.__REDUX_DEVTOOLS_EXTENSION__) {
          var n = typeof this.options.devTools == "object" ? this.options.devTools : void 0;
          this.devTools = t.__REDUX_DEVTOOLS_EXTENSION__.connect(T(T({
            name: this.id,
            autoPause: !0,
            stateSanitizer: function(r) {
              return {
                value: r.value,
                context: r.context,
                actions: r.actions
              };
            }
          }, n), {
            features: T({
              jump: !1,
              skip: !1
            }, n ? n.features : void 0)
          }), this.machine), this.devTools.init(this.state);
        }
        Mb(this);
      }
    }, e.prototype.toJSON = function() {
      return {
        id: this.id
      };
    }, e.prototype[Qt] = function() {
      return this;
    }, e.prototype.getSnapshot = function() {
      return this.status === Ge.NotStarted ? this.initialState : this._state;
    }, e.defaultOptions = {
      execute: !0,
      deferEvents: !0,
      clock: {
        setTimeout: function(t, n) {
          return setTimeout(t, n);
        },
        clearTimeout: function(t) {
          return clearTimeout(t);
        }
      },
      logger: /* @__PURE__ */ console.log.bind(console),
      devTools: !1
    }, e.interpret = Od, e;
  }()
);
function Od(e, t) {
  var n = new zb(e, t);
  return n;
}
function Lb(e) {
  if (typeof e == "string") {
    var t = {
      type: e
    };
    return t.toString = function() {
      return e;
    }, t;
  }
  return e;
}
function hi(e) {
  return T(T({
    type: Wi
  }, e), {
    toJSON: function() {
      e.onDone, e.onError;
      var t = fs(e, ["onDone", "onError"]);
      return T(T({}, t), {
        type: Wi,
        src: Lb(e.src)
      });
    }
  });
}
var vi = "", Oa = "#", qo = "*", Mn = {}, Rn = function(e) {
  return e[0] === Oa;
}, $b = function() {
  return {
    actions: {},
    guards: {},
    services: {},
    activities: {},
    delays: {}
  };
}, Fb = (
  /** @class */
  /* @__PURE__ */ function() {
    function e(t, n, r, i) {
      r === void 0 && (r = "context" in t ? t.context : void 0);
      var o = this, a;
      this.config = t, this._context = r, this.order = -1, this.__xstatenode = !0, this.__cache = {
        events: void 0,
        relativeValue: /* @__PURE__ */ new Map(),
        initialStateValue: void 0,
        initialState: void 0,
        on: void 0,
        transitions: void 0,
        candidates: {},
        delayedTransitions: void 0
      }, this.idMap = {}, this.tags = [], this.options = Object.assign($b(), n), this.parent = i == null ? void 0 : i.parent, this.key = this.config.key || (i == null ? void 0 : i.key) || this.config.id || "(machine)", this.machine = this.parent ? this.parent.machine : this, this.path = this.parent ? this.parent.path.concat(this.key) : [], this.delimiter = this.config.delimiter || (this.parent ? this.parent.delimiter : rd), this.id = this.config.id || Oe([this.machine.key], pe(this.path), !1).join(this.delimiter), this.version = this.parent ? this.parent.version : this.config.version, this.type = this.config.type || (this.config.parallel ? "parallel" : this.config.states && Object.keys(this.config.states).length ? "compound" : this.config.history ? "history" : "atomic"), this.schema = this.parent ? this.machine.schema : (a = this.config.schema) !== null && a !== void 0 ? a : {}, this.description = this.config.description, this.initial = this.config.initial, this.states = this.config.states ? vr(this.config.states, function(c, u) {
        var f, d = new e(c, {}, void 0, {
          parent: o,
          key: u
        });
        return Object.assign(o.idMap, T((f = {}, f[d.id] = d, f), d.idMap)), d;
      }) : Mn;
      var s = 0;
      function l(c) {
        var u, f;
        c.order = s++;
        try {
          for (var d = ue(xd(c)), m = d.next(); !m.done; m = d.next()) {
            var p = m.value;
            l(p);
          }
        } catch (h) {
          u = {
            error: h
          };
        } finally {
          try {
            m && !m.done && (f = d.return) && f.call(d);
          } finally {
            if (u)
              throw u.error;
          }
        }
      }
      l(this), this.history = this.config.history === !0 ? "shallow" : this.config.history || !1, this._transient = !!this.config.always || (this.config.on ? Array.isArray(this.config.on) ? this.config.on.some(function(c) {
        var u = c.event;
        return u === vi;
      }) : vi in this.config.on : !1), this.strict = !!this.config.strict, this.onEntry = _t(this.config.entry || this.config.onEntry).map(function(c) {
        return Jn(c);
      }), this.onExit = _t(this.config.exit || this.config.onExit).map(function(c) {
        return Jn(c);
      }), this.meta = this.config.meta, this.doneData = this.type === "final" ? this.config.data : void 0, this.invoke = _t(this.config.invoke).map(function(c, u) {
        var f, d;
        if (Xn(c)) {
          var m = bi(o.id, u);
          return o.machine.options.services = T((f = {}, f[m] = c, f), o.machine.options.services), hi({
            src: m,
            id: m
          });
        } else if (ve(c.src)) {
          var m = c.id || bi(o.id, u);
          return hi(T(T({}, c), {
            id: m,
            src: c.src
          }));
        } else if (Xn(c.src) || be(c.src)) {
          var m = c.id || bi(o.id, u);
          return o.machine.options.services = T((d = {}, d[m] = c.src, d), o.machine.options.services), hi(T(T({
            id: m
          }, c), {
            src: m
          }));
        } else {
          var p = c.src;
          return hi(T(T({
            id: bi(o.id, u)
          }, c), {
            src: p
          }));
        }
      }), this.activities = _t(this.config.activities).concat(this.invoke).map(function(c) {
        return ko(c);
      }), this.transition = this.transition.bind(this), this.tags = _t(this.config.tags);
    }
    return e.prototype._init = function() {
      this.__cache.transitions || Ed(this).forEach(function(t) {
        return t.on;
      });
    }, e.prototype.withConfig = function(t, n) {
      var r = this.options, i = r.actions, o = r.activities, a = r.guards, s = r.services, l = r.delays;
      return new e(this.config, {
        actions: T(T({}, i), t.actions),
        activities: T(T({}, o), t.activities),
        guards: T(T({}, a), t.guards),
        services: T(T({}, s), t.services),
        delays: T(T({}, l), t.delays)
      }, n ?? this.context);
    }, e.prototype.withContext = function(t) {
      return new e(this.config, this.options, t);
    }, Object.defineProperty(e.prototype, "context", {
      get: function() {
        return be(this._context) ? this._context() : this._context;
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(e.prototype, "definition", {
      /**
       * The well-structured state node definition.
       */
      get: function() {
        return {
          id: this.id,
          key: this.key,
          version: this.version,
          context: this.context,
          type: this.type,
          initial: this.initial,
          history: this.history,
          states: vr(this.states, function(t) {
            return t.definition;
          }),
          on: this.on,
          transitions: this.transitions,
          entry: this.onEntry,
          exit: this.onExit,
          activities: this.activities || [],
          meta: this.meta,
          order: this.order || -1,
          data: this.doneData,
          invoke: this.invoke,
          description: this.description,
          tags: this.tags
        };
      },
      enumerable: !1,
      configurable: !0
    }), e.prototype.toJSON = function() {
      return this.definition;
    }, Object.defineProperty(e.prototype, "on", {
      /**
       * The mapping of events to transitions.
       */
      get: function() {
        if (this.__cache.on)
          return this.__cache.on;
        var t = this.transitions;
        return this.__cache.on = t.reduce(function(n, r) {
          return n[r.eventType] = n[r.eventType] || [], n[r.eventType].push(r), n;
        }, {});
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(e.prototype, "after", {
      get: function() {
        return this.__cache.delayedTransitions || (this.__cache.delayedTransitions = this.getDelayedTransitions(), this.__cache.delayedTransitions);
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(e.prototype, "transitions", {
      /**
       * All the transitions that can be taken from this state node.
       */
      get: function() {
        return this.__cache.transitions || (this.__cache.transitions = this.formatTransitions(), this.__cache.transitions);
      },
      enumerable: !1,
      configurable: !0
    }), e.prototype.getCandidates = function(t) {
      if (this.__cache.candidates[t])
        return this.__cache.candidates[t];
      var n = t === vi, r = this.transitions.filter(function(i) {
        var o = i.eventType === t;
        return n ? o : o || i.eventType === qo;
      });
      return this.__cache.candidates[t] = r, r;
    }, e.prototype.getDelayedTransitions = function() {
      var t = this, n = this.config.after;
      if (!n)
        return [];
      var r = function(o, a) {
        var s = be(o) ? "".concat(t.id, ":delay[").concat(a, "]") : o, l = yd(s, t.id);
        return t.onEntry.push(sr(l, {
          delay: o
        })), t.onExit.push(pd(l)), l;
      }, i = ar(n) ? n.map(function(o, a) {
        var s = r(o.delay, a);
        return T(T({}, o), {
          event: s
        });
      }) : Pe(Object.keys(n).map(function(o, a) {
        var s = n[o], l = ve(s) ? {
          target: s
        } : s, c = isNaN(+o) ? o : +o, u = r(c, a);
        return _t(l).map(function(f) {
          return T(T({}, f), {
            event: u,
            delay: c
          });
        });
      }));
      return i.map(function(o) {
        var a = o.delay;
        return T(T({}, t.formatTransition(o)), {
          delay: a
        });
      });
    }, e.prototype.getStateNodes = function(t) {
      var n, r = this;
      if (!t)
        return [];
      var i = t instanceof Nt ? t.value : Ar(t, this.delimiter);
      if (ve(i)) {
        var o = this.getStateNode(i).initial;
        return o !== void 0 ? this.getStateNodes((n = {}, n[i] = o, n)) : [this, this.states[i]];
      }
      var a = Object.keys(i), s = [this];
      return s.push.apply(s, Oe([], pe(Pe(a.map(function(l) {
        return r.getStateNode(l).getStateNodes(i[l]);
      }))), !1)), s;
    }, e.prototype.handles = function(t) {
      var n = id(t);
      return this.events.includes(n);
    }, e.prototype.resolveState = function(t) {
      var n = t instanceof Nt ? t : Nt.create(t), r = Array.from(yr([], this.getStateNodes(n.value)));
      return new Nt(T(T({}, n), {
        value: this.resolve(n.value),
        configuration: r,
        done: Pi(r, this),
        tags: Ll(r),
        machine: this.machine
      }));
    }, e.prototype.transitionLeafNode = function(t, n, r) {
      var i = this.getStateNode(t), o = i.next(n, r);
      return !o || !o.transitions.length ? this.next(n, r) : o;
    }, e.prototype.transitionCompoundNode = function(t, n, r) {
      var i = Object.keys(t), o = this.getStateNode(i[0]), a = o._transition(t[i[0]], n, r);
      return !a || !a.transitions.length ? this.next(n, r) : a;
    }, e.prototype.transitionParallelNode = function(t, n, r) {
      var i, o, a = {};
      try {
        for (var s = ue(Object.keys(t)), l = s.next(); !l.done; l = s.next()) {
          var c = l.value, u = t[c];
          if (u) {
            var f = this.getStateNode(c), d = f._transition(u, n, r);
            d && (a[c] = d);
          }
        }
      } catch (y) {
        i = {
          error: y
        };
      } finally {
        try {
          l && !l.done && (o = s.return) && o.call(s);
        } finally {
          if (i)
            throw i.error;
        }
      }
      var m = Object.keys(a).map(function(y) {
        return a[y];
      }), p = Pe(m.map(function(y) {
        return y.transitions;
      })), h = m.some(function(y) {
        return y.transitions.length > 0;
      });
      if (!h)
        return this.next(n, r);
      var _ = Pe(Object.keys(a).map(function(y) {
        return a[y].configuration;
      }));
      return {
        transitions: p,
        exitSet: Pe(m.map(function(y) {
          return y.exitSet;
        })),
        configuration: _,
        source: n,
        actions: Pe(Object.keys(a).map(function(y) {
          return a[y].actions;
        }))
      };
    }, e.prototype._transition = function(t, n, r) {
      return ve(t) ? this.transitionLeafNode(t, n, r) : Object.keys(t).length === 1 ? this.transitionCompoundNode(t, n, r) : this.transitionParallelNode(t, n, r);
    }, e.prototype.getTransitionData = function(t, n) {
      return this._transition(t.value, t, Ke(n));
    }, e.prototype.next = function(t, n) {
      var r, i, o = this, a = n.name, s = [], l = [], c;
      try {
        for (var u = ue(this.getCandidates(a)), f = u.next(); !f.done; f = u.next()) {
          var d = f.value, m = d.cond, p = d.in, h = t.context, _ = p ? ve(p) && Rn(p) ? (
            // Check if in state by ID
            t.matches(Ar(this.getStateNodeById(p).path, this.delimiter))
          ) : (
            // Check if in state by relative grandparent
            bs(Ar(p, this.delimiter), eb(this.path.slice(0, -2))(t.value))
          ) : !0, y = !1;
          try {
            y = !m || ld(this.machine, m, h, n, t);
          } catch (x) {
            throw new Error("Unable to evaluate guard '".concat(m.name || m.type, "' in transition for event '").concat(a, "' in state node '").concat(this.id, `':
`).concat(x.message));
          }
          if (y && _) {
            d.target !== void 0 && (l = d.target), s.push.apply(s, Oe([], pe(d.actions), !1)), c = d;
            break;
          }
        }
      } catch (x) {
        r = {
          error: x
        };
      } finally {
        try {
          f && !f.done && (i = u.return) && i.call(u);
        } finally {
          if (r)
            throw r.error;
        }
      }
      if (c) {
        if (!l.length)
          return {
            transitions: [c],
            exitSet: [],
            configuration: t.value ? [this] : [],
            source: t,
            actions: s
          };
        var g = Pe(l.map(function(x) {
          return o.getRelativeStateNodes(x, t.historyValue);
        })), w = !!c.internal;
        return {
          transitions: [c],
          exitSet: w ? [] : Pe(l.map(function(x) {
            return o.getPotentiallyReenteringNodes(x);
          })),
          configuration: g,
          source: t,
          actions: s
        };
      }
    }, e.prototype.getPotentiallyReenteringNodes = function(t) {
      if (this.order < t.order)
        return [this];
      for (var n = [], r = this, i = t; r && r !== i; )
        n.push(r), r = r.parent;
      return r !== i ? [] : (n.push(i), n);
    }, e.prototype.getActions = function(t, n, r, i, o, a, s) {
      var l, c, u, f, d = this, m = a ? yr([], this.getStateNodes(a.value)) : [], p = /* @__PURE__ */ new Set();
      try {
        for (var h = ue(Array.from(t).sort(function(F, A) {
          return F.order - A.order;
        })), _ = h.next(); !_.done; _ = h.next()) {
          var y = _.value;
          (!_r(m, y) || _r(r.exitSet, y) || y.parent && p.has(y.parent)) && p.add(y);
        }
      } catch (F) {
        l = {
          error: F
        };
      } finally {
        try {
          _ && !_.done && (c = h.return) && c.call(h);
        } finally {
          if (l)
            throw l.error;
        }
      }
      try {
        for (var g = ue(m), w = g.next(); !w.done; w = g.next()) {
          var y = w.value;
          (!_r(t, y) || _r(r.exitSet, y.parent)) && r.exitSet.push(y);
        }
      } catch (F) {
        u = {
          error: F
        };
      } finally {
        try {
          w && !w.done && (f = g.return) && f.call(g);
        } finally {
          if (u)
            throw u.error;
        }
      }
      r.exitSet.sort(function(F, A) {
        return A.order - F.order;
      });
      var x = Array.from(p).sort(function(F, A) {
        return F.order - A.order;
      }), I = new Set(r.exitSet), U = Pe(x.map(function(F) {
        var A = [];
        if (F.type !== "final")
          return A;
        var X = F.parent;
        if (!X.parent)
          return A;
        A.push(
          gr(F.id, F.doneData),
          // TODO: deprecate - final states should not emit done events for their own state.
          gr(X.id, F.doneData ? Ki(F.doneData, i, o) : void 0)
        );
        var ce = X.parent;
        return ce.type === "parallel" && Ur(ce).every(function(Ce) {
          return Pi(r.configuration, Ce);
        }) && A.push(gr(ce.id)), A;
      })), M = x.map(function(F) {
        var A = F.onEntry, X = F.activities.map(function(ce) {
          return bd(ce);
        });
        return {
          type: "entry",
          actions: zt(s ? Oe(Oe([], pe(A), !1), pe(X), !1) : Oe(Oe([], pe(X), !1), pe(A), !1), d.machine.options.actions)
        };
      }).concat({
        type: "state_done",
        actions: U.map(function(F) {
          return ud(F);
        })
      }), C = Array.from(I).map(function(F) {
        return {
          type: "exit",
          actions: zt(Oe(Oe([], pe(F.onExit), !1), pe(F.activities.map(function(A) {
            return hd(A);
          })), !1), d.machine.options.actions)
        };
      }), R = C.concat({
        type: "transition",
        actions: zt(r.actions, this.machine.options.actions)
      }).concat(M);
      if (n) {
        var W = zt(Pe(Oe([], pe(t), !1).sort(function(F, A) {
          return A.order - F.order;
        }).map(function(F) {
          return F.onExit;
        })), this.machine.options.actions).filter(function(F) {
          return !ka(F);
        });
        return R.concat({
          type: "stop",
          actions: W
        });
      }
      return R;
    }, e.prototype.transition = function(t, n, r, i) {
      t === void 0 && (t = this.initialState);
      var o = Ke(n), a;
      if (t instanceof Nt)
        a = r === void 0 ? t : this.resolveState(Nt.from(t, r));
      else {
        var s = ve(t) ? this.resolve(qi(this.getResolvedPath(t))) : this.resolve(t), l = r ?? this.machine.context;
        a = this.resolveState(Nt.from(s, l));
      }
      if (this.strict && !this.events.includes(o.name) && !nb(o.name))
        throw new Error("Machine '".concat(this.id, "' does not accept event '").concat(o.name, "'"));
      var c = this._transition(a.value, a, o) || {
        transitions: [],
        configuration: [],
        exitSet: [],
        source: a,
        actions: []
      }, u = yr([], this.getStateNodes(a.value)), f = c.configuration.length ? yr(u, c.configuration) : u;
      return c.configuration = Oe([], pe(f), !1), this.resolveTransition(c, a, a.context, i, o);
    }, e.prototype.resolveRaisedTransition = function(t, n, r, i) {
      var o, a = t.actions;
      return t = this.transition(t, n, void 0, i), t._event = r, t.event = r.data, (o = t.actions).unshift.apply(o, Oe([], pe(a), !1)), t;
    }, e.prototype.resolveTransition = function(t, n, r, i, o) {
      var a, s, l, c, u = this;
      o === void 0 && (o = Sn);
      var f = t.configuration, d = !n || t.transitions.length > 0, m = d ? t.configuration : n ? n.configuration : [], p = Pi(m, this), h = d ? Sb(this.machine, f) : void 0, _ = n ? n.historyValue ? n.historyValue : t.source ? this.machine.historyValue(n.value) : void 0 : void 0, y = this.getActions(new Set(m), p, t, r, o, n, i), g = n ? T({}, n.activities) : {};
      try {
        for (var w = ue(y), x = w.next(); !x.done; x = w.next()) {
          var I = x.value;
          try {
            for (var U = (l = void 0, ue(I.actions)), M = U.next(); !M.done; M = U.next()) {
              var C = M.value;
              C.type === Yi ? g[C.activity.id || C.activity.type] = C : C.type === yo && (g[C.activity.id || C.activity.type] = !1);
            }
          } catch (tt) {
            l = {
              error: tt
            };
          } finally {
            try {
              M && !M.done && (c = U.return) && c.call(U);
            } finally {
              if (l)
                throw l.error;
            }
          }
        }
      } catch (tt) {
        a = {
          error: tt
        };
      } finally {
        try {
          x && !x.done && (s = w.return) && s.call(w);
        } finally {
          if (a)
            throw a.error;
        }
      }
      var R = pe(jr(this, n, r, o, y, i, this.machine.config.predictableActionArguments || this.machine.config.preserveActionOrder), 2), W = R[0], F = R[1], A = pe(ib(W, ka), 2), X = A[0], ce = A[1], Ce = W.filter(function(tt) {
        var Gt;
        return tt.type === Yi && ((Gt = tt.activity) === null || Gt === void 0 ? void 0 : Gt.type) === Wi;
      }), J = Ce.reduce(function(tt, Gt) {
        return tt[Gt.activity.id] = wb(Gt.activity, u.machine, F, o), tt;
      }, n ? T({}, n.children) : {}), V = new Nt({
        value: h || n.value,
        context: F,
        _event: o,
        // Persist _sessionid between states
        _sessionid: n ? n._sessionid : null,
        historyValue: h ? _ ? ob(_, h) : void 0 : n ? n.historyValue : void 0,
        history: !h || t.source ? n : void 0,
        actions: h ? ce : [],
        activities: h ? g : n ? n.activities : {},
        events: [],
        configuration: m,
        transitions: t.transitions,
        children: J,
        done: p,
        tags: Ll(m),
        machine: this
      }), G = r !== F;
      V.changed = o.name === xo || G;
      var me = V.history;
      me && delete me.history;
      var Ue = !p && (this._transient || f.some(function(tt) {
        return tt._transient;
      }));
      if (!d && (!Ue || o.name === vi))
        return V;
      var Te = V;
      if (!p)
        for (Ue && (Te = this.resolveRaisedTransition(Te, {
          type: Zu
        }, o, i)); X.length; ) {
          var Me = X.shift();
          Te = this.resolveRaisedTransition(Te, Me._event, o, i);
        }
      var Nn = Te.changed || (me ? !!Te.actions.length || G || typeof me.value != typeof Te.value || !Sd(Te.value, me.value) : void 0);
      return Te.changed = Nn, Te.history = me, Te;
    }, e.prototype.getStateNode = function(t) {
      if (Rn(t))
        return this.machine.getStateNodeById(t);
      if (!this.states)
        throw new Error("Unable to retrieve child state '".concat(t, "' from '").concat(this.id, "'; no child states exist."));
      var n = this.states[t];
      if (!n)
        throw new Error("Child state '".concat(t, "' does not exist on '").concat(this.id, "'"));
      return n;
    }, e.prototype.getStateNodeById = function(t) {
      var n = Rn(t) ? t.slice(Oa.length) : t;
      if (n === this.id)
        return this;
      var r = this.machine.idMap[n];
      if (!r)
        throw new Error("Child state node '#".concat(n, "' does not exist on machine '").concat(this.id, "'"));
      return r;
    }, e.prototype.getStateNodeByPath = function(t) {
      if (typeof t == "string" && Rn(t))
        try {
          return this.getStateNodeById(t.slice(1));
        } catch {
        }
      for (var n = Ea(t, this.delimiter).slice(), r = this; n.length; ) {
        var i = n.shift();
        if (!i.length)
          break;
        r = r.getStateNode(i);
      }
      return r;
    }, e.prototype.resolve = function(t) {
      var n, r = this;
      if (!t)
        return this.initialStateValue || Mn;
      switch (this.type) {
        case "parallel":
          return vr(this.initialStateValue, function(o, a) {
            return o ? r.getStateNode(a).resolve(t[a] || o) : Mn;
          });
        case "compound":
          if (ve(t)) {
            var i = this.getStateNode(t);
            return i.type === "parallel" || i.type === "compound" ? (n = {}, n[t] = i.initialStateValue, n) : t;
          }
          return Object.keys(t).length ? vr(t, function(o, a) {
            return o ? r.getStateNode(a).resolve(o) : Mn;
          }) : this.initialStateValue || {};
        default:
          return t || Mn;
      }
    }, e.prototype.getResolvedPath = function(t) {
      if (Rn(t)) {
        var n = this.machine.idMap[t.slice(Oa.length)];
        if (!n)
          throw new Error("Unable to find state node '".concat(t, "'"));
        return n.path;
      }
      return Ea(t, this.delimiter);
    }, Object.defineProperty(e.prototype, "initialStateValue", {
      get: function() {
        var t;
        if (this.__cache.initialStateValue)
          return this.__cache.initialStateValue;
        var n;
        if (this.type === "parallel")
          n = Ml(this.states, function(r) {
            return r.initialStateValue || Mn;
          }, function(r) {
            return r.type !== "history";
          });
        else if (this.initial !== void 0) {
          if (!this.states[this.initial])
            throw new Error("Initial state '".concat(this.initial, "' not found on '").concat(this.key, "'"));
          n = Ji(this.states[this.initial]) ? this.initial : (t = {}, t[this.initial] = this.states[this.initial].initialStateValue, t);
        } else
          n = {};
        return this.__cache.initialStateValue = n, this.__cache.initialStateValue;
      },
      enumerable: !1,
      configurable: !0
    }), e.prototype.getInitialState = function(t, n) {
      this._init();
      var r = this.getStateNodes(t);
      return this.resolveTransition({
        configuration: r,
        exitSet: [],
        transitions: [],
        source: void 0,
        actions: []
      }, void 0, n ?? this.machine.context, void 0);
    }, Object.defineProperty(e.prototype, "initialState", {
      /**
       * The initial State instance, which includes all actions to be executed from
       * entering the initial state.
       */
      get: function() {
        var t = this.initialStateValue;
        if (!t)
          throw new Error("Cannot retrieve initial state from simple state '".concat(this.id, "'."));
        return this.getInitialState(t);
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(e.prototype, "target", {
      /**
       * The target state value of the history state node, if it exists. This represents the
       * default state value to transition to if no history value exists yet.
       */
      get: function() {
        var t;
        if (this.type === "history") {
          var n = this.config;
          ve(n.target) ? t = Rn(n.target) ? qi(this.machine.getStateNodeById(n.target).path.slice(this.path.length - 1)) : n.target : t = n.target;
        }
        return t;
      },
      enumerable: !1,
      configurable: !0
    }), e.prototype.getRelativeStateNodes = function(t, n, r) {
      return r === void 0 && (r = !0), r ? t.type === "history" ? t.resolveHistory(n) : t.initialStateNodes : [t];
    }, Object.defineProperty(e.prototype, "initialStateNodes", {
      get: function() {
        var t = this;
        if (Ji(this))
          return [this];
        if (this.type === "compound" && !this.initial)
          return [this];
        var n = Ci(this.initialStateValue);
        return Pe(n.map(function(r) {
          return t.getFromRelativePath(r);
        }));
      },
      enumerable: !1,
      configurable: !0
    }), e.prototype.getFromRelativePath = function(t) {
      if (!t.length)
        return [this];
      var n = pe(t), r = n[0], i = n.slice(1);
      if (!this.states)
        throw new Error("Cannot retrieve subPath '".concat(r, "' from node with no states"));
      var o = this.getStateNode(r);
      if (o.type === "history")
        return o.resolveHistory();
      if (!this.states[r])
        throw new Error("Child state '".concat(r, "' does not exist on '").concat(this.id, "'"));
      return this.states[r].getFromRelativePath(i);
    }, e.prototype.historyValue = function(t) {
      if (Object.keys(this.states).length)
        return {
          current: t || this.initialStateValue,
          states: Ml(this.states, function(n, r) {
            if (!t)
              return n.historyValue();
            var i = ve(t) ? void 0 : t[r];
            return n.historyValue(i || n.initialStateValue);
          }, function(n) {
            return !n.history;
          })
        };
    }, e.prototype.resolveHistory = function(t) {
      var n = this;
      if (this.type !== "history")
        return [this];
      var r = this.parent;
      if (!t) {
        var i = this.target;
        return i ? Pe(Ci(i).map(function(a) {
          return r.getFromRelativePath(a);
        })) : r.initialStateNodes;
      }
      var o = tb(r.path, "states")(t).current;
      return ve(o) ? [r.getStateNode(o)] : Pe(Ci(o).map(function(a) {
        return n.history === "deep" ? r.getFromRelativePath(a) : [r.states[a[0]]];
      }));
    }, Object.defineProperty(e.prototype, "stateIds", {
      /**
       * All the state node IDs of this state node and its descendant state nodes.
       */
      get: function() {
        var t = this, n = Pe(Object.keys(this.states).map(function(r) {
          return t.states[r].stateIds;
        }));
        return [this.id].concat(n);
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(e.prototype, "events", {
      /**
       * All the event types accepted by this state node and its descendants.
       */
      get: function() {
        var t, n, r, i;
        if (this.__cache.events)
          return this.__cache.events;
        var o = this.states, a = new Set(this.ownEvents);
        if (o)
          try {
            for (var s = ue(Object.keys(o)), l = s.next(); !l.done; l = s.next()) {
              var c = l.value, u = o[c];
              if (u.states)
                try {
                  for (var f = (r = void 0, ue(u.events)), d = f.next(); !d.done; d = f.next()) {
                    var m = d.value;
                    a.add("".concat(m));
                  }
                } catch (p) {
                  r = {
                    error: p
                  };
                } finally {
                  try {
                    d && !d.done && (i = f.return) && i.call(f);
                  } finally {
                    if (r)
                      throw r.error;
                  }
                }
            }
          } catch (p) {
            t = {
              error: p
            };
          } finally {
            try {
              l && !l.done && (n = s.return) && n.call(s);
            } finally {
              if (t)
                throw t.error;
            }
          }
        return this.__cache.events = Array.from(a);
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(e.prototype, "ownEvents", {
      /**
       * All the events that have transitions directly from this state node.
       *
       * Excludes any inert events.
       */
      get: function() {
        var t = new Set(this.transitions.filter(function(n) {
          return !(!n.target && !n.actions.length && n.internal);
        }).map(function(n) {
          return n.eventType;
        }));
        return Array.from(t);
      },
      enumerable: !1,
      configurable: !0
    }), e.prototype.resolveTarget = function(t) {
      var n = this;
      if (t !== void 0)
        return t.map(function(r) {
          if (!ve(r))
            return r;
          var i = r[0] === n.delimiter;
          if (i && !n.parent)
            return n.getStateNodeByPath(r.slice(1));
          var o = i ? n.key + r : r;
          if (n.parent)
            try {
              var a = n.parent.getStateNodeByPath(o);
              return a;
            } catch (s) {
              throw new Error("Invalid transition definition for state node '".concat(n.id, `':
`).concat(s.message));
            }
          else
            return n.getStateNodeByPath(o);
        });
    }, e.prototype.formatTransition = function(t) {
      var n = this, r = cb(t.target), i = "internal" in t ? t.internal : r ? r.some(function(l) {
        return ve(l) && l[0] === n.delimiter;
      }) : !0, o = this.machine.options.guards, a = this.resolveTarget(r), s = T(T({}, t), {
        actions: zt(_t(t.actions)),
        cond: sd(t.cond, o),
        target: a,
        source: this,
        internal: i,
        eventType: t.event,
        toJSON: function() {
          return T(T({}, s), {
            target: s.target ? s.target.map(function(l) {
              return "#".concat(l.id);
            }) : void 0,
            source: "#".concat(n.id)
          });
        }
      });
      return s;
    }, e.prototype.formatTransitions = function() {
      var t, n, r = this, i;
      if (!this.config.on)
        i = [];
      else if (Array.isArray(this.config.on))
        i = this.config.on;
      else {
        var o = this.config.on, a = qo, s = o[a], l = s === void 0 ? [] : s, c = fs(o, [typeof a == "symbol" ? a : a + ""]);
        i = Pe(Object.keys(c).map(function(g) {
          var w = Pn(g, c[g]);
          return w;
        }).concat(Pn(qo, l)));
      }
      var u = this.config.always ? Pn("", this.config.always) : [], f = this.config.onDone ? Pn(String(gr(this.id)), this.config.onDone) : [], d = Pe(this.invoke.map(function(g) {
        var w = [];
        return g.onDone && w.push.apply(w, Oe([], pe(Pn(String(Nr(g.id)), g.onDone)), !1)), g.onError && w.push.apply(w, Oe([], pe(Pn(String(zn(g.id)), g.onError)), !1)), w;
      })), m = this.after, p = Pe(Oe(Oe(Oe(Oe([], pe(f), !1), pe(d), !1), pe(i), !1), pe(u), !1).map(function(g) {
        return _t(g).map(function(w) {
          return r.formatTransition(w);
        });
      }));
      try {
        for (var h = ue(m), _ = h.next(); !_.done; _ = h.next()) {
          var y = _.value;
          p.push(y);
        }
      } catch (g) {
        t = {
          error: g
        };
      } finally {
        try {
          _ && !_.done && (n = h.return) && n.call(h);
        } finally {
          if (t)
            throw t.error;
        }
      }
      return p;
    }, e;
  }()
);
function Vb(e, t) {
  return new Fb(e, t);
}
var Qi = gd;
function jb(e) {
  return "state" in e;
}
var Fl = function() {
};
function Ub(e) {
  return "getSnapshot" in e ? e.getSnapshot() : jb(e) ? e.state : void 0;
}
function Hb(e, t) {
  t === void 0 && (t = Ub);
  var n = Je(e) ? e : oa(e), r = oa(t(n.value)), i = function(o) {
    n.value.send(o);
  };
  return bt(n, function(o, a, s) {
    r.value = t(o);
    var l = o.subscribe({
      next: function(c) {
        return r.value = c;
      },
      error: Fl,
      complete: Fl
    }).unsubscribe;
    s(function() {
      return l();
    });
  }, {
    immediate: !0
  }), { state: r, send: i };
}
const Bb = {
  CLOSE: "closed",
  ERROR: "error",
  UPDATE_CONTEXT: {
    actions: Qi((e, t) => {
      const { ...n } = t;
      return n;
    })
  }
}, Ad = {
  store_id: null,
  product_id: null,
  variant_id: null,
  coupon: null,
  quantity: null,
  product: null,
  variant: null,
  error: null,
  discord_data: null
}, Gb = {
  entry: Qi(Ad),
  on: {
    OPEN: {
      target: "checkout",
      actions: Qi((e, t) => ({
        store_id: t.store_id,
        product_id: t.product_id,
        variant_id: t.variant_id,
        coupon: t.coupon,
        quantity: t.quantity,
        email: t.email,
        customization: t.customization
      }))
    }
  }
}, Yb = {
  on: {
    FETCH: "checkout"
  }
}, Wb = {
  on: {
    VARIANT_SELECTION: "variant_selection",
    VARIANT_OVERVIEW: "overview"
  },
  invoke: {
    id: "openingCheckout",
    src: (e) => (t) => {
      if (!e.store_id || !e.product_id)
        throw {
          message: "This checkout button is not properly configured.",
          errors: {
            ...e.store_id ? { product_id: [] } : { store_id: [] }
          }
        };
      t(e.variant_id ? "VARIANT_OVERVIEW" : "VARIANT_SELECTION");
    }
  }
}, Zr = "https://sell.app/api/v2/fast-checkout";
function Oo(e, t) {
  for (const [n, r] of Object.entries(t))
    e = e.replace(`{${n}}`, r);
  return e;
}
function Qn(e) {
  return e === null ? !0 : typeof e == "string" ? e.trim() === "" : typeof e == "number" || typeof e == "boolean" ? !1 : Array.isArray(e) ? e.length === 0 : typeof e == "object" ? Object.entries(e).length === 0 : !e;
}
function Vl(e) {
  return !Qn(e);
}
function jl(e, t) {
  return Object.fromEntries(
    Object.entries(e).filter((n) => {
      const [r, i] = n;
      return t(i, r);
    })
  );
}
const Ao = {
  async get(e, t) {
    const n = new URL(e);
    return t && (n.search = new URLSearchParams(jl(t, Vl)).toString()), await Ul(n.toString(), {
      headers: {
        Accept: "application/json"
      }
    });
  },
  async post(e, t) {
    return await Ul(e, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(jl(t, Vl))
    });
  }
}, qb = 422, Kb = 403;
async function Ul(e, t) {
  const n = await fetch(e, t);
  if (!n.ok && n.status !== qb && n.status !== Kb)
    throw new Error("Oops... Something went wrong while processing your request.");
  const r = await n.json();
  if (!n.ok)
    throw { code: n.status, message: r.message ?? "", errors: r.errors ?? {} };
  return r;
}
const Xb = `${Zr}/{store_id}/{product_id}/{variant_id}`;
async function Jb(e, t, n, r) {
  const i = Oo(Xb, { store_id: e, product_id: t, variant_id: n });
  return await Ao.post(i, r);
}
const Qb = `${Zr}/{store_id}/{product_id}`;
async function Nd(e, t, n = {}) {
  const r = Oo(Qb, { store_id: e, product_id: t });
  return await Ao.get(r, n);
}
const Zb = `${Zr}/{store_id}/{product_id}/{variant_id}`;
async function eh(e, t, n, r = {}) {
  const i = Oo(Zb, { store_id: e, product_id: t, variant_id: n });
  return await Ao.get(i, r);
}
const { assign: th, pure: nh, send: rh } = So, No = nh((e, t) => {
  const n = typeof t.data == "object" && "errors" in t.data;
  let r = !n;
  const i = n ? t.data : { message: t.data, errors: {} };
  if (!n || "store_id" in i.errors || "product_id" in i.errors || "variant_id" in i.errors || i.code === 403) {
    const a = " Please contact the seller to let them know.";
    i.code !== 403 ? "store_id" in i.errors ? i.message = "This store could not be found." + a : "product_id" in i.errors ? i.message = "This product could not  be found." + a : "variant_id" in i.errors ? i.message = "This variant could not be found." + a : i.message = "It looks like something went wrong." : i.message === "You have been blacklisted" ? i.message = "You have either been blacklisted by the store owner, or you are using a VPN/Proxy. If you are using a proxy, please disable it." : i.message === "Action not allowed. This store is on hold." ? i.message = "This store is on hold: Creator has not paid their invoice yet" + a : i.message = "It looks like something went wrong." + a, i.errors = {}, r = !0;
  }
  const o = [
    th(
      () => ({
        error: i
      })
    )
  ];
  return r && o.push(rh("ERROR")), o;
}), { assign: Hl, send: ih } = So, oh = {
  on: {
    NEXT: {
      target: "overview",
      actions: Hl((e, t) => ({
        variant_id: t.variant_id
      }))
    }
  },
  meta: {
    component: "VariantSelection"
  },
  initial: "fetchProductVariantList",
  states: {
    fetchProductVariantList: {
      tags: ["loading"],
      on: {
        FINISH_FETCH: "selectProductVariant"
      },
      invoke: {
        id: "fetchVariantList",
        src: async (e) => {
          var t;
          return ((t = e.product) == null ? void 0 : t.id.toString()) === e.product_id ? e.product : await Nd(e.store_id, e.product_id);
        },
        onDone: {
          actions: [
            Hl(
              (e, t) => ({
                product: t.data,
                error: null
              })
            ),
            ih((e, t) => t.data.variants.length === 1 ? { type: "NEXT", variant_id: t.data.variants[0].id.toString() } : { type: "FINISH_FETCH" })
          ]
        },
        onError: {
          target: "#embed.error",
          actions: No
        }
      }
    },
    selectProductVariant: {}
  }
}, { assign: ah, send: Bl } = So, sh = {
  on: {
    PREVIOUS: "variant_selection",
    NEXT: "payment_method",
    FETCH: {
      internal: !0,
      target: [".fetchStates.fetching"]
    },
    FINISH_FETCH: {
      internal: !0,
      target: [".fetchStates.idle", ".overviewStates.idle"]
    }
  },
  meta: {
    component: "Overview"
  },
  type: "parallel",
  states: {
    fetchStates: {
      initial: "fetching",
      states: {
        fetching: {
          tags: ["fetching"],
          invoke: {
            id: "fetchProductVariant",
            src: async (e) => {
              var t;
              return {
                product: ((t = e.product) == null ? void 0 : t.id.toString()) === e.product_id ? e.product : await Nd(e.store_id, e.product_id, { withoutVariants: !0 }),
                variant: await eh(e.store_id, e.product_id, e.variant_id, {
                  coupon: e.coupon,
                  quantity: e.quantity,
                  extra: e.extra
                })
              };
            },
            onDone: {
              actions: [
                ah(
                  (e, t) => ({
                    product: t.data.product,
                    variant: t.data.variant,
                    quantity: e.quantity ?? t.data.variant.minimum_purchase_quantity,
                    error: null
                  })
                ),
                Bl("FINISH_FETCH")
              ]
            },
            onError: {
              actions: [No, Bl("FINISH_FETCH")]
            }
          }
        },
        idle: {}
      }
    },
    overviewStates: {
      initial: "loading",
      states: {
        loading: {
          tags: ["loading"]
        },
        idle: {}
      }
    }
  }
}, lh = {
  on: {
    PREVIOUS: "overview",
    CONNECT_DISCORD: "connect_discord",
    CUSTOMER_EMAIL: "customer_email"
  },
  meta: {
    component: "PaymentMethod"
  }
}, ch = {
  on: {
    NEXT: "final_step",
    CONNECT_DISCORD: "connect_discord",
    PAYMENT_METHODS: "payment_method"
  },
  meta: {
    component: "CustomerEmail"
  }
}, uh = `${Zr}/{store_id}/connect-discord`;
async function dh(e, t) {
  const n = Oo(uh, { store_id: e });
  return await Ao.get(n, t);
}
const { assign: fh, send: Gl } = So, mh = {
  on: {
    PREVIOUS: "payment_method",
    NEXT: "customer_email",
    FETCH: {
      internal: !0,
      target: [".fetchStates.fetching"]
    },
    FINISH_FETCH: {
      internal: !0,
      target: [".fetchStates.idle", ".overviewStates.idle"]
    }
  },
  meta: {
    component: "ConnectDiscord"
  },
  type: "parallel",
  states: {
    fetchStates: {
      initial: "fetching",
      states: {
        fetching: {
          tags: ["fetching"],
          invoke: {
            id: "fetchingDiscordData",
            src: async (e) => {
              var t;
              return await dh(e.store_id, {
                discord_token: ((t = e.discord_data) == null ? void 0 : t.discord_token) ?? sessionStorage.getItem("discord_token"),
                origin: window.location.href
              });
            },
            onDone: {
              actions: [
                fh((e, t) => ({
                  discord_data: t.data,
                  error: null
                })),
                Gl("FINISH_FETCH")
              ]
            },
            onError: {
              actions: [No, Gl("FINISH_FETCH")]
            }
          }
        },
        idle: {}
      }
    },
    overviewStates: {
      initial: "loading",
      states: {
        loading: {
          tags: ["loading"]
        },
        idle: {}
      }
    }
  }
}, ph = {
  on: {
    PREVIOUS: "customer_email",
    CONNECT_DISCORD: "connect_discord",
    PAYMENT_METHODS: "payment_method"
  },
  meta: {
    component: "FinalStep"
  },
  initial: "checkFinalStep",
  states: {
    checkFinalStep: {
      on: {
        CHECKOUT: "checkout_product"
      }
    },
    checkout_product: {
      invoke: {
        id: "checkout_product",
        src: async (e) => await Jb(e.store_id, e.product_id, e.variant_id, {
          coupon: e.coupon,
          quantity: e.quantity,
          extra: e.extra,
          customer_email: Ee.customer_email,
          payment_method: Ee.payment_method,
          additional_information: Ee.additional_information,
          vat_id: Ee.vat_id,
          country: Ee.country,
          discord_token: Ee.discord_token
        }),
        onDone: {
          target: "#embed.invoice_processed",
          actions: [
            Qi(
              (e, t) => ({
                order: t.data.payment_url,
                error: null
              })
            ),
            (e, t) => {
              window.open(t.data.payment_url, "_blank");
            }
          ]
        },
        onError: {
          target: "#embed.checkout.customer_email",
          actions: No
        }
      }
    }
  }
}, bh = {
  initial: "entry",
  states: {
    entry: Wb,
    variant_selection: oh,
    overview: sh,
    payment_method: lh,
    connect_discord: mh,
    customer_email: ch,
    final_step: ph
  }
}, hh = {}, vh = {
  closed: Gb,
  error: Yb,
  checkout: bh,
  invoice_processed: hh
}, gh = {
  id: "embed",
  initial: "closed",
  context: Ad,
  predictableActionArguments: !0,
  on: Bb,
  states: vh
}, yh = Vb(gh), _h = Od(yh).start();
function ut() {
  const { state: e, send: t } = Hb(_h);
  return {
    context: $(() => e.value.context),
    send: t,
    state: e
  };
}
const Ee = ir({
  customer_email: "",
  payment_method: null,
  additional_information: {},
  vat_id: "",
  country: "",
  discord_token: ""
});
function Id(e, t) {
  return D(), Y("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    fill: "currentColor",
    "aria-hidden": "true"
  }, [
    k("path", {
      "fill-rule": "evenodd",
      d: "M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zM12 8.25a.75.75 0 01.75.75v3.75a.75.75 0 01-1.5 0V9a.75.75 0 01.75-.75zm0 8.25a.75.75 0 100-1.5.75.75 0 000 1.5z",
      "clip-rule": "evenodd"
    })
  ]);
}
function wh(e, t) {
  return D(), Y("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    fill: "currentColor",
    "aria-hidden": "true"
  }, [
    k("path", {
      "fill-rule": "evenodd",
      d: "M3.75 12a.75.75 0 01.75-.75h15a.75.75 0 010 1.5h-15a.75.75 0 01-.75-.75z",
      "clip-rule": "evenodd"
    })
  ]);
}
function xh(e, t) {
  return D(), Y("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    fill: "currentColor",
    "aria-hidden": "true"
  }, [
    k("path", {
      "fill-rule": "evenodd",
      d: "M12 3.75a.75.75 0 01.75.75v6.75h6.75a.75.75 0 010 1.5h-6.75v6.75a.75.75 0 01-1.5 0v-6.75H4.5a.75.75 0 010-1.5h6.75V4.5a.75.75 0 01.75-.75z",
      "clip-rule": "evenodd"
    })
  ]);
}
function Cd(e, t) {
  return D(), Y("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    "stroke-width": "1.5",
    stroke: "currentColor",
    "aria-hidden": "true"
  }, [
    k("path", {
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      d: "M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
    })
  ]);
}
function Eh(e, t) {
  return D(), Y("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    fill: "none",
    viewBox: "0 0 24 24",
    "stroke-width": "1.5",
    stroke: "currentColor",
    "aria-hidden": "true"
  }, [
    k("path", {
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      d: "M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75"
    })
  ]);
}
const qe = (e, t) => {
  const n = e.__vccOpts || e;
  for (const [r, i] of t)
    n[r] = i;
  return n;
}, kh = {
  name: "MySpinner"
}, Sh = {
  class: "embed-animate-spin embed-h-5 embed-w-5",
  xmlns: "http://www.w3.org/2000/svg",
  fill: "none",
  viewBox: "0 0 24 24"
}, Oh = /* @__PURE__ */ k("circle", {
  class: "embed-opacity-25",
  cx: "12",
  cy: "12",
  r: "10",
  stroke: "currentColor",
  "stroke-width": "4"
}, null, -1), Ah = /* @__PURE__ */ k("path", {
  class: "embed-opacity-75",
  fill: "currentColor",
  d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
}, null, -1), Nh = [
  Oh,
  Ah
];
function Ih(e, t, n, r, i, o) {
  return D(), Y("svg", Sh, Nh);
}
const Ch = /* @__PURE__ */ qe(kh, [["render", Ih]]), Th = de({
  name: "MyButton",
  components: {
    Spinner: Ch
  },
  props: {
    loading: {
      type: Boolean,
      required: !1,
      default: !1
    },
    disabled: {
      type: Boolean,
      required: !1,
      default: !1
    }
  }
}), Ph = ["disabled"];
function Mh(e, t, n, r, i, o) {
  const a = te("Spinner");
  return D(), Y("button", {
    class: _e(["embed-inline-flex embed-items-center embed-justify-center sm:embed-text-sm embed-px-4 embed-py-2 embed-rounded-full focus:embed-ring-0 focus:embed-outline-none disabled:embed-opacity-75 disabled:embed-cursor-not-allowed embed-transition embed-duration-200 embed-ease-in-out", {
      "embed-font-semibold embed-text-zinc-300 embed-shadow-inner embed-bg-zinc-950 hover:embed-text-white hover:embed-shadow-zinc-300 focus:embed-shadow-zinc-400 dark:[background:linear-gradient(theme(colors.zinc.950),_theme(colors.zinc.950))_padding-box,_conic-gradient(theme(colors.zinc.400),_theme(colors.zinc.950)_25%,_theme(colors.zinc.950)_75%,_theme(colors.zinc.400)_100%)_border-box] dark:hover:embed-shadow-zinc-600 dark:focus:embed-shadow-zinc-600 dark:embed-border dark:embed-border-transparent": typeof e.$attrs.primary < "u",
      "embed-bg-zinc-50 embed-text-zinc-800 embed-shadow-inner embed-shadow-zinc-200 hover:embed-bg-zinc-100 hover:embed-shadow-zinc-300 focus:embed-shadow-zinc-400 dark:embed-text-zinc-300 dark:embed-shadow-neutral-900 dark:embed-bg-zinc-700 dark:hover:embed-shadow-black dark:focus:embed-shadow-neutral-800 embed-font-medium": typeof e.$attrs.outline < "u",
      "embed-bg-red-600 hover:embed-bg-red-700 embed-text-white focus:embed-ring-offset-2 embed-ring-offset-transparent focus:embed-ring-red-500": typeof e.$attrs.danger < "u"
    }]),
    disabled: e.disabled || e.loading
  }, [
    e.loading ? (D(), $e(a, { key: 1 })) : Vi(e.$slots, "default", { key: 0 })
  ], 10, Ph);
}
const Io = /* @__PURE__ */ qe(Th, [["render", Mh]]), Rh = de({
  name: "VariantSelection",
  components: {
    RadioGroup: Gu,
    RadioGroupDescription: qu,
    RadioGroupLabel: Wu,
    RadioGroupOption: Yu,
    DialogTitle: ln,
    MyButton: Io
  },
  setup() {
    const { context: e, send: t, state: n } = ut(), r = $(() => e.value.product), i = re(null);
    function o() {
      Qn(i) || t({
        type: "NEXT",
        variant_id: i.value
      });
    }
    return {
      state: n,
      product: r,
      selected_variant: i,
      selectVariant: o,
      context: e
    };
  }
}), Dh = { class: "embed-flex embed-flex-col embed-px-4 embed-pt-5 embed-pb-4 sm:embed-p-6" }, zh = /* @__PURE__ */ k("p", { class: "embed-mb-4 embed-font-normal embed-text-center embed-text-zinc-800 dark:embed-text-zinc-400 embed-text-xs" }, "Select the product you'd like to purchase", -1), Lh = { class: "embed-space-y-4" }, $h = { class: "embed-flex embed-items-center embed-flex-grow-0" }, Fh = { class: "embed-text-sm" }, Vh = { class: "embed-flex embed-flex-col sm:embed-flex-row sm:embed-justify-between embed-text-left embed-mt-2" }, jh = { class: "embed-flex embed-text-sm sm:embed-mt-0 sm:embed-block sm:embed-mr-4 sm:embed-text-right embed-w-auto embed-flex-shrink-0" }, Uh = /* @__PURE__ */ k("div", {
  class: "embed-absolute embed--inset-px embed-rounded-lg embed-pointer-events-none",
  "aria-hidden": "true"
}, null, -1), Hh = { class: "embed-mt-6 embed-w-full embed-justify-end embed-flex embed-items-center embed-col-span-2 embed-space-x-2" };
function Bh(e, t, n, r, i, o) {
  const a = te("DialogTitle"), s = te("RadioGroupLabel"), l = te("RadioGroupDescription"), c = te("RadioGroupOption"), u = te("RadioGroup"), f = te("MyButton");
  return D(), Y("div", null, [
    k("div", Dh, [
      H(a, {
        as: "h2",
        class: "embed-mb-1 embed-font-bold embed-text-center embed-text-black dark:embed-text-white embed-text-xl"
      }, {
        default: ne(() => [
          ye(ie(e.product.title), 1)
        ]),
        _: 1
      }),
      zh,
      H(u, {
        modelValue: e.selected_variant,
        "onUpdate:modelValue": t[0] || (t[0] = (d) => e.selected_variant = d)
      }, {
        default: ne(() => [
          H(s, { class: "embed-sr-only" }, {
            default: ne(() => [
              ye("Select the product variant")
            ]),
            _: 1
          }),
          k("div", Lh, [
            (D(!0), Y(De, null, zr(e.product.variants, (d) => (D(), $e(c, {
              key: d.id,
              as: "template",
              value: d.id
            }, {
              default: ne(({ checked: m }) => [
                k("div", {
                  class: _e(["embed-flex embed-flex-col dark:embed-border dark:embed-border-transparent embed-shadow-inner", [m ? "embed-bg-white dark:[background:linear-gradient(theme(colors.zinc.950),_theme(colors.zinc.950))_padding-box,_conic-gradient(theme(colors.zinc.400),_theme(colors.zinc.700)_25%,_theme(colors.zinc.700)_75%,_theme(colors.zinc.400)_100%)_border-box] embed-shadow-zinc-400 dark:embed-shadow-black" : "embed-shadow-zinc-200 hover:embed-shadow-zinc-300 focus:embed-shadow-zinc-400 dark:embed-shadow-neutral-900 dark:hover:embed-shadow-black dark:focus:embed-shadow-neutral-800 embed-bg-white dark:[background:linear-gradient(theme(colors.zinc.800),_theme(colors.zinc.800))_padding-box,_conic-gradient(theme(colors.zinc.500),_theme(colors.zinc.800)_25%,_theme(colors.zinc.800)_75%,_theme(colors.zinc.500)_100%)_border-box]", "embed-transition embed-duration-300 embed-ease-in-out embed-relative embed-rounded-lg embed-px-6 embed-py-4 embed-cursor-pointer sm:embed-flex sm:embed-justify-between focus:embed-outline-none"]])
                }, [
                  k("div", $h, [
                    k("div", Fh, [
                      H(s, {
                        as: "p",
                        class: "embed-font-bold embed-text-black dark:embed-text-white",
                        style: { "text-transform": "embed-capitalize" }
                      }, {
                        default: ne(() => [
                          ye(ie(d.title), 1)
                        ]),
                        _: 2
                      }, 1024)
                    ])
                  ]),
                  H(l, {
                    as: "div",
                    class: "embed-flex embed-text-xs embed-text-left"
                  }, {
                    default: ne(() => [
                      k("div", {
                        class: _e(["embed-flex embed-text-xs embed-text-left", [m ? "embed-text-black dark:embed-text-zinc-200" : "embed-text-zinc-500 dark:embed-text-zinc-400"]])
                      }, ie(d.description), 3)
                    ]),
                    _: 2
                  }, 1024),
                  k("div", Vh, [
                    k("div", jh, [
                      k("div", {
                        class: _e([m ? "embed-text-black dark:embed-text-zinc-200 embed-font-bold" : "embed-text-zinc-500 dark:embed-text-zinc-400 embed-font-medium"])
                      }, ie(d.price), 3)
                    ]),
                    H(l, {
                      as: "div",
                      class: "embed-flex embed-text-xs embed-text-left"
                    }, {
                      default: ne(() => [
                        k("div", {
                          class: _e(["embed-flex embed-text-xs embed-text-left", [m ? "embed-text-black dark:embed-text-zinc-200" : "embed-text-zinc-500 dark:embed-text-zinc-400"]])
                        }, ie(d.stock) + " in stock", 3)
                      ]),
                      _: 2
                    }, 1024)
                  ]),
                  Uh
                ], 2)
              ]),
              _: 2
            }, 1032, ["value"]))), 128))
          ])
        ]),
        _: 1
      }, 8, ["modelValue"]),
      k("div", Hh, [
        H(f, {
          loading: e.state.hasTag("loading"),
          class: _e(["embed-w-full", e.selected_variant == null ? "embed-hidden" : ""]),
          primary: "",
          onClick: t[1] || (t[1] = (d) => e.selectVariant())
        }, {
          default: ne(() => [
            ye("Continue")
          ]),
          _: 1
        }, 8, ["loading", "class"])
      ])
    ])
  ]);
}
const Gh = /* @__PURE__ */ qe(Rh, [["render", Bh]]), Yh = de({
  name: "NumberInput",
  components: {
    MinusIcon: wh,
    PlusIcon: xh
  },
  inheritAttrs: !1,
  props: {
    modelValue: {
      type: Number,
      default: null
    },
    min: {
      type: Number,
      default: null
    },
    max: {
      type: Number,
      default: null
    }
  },
  emits: ["update:modelValue"],
  setup(e, { emit: t }) {
    const { context: n } = ut(), r = n.value.variant.quantity_increments ?? 1;
    function i(u) {
      u = parseInt(u.toString()), isNaN(u) && (u = 0), u < (e.min ?? 1) ? u = e.min : e.max !== null && u > e.max && (u = e.max), t("update:modelValue", u);
    }
    const o = $(() => e.min !== e.max), a = $(() => o.value && (e.max ? e.modelValue < e.max : !0) && r > 0);
    function s() {
      a.value && i(e.modelValue + r);
    }
    const l = $(() => o.value && e.modelValue > (e.min ?? 1));
    function c() {
      l.value && i(e.modelValue - r);
    }
    return {
      emitUpdate: i,
      canModify: o,
      canIncrement: a,
      increment: s,
      canDecrement: l,
      decrement: c
    };
  }
}), Wh = { class: "embed-relative embed-group" }, qh = ["disabled"], Kh = ["value", "disabled"], Xh = ["disabled"];
function Jh(e, t, n, r, i, o) {
  const a = te("MinusIcon"), s = te("PlusIcon");
  return D(), Y("div", Wh, [
    k("button", {
      class: "embed-absolute embed-inset-y-0 embed-left-0 embed-pl-3 embed-flex embed-items-center embed-text-black dark:embed-text-white disabled:embed-opacity-50 disabled:embed-cursor-not-allowed",
      disabled: !e.canDecrement,
      onClick: t[0] || (t[0] = (l) => e.decrement())
    }, [
      H(a, { class: "embed-w-5 embed-h-5" })
    ], 8, qh),
    k("input", Or(e.$attrs, {
      value: e.modelValue,
      class: "embed-w-full embed-rounded-lg embed-text-center embed-border embed-border-transparent embed-bg-white dark:[background:linear-gradient(theme(colors.zinc.950),_theme(colors.zinc.950))_padding-box,_conic-gradient(theme(colors.zinc.400),_theme(colors.zinc.700)_25%,_theme(colors.zinc.700)_75%,_theme(colors.zinc.400)_100%)_border-box] embed-text-black dark:embed-text-white embed-placeholder-neutral-500 focus:embed-placeholder-neutral-800 dark:embed-placeholder-neutral-500 dark:focus:embed-placeholder-neutral-400 focus:embed-ring-0 embed-shadow-inner embed-shadow-zinc-200 hover:embed-shadow-zinc-300 focus:embed-shadow-zinc-400 dark:embed-shadow-black dark:hover:embed-shadow-zinc-600 dark:focus:embed-shadow-zinc-600 embed-transition embed-duration-200 embed-ease-in-out disabled:embed-bg-zinc-100 dark:disabled:embed-bg-zinc-900 disabled:embed-opacity-70",
      type: "text",
      inputmode: "numeric",
      disabled: !e.canModify,
      onInput: t[1] || (t[1] = (l) => e.emitUpdate(l.target.value))
    }), null, 16, Kh),
    k("button", {
      class: "embed-absolute embed-inset-y-0 embed-right-0 embed-pr-3 embed-flex embed-items-center embed-text-black dark:embed-text-white disabled:embed-opacity-50 disabled:embed-cursor-not-allowed",
      disabled: !e.canIncrement,
      onClick: t[2] || (t[2] = (l) => e.increment())
    }, [
      H(s, { class: "embed-w-5 embed-h-5" })
    ], 8, Xh)
  ]);
}
const Qh = /* @__PURE__ */ qe(Yh, [["render", Jh]]), Zh = de({
  name: "ProductOverview",
  components: {
    MyButton: Io,
    DialogTitle: ln,
    NumberInput: Qh
  },
  setup() {
    const { context: e, state: t, send: n } = ut(), r = ir({
      coupon: e.value.coupon ?? "",
      quantity: e.value.quantity ?? 0,
      extra: e.value.extra ?? "0.00"
    }), i = re(e.value.extra !== void 0 && e.value.extra !== "0.00"), o = re(e.value.coupon == "");
    function a(f, d) {
      n([
        {
          type: "UPDATE_CONTEXT",
          [f]: d ?? r[f]
        },
        "FETCH"
      ]);
    }
    bt(
      () => r.quantity,
      (f) => {
        a("quantity", f);
      }
    );
    const s = $(() => e.value.product), l = $(() => e.value.variant), c = $(() => l.value.stock === !1), u = $(() => t.value.hasTag("fetching"));
    return {
      product: s,
      variant: l,
      send: n,
      data: r,
      context: e,
      orMore: i,
      applyCoupon: o,
      apply: a,
      isSoldOut: c,
      isLoading: u
    };
  }
}), e0 = {
  key: 0,
  class: "aspect-w-3 aspect-h-1 embed-flex-shrink-0 embed-rounded-t-2xl embed-overflow-hidden embed-bg-inherit"
}, t0 = ["src", "alt"], n0 = { class: "embed-flex embed-flex-col embed-px-4 embed-pt-5 embed-pb-4 sm:embed-p-6 embed-space-y-3" }, r0 = ["innerHTML"], i0 = { class: "embed-flex embed-flex-col embed-mx-auto embed-items-center" }, o0 = {
  key: 0,
  class: "embed-text-xl embed-text-center embed-font-light embed-text-black dark:embed-text-white embed-line-through"
}, a0 = { class: "embed-text-xl embed-text-center embed-text-black dark:embed-text-white embed-font-bold" }, s0 = { key: 0 }, l0 = { class: "embed-flex embed-flex-col" }, c0 = { class: "embed-flex embed-rounded-md embed-w-full" }, u0 = { class: "embed-relative embed-flex embed-items-stretch embed-flex-grow focus-within:embed-z-10" }, d0 = /* @__PURE__ */ k("span", null, "Add", -1), f0 = ["textContent"], m0 = { class: "embed-text-zinc-900 dark:embed-text-zinc-100 embed-overflow-auto embed-overscroll-contain embed-h-32 embed-text-sm embed-w-full embed-text-center embed-px-4 embed-py-5 sm:embed-p-6 embed-rounded-xl embed-bg-neutral-50 embed-p-2 embed-shadow-inner embed-shadow-zinc-400 dark:embed-bg-zinc-950 dark:embed-shadow-black" }, p0 = ["innerHTML"], b0 = { class: "embed-flex embed-flex-col embed-w-full" }, h0 = { class: "embed-flex embed-flex-col embed-gap-1 embed-rounded-md embed-shadow-sm embed-flex-shrink-0" }, v0 = { class: "embed-flex embed-rounded-md" }, g0 = { class: "embed-relative embed-flex embed-items-stretch embed-flex-grow focus-within:embed-z-10" }, y0 = /* @__PURE__ */ k("span", null, "Apply", -1), _0 = ["textContent"], w0 = {
  key: 3,
  class: "embed-mt-3 embed-w-3/4 embed-mx-auto embed-text-center embed-p-2 embed-bg-emerald-600 dark:embed-bg-emerald-900 embed-text-white embed-text-xs embed-rounded-full"
}, x0 = {
  key: 1,
  class: "embed-flex embed-flex-col embed-gap-1"
}, E0 = { class: "embed-flex embed-space-x-2" }, k0 = { class: "embed-inline-block embed-text-left embed-text-xs embed-font-medium embed-ml-11 embed-text-black dark:embed-text-white embed-space-x-1" }, S0 = {
  key: 0,
  class: "embed-text-lg"
}, O0 = { key: 1 }, A0 = /* @__PURE__ */ k("span", null, "in stock ", -1), N0 = ["textContent"];
function I0(e, t, n, r, i, o) {
  var c, u, f, d, m, p, h, _, y, g, w, x, I, U;
  const a = te("DialogTitle"), s = te("MyButton"), l = te("NumberInput");
  return D(), Y("div", null, [
    ((c = e.variant.images) == null ? void 0 : c.length) > 0 ? (D(), Y("div", e0, [
      k("img", {
        class: "embed-object-contain",
        src: e.variant.images[0],
        alt: e.variant.title
      }, null, 8, t0)
    ])) : xe("", !0),
    k("div", n0, [
      k("div", null, [
        H(a, {
          as: "h1",
          class: "embed-font-bold embed-text-center embed-text-black dark:embed-text-white embed-text-xl"
        }, {
          default: ne(() => [
            ye(ie(e.product.title), 1)
          ]),
          _: 1
        }),
        e.variant.description !== "Default Variant" && e.variant.description !== "default variant" ? (D(), Y("p", {
          key: 0,
          class: "dark:embed-text-zinc-400 embed-text-xs",
          innerHTML: e.variant.description
        }, null, 8, r0)) : xe("", !0)
      ]),
      k("div", i0, [
        e.variant.price !== e.variant.total ? (D(), Y("div", o0, ie(e.variant.price), 1)) : xe("", !0),
        k("div", a0, ie(e.variant.total), 1)
      ]),
      e.variant.humble ? (D(), Y("div", s0, [
        e.orMore ? (D(), $e(Wn, {
          key: 0,
          appear: "",
          "enter-from-class": "embed-opacity-0 embed-scale-0",
          "enter-to-class": "opacity-1 embed-scale-100",
          "enter-active-class": "embed-transition embed-transform origin",
          "leave-from-class": "opacity-1 embed-scale-100",
          "leave-to-class": "embed-opacity-0 embed-scale-0",
          "leave-active-class": "embed-transition embed-transform"
        }, {
          default: ne(() => {
            var M, C, R, W, F;
            return [
              k("div", l0, [
                k("div", c0, [
                  k("div", u0, [
                    Fi(k("input", {
                      id: "extra",
                      "onUpdate:modelValue": t[0] || (t[0] = (A) => e.data.extra = A),
                      type: "number",
                      name: "extra",
                      class: "embed-rounded-md embed-rounded-r-none embed-border-r-0 embed-w-full embed-bg-white dark:[background:linear-gradient(theme(colors.zinc.950),_theme(colors.zinc.950))_padding-box,_conic-gradient(theme(colors.zinc.400),_theme(colors.zinc.700)_25%,_theme(colors.zinc.700)_75%,_theme(colors.zinc.400)_100%)_border-box] embed-text-black dark:embed-text-white embed-placeholder-neutral-500 focus:embed-placeholder-neutral-800 dark:embed-placeholder-neutral-500 dark:focus:embed-placeholder-neutral-400 focus:embed-ring-0 embed-shadow-inner embed-shadow-zinc-200 hover:embed-shadow-zinc-300 focus:embed-shadow-zinc-400 dark:embed-shadow-black dark:hover:embed-shadow-zinc-600 dark:focus:embed-shadow-zinc-600 embed-transition embed-duration-200 embed-ease-in-out disabled:embed-bg-zinc-100 dark:disabled:embed-bg-zinc-900 disabled:embed-opacity-70 embed-border embed-border-transparent focus:embed-border-transparent",
                      placeholder: "0.00"
                    }, null, 512), [
                      [wl, e.data.extra]
                    ])
                  ]),
                  H(s, {
                    primary: "",
                    class: "embed-rounded-l-none",
                    onClick: t[1] || (t[1] = (A) => e.apply("extra"))
                  }, {
                    default: ne(() => [
                      d0
                    ]),
                    _: 1
                  })
                ]),
                (R = (C = (M = e.context.error) == null ? void 0 : M.errors) == null ? void 0 : C.extra) != null && R[0] ? (D(), Y("p", {
                  key: 0,
                  class: "embed-ml-1.5 embed-text-left embed-text-sm embed-text-red-600 dark:embed-text-red embed-w-full",
                  textContent: ie((F = (W = e.context.error) == null ? void 0 : W.errors) == null ? void 0 : F.extra[0])
                }, null, 8, f0)) : xe("", !0)
              ])
            ];
          }),
          _: 1
        })) : (D(), Y("button", {
          key: 1,
          class: "dark:embed-border dark:embed-border-transparent embed-inline-flex embed-items-center embed-justify-center sm:embed-text-sm embed-px-2 embed-py-1 embed-rounded-full focus:embed-ring-0 focus:embed-outline-none embed-transition embed-duration-200 embed-ease-in-out embed-font-semibold embed-text-zinc-300 embed-shadow-inner [background:linear-gradient(theme(colors.zinc.950),_theme(colors.zinc.950))_padding-box,_conic-gradient(theme(colors.zinc.500),_theme(colors.zinc.500)_25%,_theme(colors.zinc.500)_75%,_theme(colors.zinc.500)_100%)_border-box] hover:embed-text-white hover:embed-shadow-zinc-300 focus:embed-shadow-zinc-400 dark:[background:linear-gradient(theme(colors.zinc.950),_theme(colors.zinc.950))_padding-box,_conic-gradient(theme(colors.zinc.400),_theme(colors.zinc.950)_25%,_theme(colors.zinc.950)_75%,_theme(colors.zinc.400)_100%)_border-box] dark:hover:embed-shadow-zinc-600 dark:focus:embed-shadow-zinc-600",
          onClick: t[2] || (t[2] = (M) => e.orMore = !0)
        }, "Add more"))
      ])) : xe("", !0),
      k("div", m0, [
        k("p", {
          innerHTML: e.product.description
        }, null, 8, p0)
      ]),
      k("div", b0, [
        e.applyCoupon ? (D(), $e(Wn, {
          key: 0,
          appear: "",
          "enter-from-class": "embed-opacity-0 embed-scale-0",
          "enter-to-class": "opacity-1 embed-scale-100",
          "enter-active-class": "embed-transition embed-transform origin",
          "leave-from-class": "opacity-1 embed-scale-100",
          "leave-to-class": "embed-opacity-0 embed-scale-0",
          "leave-active-class": "embed-transition embed-transform"
        }, {
          default: ne(() => [
            k("div", h0, [
              k("div", v0, [
                k("div", g0, [
                  Fi(k("input", {
                    "onUpdate:modelValue": t[3] || (t[3] = (M) => e.data.coupon = M),
                    type: "text",
                    name: "coupon-code",
                    class: "embed-rounded-md embed-rounded-r-none embed-border-r-0 embed-w-full embed-bg-white dark:[background:linear-gradient(theme(colors.zinc.950),_theme(colors.zinc.950))_padding-box,_conic-gradient(theme(colors.zinc.400),_theme(colors.zinc.700)_25%,_theme(colors.zinc.700)_75%,_theme(colors.zinc.400)_100%)_border-box] embed-text-black dark:embed-text-white embed-placeholder-neutral-500 focus:embed-placeholder-neutral-800 dark:embed-placeholder-neutral-500 dark:focus:embed-placeholder-neutral-400 focus:embed-ring-0 embed-shadow-inner embed-shadow-zinc-200 hover:embed-shadow-zinc-300 focus:embed-shadow-zinc-400 dark:embed-shadow-black dark:hover:embed-shadow-zinc-600 dark:focus:embed-shadow-zinc-600 embed-transition embed-duration-200 embed-ease-in-out disabled:embed-bg-zinc-100 dark:disabled:embed-bg-zinc-900 disabled:embed-opacity-70 embed-border embed-border-transparent focus:embed-border-transparent",
                    placeholder: "Enter coupon code"
                  }, null, 512), [
                    [wl, e.data.coupon]
                  ])
                ]),
                H(s, {
                  primary: "",
                  loading: e.isLoading,
                  type: "button",
                  class: "embed-relative embed-inline-flex embed-items-center embed-space-x-2 embed-rounded-l-none",
                  onClick: t[4] || (t[4] = (M) => e.apply("coupon"))
                }, {
                  default: ne(() => [
                    y0
                  ]),
                  _: 1
                }, 8, ["loading"])
              ])
            ])
          ]),
          _: 1
        })) : (D(), Y("button", {
          key: 1,
          class: "embed-py-2 embed-text-zinc-500 hover:embed-text-zinc-800 dark:hover:embed-text-zinc-200 embed-font-semibold embed-mx-auto embed-transition embed-duration-100 embed-ease-in-out",
          onClick: t[5] || (t[5] = (M) => e.applyCoupon = !0)
        }, "Have a coupon code?")),
        (d = (f = (u = e.context.error) == null ? void 0 : u.errors) == null ? void 0 : f.coupon) != null && d[0] ? (D(), Y("p", {
          key: 2,
          class: "embed-mt-1 embed-ml-1.5 embed-text-left embed-text-xs embed-text-red-600 dark:embed-text-red embed-w-full",
          textContent: ie((p = (m = e.context.error) == null ? void 0 : m.errors) == null ? void 0 : p.coupon[0])
        }, null, 8, _0)) : xe("", !0),
        e.variant.coupon && ((y = (_ = (h = e.context.error) == null ? void 0 : h.errors) == null ? void 0 : _.coupon) == null ? void 0 : y[0]) === void 0 ? (D(), Y("p", w0, "A " + ie(e.variant.coupon) + " coupon has successfully been applied!", 1)) : xe("", !0)
      ]),
      e.variant.visibility == "PUBLIC" || e.variant.visibility == "HIDDEN" ? (D(), Y("div", x0, [
        k("div", E0, [
          H(l, {
            modelValue: e.data.quantity,
            "onUpdate:modelValue": t[6] || (t[6] = (M) => e.data.quantity = M),
            min: e.variant.minimum_purchase_quantity,
            max: e.variant.maximum_purchase_quantity
          }, null, 8, ["modelValue", "min", "max"]),
          H(s, {
            loading: e.isLoading,
            disabled: e.isSoldOut,
            style: Kr({ "background-color": e.context.customization.theme }),
            class: "embed-w-full disabled:embed-bg-red-600 !embed-text-lg embed-text-white embed-font-medium embed-rounded-md disabled:focus:embed-ring-zinc-500",
            primary: "",
            onClick: t[7] || (t[7] = (M) => e.send("NEXT"))
          }, {
            default: ne(() => [
              ye(ie(e.isSoldOut ? "Sold out" : "Buy now"), 1)
            ]),
            _: 1
          }, 8, ["loading", "disabled", "style"])
        ]),
        k("p", k0, [
          e.variant.stock ? (D(), Y("span", O0, ie(e.variant.stock), 1)) : (D(), Y("span", S0, "0")),
          A0
        ]),
        (x = (w = (g = e.context.error) == null ? void 0 : g.errors) == null ? void 0 : w.quantity) != null && x[0] ? (D(), Y("p", {
          key: 0,
          class: "embed-ml-1.5 embed-text-left embed-text-sm embed-text-red-600 dark:embed-text-red embed-w-full",
          textContent: ie((U = (I = e.context.error) == null ? void 0 : I.errors) == null ? void 0 : U.quantity[0])
        }, null, 8, N0)) : xe("", !0)
      ])) : xe("", !0)
    ])
  ]);
}
const C0 = /* @__PURE__ */ qe(Zh, [["render", I0]]), T0 = de({
  name: "MyNavigator",
  components: {
    MyButton: Io
  },
  props: {
    back: {
      type: Object,
      required: !1,
      default: () => ({
        type: "PREVIOUS"
      })
    },
    next: {
      type: Object,
      required: !1,
      default: () => ({
        type: "NEXT"
      })
    },
    text: {
      type: String,
      required: !1,
      default: () => "Continue"
    }
  },
  setup() {
    const { state: e, send: t } = ut();
    return {
      send: t,
      state: e
    };
  }
}), P0 = { class: "embed-mt-6 embed-w-full embed-justify-between embed-flex embed-items-center embed-col-span-2 embed-space-x-2" };
function M0(e, t, n, r, i, o) {
  const a = te("MyButton");
  return D(), Y("div", P0, [
    H(a, {
      outline: "",
      class: "embed-w-1/2",
      disabled: e.state.hasTag("loading"),
      onClick: t[0] || (t[0] = (s) => e.send(e.back))
    }, {
      default: ne(() => [
        ye("Back")
      ]),
      _: 1
    }, 8, ["disabled"]),
    H(a, {
      loading: e.state.hasTag("loading"),
      class: "embed-w-1/2",
      style: Kr({ "background-color": e.state.context.customization.theme }),
      primary: "",
      onClick: t[1] || (t[1] = (s) => e.send(e.next))
    }, {
      default: ne(() => [
        ye(ie(e.text), 1)
      ]),
      _: 1
    }, 8, ["loading", "style"])
  ]);
}
const ei = /* @__PURE__ */ qe(T0, [["render", M0]]);
function Yl(e, t) {
  var n = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var r = Object.getOwnPropertySymbols(e);
    t && (r = r.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), n.push.apply(n, r);
  }
  return n;
}
function B(e) {
  for (var t = 1; t < arguments.length; t++) {
    var n = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Yl(Object(n), !0).forEach(function(r) {
      Be(e, r, n[r]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Yl(Object(n)).forEach(function(r) {
      Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(n, r));
    });
  }
  return e;
}
function Zi(e) {
  "@babel/helpers - typeof";
  return Zi = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Zi(e);
}
function R0(e, t) {
  if (!(e instanceof t))
    throw new TypeError("Cannot call a class as a function");
}
function Wl(e, t) {
  for (var n = 0; n < t.length; n++) {
    var r = t[n];
    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r);
  }
}
function D0(e, t, n) {
  return t && Wl(e.prototype, t), n && Wl(e, n), Object.defineProperty(e, "prototype", {
    writable: !1
  }), e;
}
function Be(e, t, n) {
  return t in e ? Object.defineProperty(e, t, {
    value: n,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : e[t] = n, e;
}
function gs(e, t) {
  return L0(e) || F0(e, t) || Td(e, t) || j0();
}
function ti(e) {
  return z0(e) || $0(e) || Td(e) || V0();
}
function z0(e) {
  if (Array.isArray(e))
    return Aa(e);
}
function L0(e) {
  if (Array.isArray(e))
    return e;
}
function $0(e) {
  if (typeof Symbol < "u" && e[Symbol.iterator] != null || e["@@iterator"] != null)
    return Array.from(e);
}
function F0(e, t) {
  var n = e == null ? null : typeof Symbol < "u" && e[Symbol.iterator] || e["@@iterator"];
  if (n != null) {
    var r = [], i = !0, o = !1, a, s;
    try {
      for (n = n.call(e); !(i = (a = n.next()).done) && (r.push(a.value), !(t && r.length === t)); i = !0)
        ;
    } catch (l) {
      o = !0, s = l;
    } finally {
      try {
        !i && n.return != null && n.return();
      } finally {
        if (o)
          throw s;
      }
    }
    return r;
  }
}
function Td(e, t) {
  if (e) {
    if (typeof e == "string")
      return Aa(e, t);
    var n = Object.prototype.toString.call(e).slice(8, -1);
    if (n === "Object" && e.constructor && (n = e.constructor.name), n === "Map" || n === "Set")
      return Array.from(e);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))
      return Aa(e, t);
  }
}
function Aa(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var n = 0, r = new Array(t); n < t; n++)
    r[n] = e[n];
  return r;
}
function V0() {
  throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function j0() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
var ql = function() {
}, ys = {}, Pd = {}, Md = null, Rd = {
  mark: ql,
  measure: ql
};
try {
  typeof window < "u" && (ys = window), typeof document < "u" && (Pd = document), typeof MutationObserver < "u" && (Md = MutationObserver), typeof performance < "u" && (Rd = performance);
} catch {
}
var U0 = ys.navigator || {}, Kl = U0.userAgent, Xl = Kl === void 0 ? "" : Kl, on = ys, Ie = Pd, Jl = Md, gi = Rd;
on.document;
var Bt = !!Ie.documentElement && !!Ie.head && typeof Ie.addEventListener == "function" && typeof Ie.createElement == "function", Dd = ~Xl.indexOf("MSIE") || ~Xl.indexOf("Trident/"), yi, _i, wi, xi, Ei, Vt = "___FONT_AWESOME___", Na = 16, zd = "fa", Ld = "svg-inline--fa", On = "data-fa-i2svg", Ia = "data-fa-pseudo-element", H0 = "data-fa-pseudo-element-pending", _s = "data-prefix", ws = "data-icon", Ql = "fontawesome-i2svg", B0 = "async", G0 = ["HTML", "HEAD", "STYLE", "SCRIPT"], $d = function() {
  try {
    return !0;
  } catch {
    return !1;
  }
}(), Ne = "classic", Re = "sharp", xs = [Ne, Re];
function ni(e) {
  return new Proxy(e, {
    get: function(n, r) {
      return r in n ? n[r] : n[Ne];
    }
  });
}
var Hr = ni((yi = {}, Be(yi, Ne, {
  fa: "solid",
  fas: "solid",
  "fa-solid": "solid",
  far: "regular",
  "fa-regular": "regular",
  fal: "light",
  "fa-light": "light",
  fat: "thin",
  "fa-thin": "thin",
  fad: "duotone",
  "fa-duotone": "duotone",
  fab: "brands",
  "fa-brands": "brands",
  fak: "kit",
  "fa-kit": "kit"
}), Be(yi, Re, {
  fa: "solid",
  fass: "solid",
  "fa-solid": "solid",
  fasr: "regular",
  "fa-regular": "regular",
  fasl: "light",
  "fa-light": "light"
}), yi)), Br = ni((_i = {}, Be(_i, Ne, {
  solid: "fas",
  regular: "far",
  light: "fal",
  thin: "fat",
  duotone: "fad",
  brands: "fab",
  kit: "fak"
}), Be(_i, Re, {
  solid: "fass",
  regular: "fasr",
  light: "fasl"
}), _i)), Gr = ni((wi = {}, Be(wi, Ne, {
  fab: "fa-brands",
  fad: "fa-duotone",
  fak: "fa-kit",
  fal: "fa-light",
  far: "fa-regular",
  fas: "fa-solid",
  fat: "fa-thin"
}), Be(wi, Re, {
  fass: "fa-solid",
  fasr: "fa-regular",
  fasl: "fa-light"
}), wi)), Y0 = ni((xi = {}, Be(xi, Ne, {
  "fa-brands": "fab",
  "fa-duotone": "fad",
  "fa-kit": "fak",
  "fa-light": "fal",
  "fa-regular": "far",
  "fa-solid": "fas",
  "fa-thin": "fat"
}), Be(xi, Re, {
  "fa-solid": "fass",
  "fa-regular": "fasr",
  "fa-light": "fasl"
}), xi)), W0 = /fa(s|r|l|t|d|b|k|ss|sr|sl)?[\-\ ]/, Fd = "fa-layers-text", q0 = /Font ?Awesome ?([56 ]*)(Solid|Regular|Light|Thin|Duotone|Brands|Free|Pro|Sharp|Kit)?.*/i, K0 = ni((Ei = {}, Be(Ei, Ne, {
  900: "fas",
  400: "far",
  normal: "far",
  300: "fal",
  100: "fat"
}), Be(Ei, Re, {
  900: "fass",
  400: "fasr",
  300: "fasl"
}), Ei)), Vd = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], X0 = Vd.concat([11, 12, 13, 14, 15, 16, 17, 18, 19, 20]), J0 = ["class", "data-prefix", "data-icon", "data-fa-transform", "data-fa-mask"], _n = {
  GROUP: "duotone-group",
  SWAP_OPACITY: "swap-opacity",
  PRIMARY: "primary",
  SECONDARY: "secondary"
}, Yr = /* @__PURE__ */ new Set();
Object.keys(Br[Ne]).map(Yr.add.bind(Yr));
Object.keys(Br[Re]).map(Yr.add.bind(Yr));
var Q0 = [].concat(xs, ti(Yr), ["2xs", "xs", "sm", "lg", "xl", "2xl", "beat", "border", "fade", "beat-fade", "bounce", "flip-both", "flip-horizontal", "flip-vertical", "flip", "fw", "inverse", "layers-counter", "layers-text", "layers", "li", "pull-left", "pull-right", "pulse", "rotate-180", "rotate-270", "rotate-90", "rotate-by", "shake", "spin-pulse", "spin-reverse", "spin", "stack-1x", "stack-2x", "stack", "ul", _n.GROUP, _n.SWAP_OPACITY, _n.PRIMARY, _n.SECONDARY]).concat(Vd.map(function(e) {
  return "".concat(e, "x");
})).concat(X0.map(function(e) {
  return "w-".concat(e);
})), Ir = on.FontAwesomeConfig || {};
function Z0(e) {
  var t = Ie.querySelector("script[" + e + "]");
  if (t)
    return t.getAttribute(e);
}
function ev(e) {
  return e === "" ? !0 : e === "false" ? !1 : e === "true" ? !0 : e;
}
if (Ie && typeof Ie.querySelector == "function") {
  var tv = [["data-family-prefix", "familyPrefix"], ["data-css-prefix", "cssPrefix"], ["data-family-default", "familyDefault"], ["data-style-default", "styleDefault"], ["data-replacement-class", "replacementClass"], ["data-auto-replace-svg", "autoReplaceSvg"], ["data-auto-add-css", "autoAddCss"], ["data-auto-a11y", "autoA11y"], ["data-search-pseudo-elements", "searchPseudoElements"], ["data-observe-mutations", "observeMutations"], ["data-mutate-approach", "mutateApproach"], ["data-keep-original-source", "keepOriginalSource"], ["data-measure-performance", "measurePerformance"], ["data-show-missing-icons", "showMissingIcons"]];
  tv.forEach(function(e) {
    var t = gs(e, 2), n = t[0], r = t[1], i = ev(Z0(n));
    i != null && (Ir[r] = i);
  });
}
var jd = {
  styleDefault: "solid",
  familyDefault: "classic",
  cssPrefix: zd,
  replacementClass: Ld,
  autoReplaceSvg: !0,
  autoAddCss: !0,
  autoA11y: !0,
  searchPseudoElements: !1,
  observeMutations: !0,
  mutateApproach: "async",
  keepOriginalSource: !0,
  measurePerformance: !1,
  showMissingIcons: !0
};
Ir.familyPrefix && (Ir.cssPrefix = Ir.familyPrefix);
var Zn = B(B({}, jd), Ir);
Zn.autoReplaceSvg || (Zn.observeMutations = !1);
var K = {};
Object.keys(jd).forEach(function(e) {
  Object.defineProperty(K, e, {
    enumerable: !0,
    set: function(n) {
      Zn[e] = n, Cr.forEach(function(r) {
        return r(K);
      });
    },
    get: function() {
      return Zn[e];
    }
  });
});
Object.defineProperty(K, "familyPrefix", {
  enumerable: !0,
  set: function(t) {
    Zn.cssPrefix = t, Cr.forEach(function(n) {
      return n(K);
    });
  },
  get: function() {
    return Zn.cssPrefix;
  }
});
on.FontAwesomeConfig = K;
var Cr = [];
function nv(e) {
  return Cr.push(e), function() {
    Cr.splice(Cr.indexOf(e), 1);
  };
}
var Kt = Na, Tt = {
  size: 16,
  x: 0,
  y: 0,
  rotate: 0,
  flipX: !1,
  flipY: !1
};
function rv(e) {
  if (!(!e || !Bt)) {
    var t = Ie.createElement("style");
    t.setAttribute("type", "text/css"), t.innerHTML = e;
    for (var n = Ie.head.childNodes, r = null, i = n.length - 1; i > -1; i--) {
      var o = n[i], a = (o.tagName || "").toUpperCase();
      ["STYLE", "LINK"].indexOf(a) > -1 && (r = o);
    }
    return Ie.head.insertBefore(t, r), e;
  }
}
var iv = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
function Wr() {
  for (var e = 12, t = ""; e-- > 0; )
    t += iv[Math.random() * 62 | 0];
  return t;
}
function lr(e) {
  for (var t = [], n = (e || []).length >>> 0; n--; )
    t[n] = e[n];
  return t;
}
function Es(e) {
  return e.classList ? lr(e.classList) : (e.getAttribute("class") || "").split(" ").filter(function(t) {
    return t;
  });
}
function Ud(e) {
  return "".concat(e).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function ov(e) {
  return Object.keys(e || {}).reduce(function(t, n) {
    return t + "".concat(n, '="').concat(Ud(e[n]), '" ');
  }, "").trim();
}
function Co(e) {
  return Object.keys(e || {}).reduce(function(t, n) {
    return t + "".concat(n, ": ").concat(e[n].trim(), ";");
  }, "");
}
function ks(e) {
  return e.size !== Tt.size || e.x !== Tt.x || e.y !== Tt.y || e.rotate !== Tt.rotate || e.flipX || e.flipY;
}
function av(e) {
  var t = e.transform, n = e.containerWidth, r = e.iconWidth, i = {
    transform: "translate(".concat(n / 2, " 256)")
  }, o = "translate(".concat(t.x * 32, ", ").concat(t.y * 32, ") "), a = "scale(".concat(t.size / 16 * (t.flipX ? -1 : 1), ", ").concat(t.size / 16 * (t.flipY ? -1 : 1), ") "), s = "rotate(".concat(t.rotate, " 0 0)"), l = {
    transform: "".concat(o, " ").concat(a, " ").concat(s)
  }, c = {
    transform: "translate(".concat(r / 2 * -1, " -256)")
  };
  return {
    outer: i,
    inner: l,
    path: c
  };
}
function sv(e) {
  var t = e.transform, n = e.width, r = n === void 0 ? Na : n, i = e.height, o = i === void 0 ? Na : i, a = e.startCentered, s = a === void 0 ? !1 : a, l = "";
  return s && Dd ? l += "translate(".concat(t.x / Kt - r / 2, "em, ").concat(t.y / Kt - o / 2, "em) ") : s ? l += "translate(calc(-50% + ".concat(t.x / Kt, "em), calc(-50% + ").concat(t.y / Kt, "em)) ") : l += "translate(".concat(t.x / Kt, "em, ").concat(t.y / Kt, "em) "), l += "scale(".concat(t.size / Kt * (t.flipX ? -1 : 1), ", ").concat(t.size / Kt * (t.flipY ? -1 : 1), ") "), l += "rotate(".concat(t.rotate, "deg) "), l;
}
var lv = `:root, :host {
  --fa-font-solid: normal 900 1em/1 "Font Awesome 6 Solid";
  --fa-font-regular: normal 400 1em/1 "Font Awesome 6 Regular";
  --fa-font-light: normal 300 1em/1 "Font Awesome 6 Light";
  --fa-font-thin: normal 100 1em/1 "Font Awesome 6 Thin";
  --fa-font-duotone: normal 900 1em/1 "Font Awesome 6 Duotone";
  --fa-font-sharp-solid: normal 900 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-regular: normal 400 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-light: normal 300 1em/1 "Font Awesome 6 Sharp";
  --fa-font-brands: normal 400 1em/1 "Font Awesome 6 Brands";
}

svg:not(:root).svg-inline--fa, svg:not(:host).svg-inline--fa {
  overflow: visible;
  box-sizing: content-box;
}

.svg-inline--fa {
  display: var(--fa-display, inline-block);
  height: 1em;
  overflow: visible;
  vertical-align: -0.125em;
}
.svg-inline--fa.fa-2xs {
  vertical-align: 0.1em;
}
.svg-inline--fa.fa-xs {
  vertical-align: 0em;
}
.svg-inline--fa.fa-sm {
  vertical-align: -0.0714285705em;
}
.svg-inline--fa.fa-lg {
  vertical-align: -0.2em;
}
.svg-inline--fa.fa-xl {
  vertical-align: -0.25em;
}
.svg-inline--fa.fa-2xl {
  vertical-align: -0.3125em;
}
.svg-inline--fa.fa-pull-left {
  margin-right: var(--fa-pull-margin, 0.3em);
  width: auto;
}
.svg-inline--fa.fa-pull-right {
  margin-left: var(--fa-pull-margin, 0.3em);
  width: auto;
}
.svg-inline--fa.fa-li {
  width: var(--fa-li-width, 2em);
  top: 0.25em;
}
.svg-inline--fa.fa-fw {
  width: var(--fa-fw-width, 1.25em);
}

.fa-layers svg.svg-inline--fa {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
}

.fa-layers-counter, .fa-layers-text {
  display: inline-block;
  position: absolute;
  text-align: center;
}

.fa-layers {
  display: inline-block;
  height: 1em;
  position: relative;
  text-align: center;
  vertical-align: -0.125em;
  width: 1em;
}
.fa-layers svg.svg-inline--fa {
  -webkit-transform-origin: center center;
          transform-origin: center center;
}

.fa-layers-text {
  left: 50%;
  top: 50%;
  -webkit-transform: translate(-50%, -50%);
          transform: translate(-50%, -50%);
  -webkit-transform-origin: center center;
          transform-origin: center center;
}

.fa-layers-counter {
  background-color: var(--fa-counter-background-color, #ff253a);
  border-radius: var(--fa-counter-border-radius, 1em);
  box-sizing: border-box;
  color: var(--fa-inverse, #fff);
  line-height: var(--fa-counter-line-height, 1);
  max-width: var(--fa-counter-max-width, 5em);
  min-width: var(--fa-counter-min-width, 1.5em);
  overflow: hidden;
  padding: var(--fa-counter-padding, 0.25em 0.5em);
  right: var(--fa-right, 0);
  text-overflow: ellipsis;
  top: var(--fa-top, 0);
  -webkit-transform: scale(var(--fa-counter-scale, 0.25));
          transform: scale(var(--fa-counter-scale, 0.25));
  -webkit-transform-origin: top right;
          transform-origin: top right;
}

.fa-layers-bottom-right {
  bottom: var(--fa-bottom, 0);
  right: var(--fa-right, 0);
  top: auto;
  -webkit-transform: scale(var(--fa-layers-scale, 0.25));
          transform: scale(var(--fa-layers-scale, 0.25));
  -webkit-transform-origin: bottom right;
          transform-origin: bottom right;
}

.fa-layers-bottom-left {
  bottom: var(--fa-bottom, 0);
  left: var(--fa-left, 0);
  right: auto;
  top: auto;
  -webkit-transform: scale(var(--fa-layers-scale, 0.25));
          transform: scale(var(--fa-layers-scale, 0.25));
  -webkit-transform-origin: bottom left;
          transform-origin: bottom left;
}

.fa-layers-top-right {
  top: var(--fa-top, 0);
  right: var(--fa-right, 0);
  -webkit-transform: scale(var(--fa-layers-scale, 0.25));
          transform: scale(var(--fa-layers-scale, 0.25));
  -webkit-transform-origin: top right;
          transform-origin: top right;
}

.fa-layers-top-left {
  left: var(--fa-left, 0);
  right: auto;
  top: var(--fa-top, 0);
  -webkit-transform: scale(var(--fa-layers-scale, 0.25));
          transform: scale(var(--fa-layers-scale, 0.25));
  -webkit-transform-origin: top left;
          transform-origin: top left;
}

.fa-1x {
  font-size: 1em;
}

.fa-2x {
  font-size: 2em;
}

.fa-3x {
  font-size: 3em;
}

.fa-4x {
  font-size: 4em;
}

.fa-5x {
  font-size: 5em;
}

.fa-6x {
  font-size: 6em;
}

.fa-7x {
  font-size: 7em;
}

.fa-8x {
  font-size: 8em;
}

.fa-9x {
  font-size: 9em;
}

.fa-10x {
  font-size: 10em;
}

.fa-2xs {
  font-size: 0.625em;
  line-height: 0.1em;
  vertical-align: 0.225em;
}

.fa-xs {
  font-size: 0.75em;
  line-height: 0.0833333337em;
  vertical-align: 0.125em;
}

.fa-sm {
  font-size: 0.875em;
  line-height: 0.0714285718em;
  vertical-align: 0.0535714295em;
}

.fa-lg {
  font-size: 1.25em;
  line-height: 0.05em;
  vertical-align: -0.075em;
}

.fa-xl {
  font-size: 1.5em;
  line-height: 0.0416666682em;
  vertical-align: -0.125em;
}

.fa-2xl {
  font-size: 2em;
  line-height: 0.03125em;
  vertical-align: -0.1875em;
}

.fa-fw {
  text-align: center;
  width: 1.25em;
}

.fa-ul {
  list-style-type: none;
  margin-left: var(--fa-li-margin, 2.5em);
  padding-left: 0;
}
.fa-ul > li {
  position: relative;
}

.fa-li {
  left: calc(var(--fa-li-width, 2em) * -1);
  position: absolute;
  text-align: center;
  width: var(--fa-li-width, 2em);
  line-height: inherit;
}

.fa-border {
  border-color: var(--fa-border-color, #eee);
  border-radius: var(--fa-border-radius, 0.1em);
  border-style: var(--fa-border-style, solid);
  border-width: var(--fa-border-width, 0.08em);
  padding: var(--fa-border-padding, 0.2em 0.25em 0.15em);
}

.fa-pull-left {
  float: left;
  margin-right: var(--fa-pull-margin, 0.3em);
}

.fa-pull-right {
  float: right;
  margin-left: var(--fa-pull-margin, 0.3em);
}

.fa-beat {
  -webkit-animation-name: fa-beat;
          animation-name: fa-beat;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, ease-in-out);
          animation-timing-function: var(--fa-animation-timing, ease-in-out);
}

.fa-bounce {
  -webkit-animation-name: fa-bounce;
          animation-name: fa-bounce;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.28, 0.84, 0.42, 1));
          animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.28, 0.84, 0.42, 1));
}

.fa-fade {
  -webkit-animation-name: fa-fade;
          animation-name: fa-fade;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
          animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
}

.fa-beat-fade {
  -webkit-animation-name: fa-beat-fade;
          animation-name: fa-beat-fade;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
          animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
}

.fa-flip {
  -webkit-animation-name: fa-flip;
          animation-name: fa-flip;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, ease-in-out);
          animation-timing-function: var(--fa-animation-timing, ease-in-out);
}

.fa-shake {
  -webkit-animation-name: fa-shake;
          animation-name: fa-shake;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, linear);
          animation-timing-function: var(--fa-animation-timing, linear);
}

.fa-spin {
  -webkit-animation-name: fa-spin;
          animation-name: fa-spin;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 2s);
          animation-duration: var(--fa-animation-duration, 2s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, linear);
          animation-timing-function: var(--fa-animation-timing, linear);
}

.fa-spin-reverse {
  --fa-animation-direction: reverse;
}

.fa-pulse,
.fa-spin-pulse {
  -webkit-animation-name: fa-spin;
          animation-name: fa-spin;
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, steps(8));
          animation-timing-function: var(--fa-animation-timing, steps(8));
}

@media (prefers-reduced-motion: reduce) {
  .fa-beat,
.fa-bounce,
.fa-fade,
.fa-beat-fade,
.fa-flip,
.fa-pulse,
.fa-shake,
.fa-spin,
.fa-spin-pulse {
    -webkit-animation-delay: -1ms;
            animation-delay: -1ms;
    -webkit-animation-duration: 1ms;
            animation-duration: 1ms;
    -webkit-animation-iteration-count: 1;
            animation-iteration-count: 1;
    -webkit-transition-delay: 0s;
            transition-delay: 0s;
    -webkit-transition-duration: 0s;
            transition-duration: 0s;
  }
}
@-webkit-keyframes fa-beat {
  0%, 90% {
    -webkit-transform: scale(1);
            transform: scale(1);
  }
  45% {
    -webkit-transform: scale(var(--fa-beat-scale, 1.25));
            transform: scale(var(--fa-beat-scale, 1.25));
  }
}
@keyframes fa-beat {
  0%, 90% {
    -webkit-transform: scale(1);
            transform: scale(1);
  }
  45% {
    -webkit-transform: scale(var(--fa-beat-scale, 1.25));
            transform: scale(var(--fa-beat-scale, 1.25));
  }
}
@-webkit-keyframes fa-bounce {
  0% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
  10% {
    -webkit-transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
            transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
  }
  30% {
    -webkit-transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
            transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
  }
  50% {
    -webkit-transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
            transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
  }
  57% {
    -webkit-transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
            transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
  }
  64% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
  100% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
}
@keyframes fa-bounce {
  0% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
  10% {
    -webkit-transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
            transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
  }
  30% {
    -webkit-transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
            transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
  }
  50% {
    -webkit-transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
            transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
  }
  57% {
    -webkit-transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
            transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
  }
  64% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
  100% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
}
@-webkit-keyframes fa-fade {
  50% {
    opacity: var(--fa-fade-opacity, 0.4);
  }
}
@keyframes fa-fade {
  50% {
    opacity: var(--fa-fade-opacity, 0.4);
  }
}
@-webkit-keyframes fa-beat-fade {
  0%, 100% {
    opacity: var(--fa-beat-fade-opacity, 0.4);
    -webkit-transform: scale(1);
            transform: scale(1);
  }
  50% {
    opacity: 1;
    -webkit-transform: scale(var(--fa-beat-fade-scale, 1.125));
            transform: scale(var(--fa-beat-fade-scale, 1.125));
  }
}
@keyframes fa-beat-fade {
  0%, 100% {
    opacity: var(--fa-beat-fade-opacity, 0.4);
    -webkit-transform: scale(1);
            transform: scale(1);
  }
  50% {
    opacity: 1;
    -webkit-transform: scale(var(--fa-beat-fade-scale, 1.125));
            transform: scale(var(--fa-beat-fade-scale, 1.125));
  }
}
@-webkit-keyframes fa-flip {
  50% {
    -webkit-transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
            transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
  }
}
@keyframes fa-flip {
  50% {
    -webkit-transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
            transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
  }
}
@-webkit-keyframes fa-shake {
  0% {
    -webkit-transform: rotate(-15deg);
            transform: rotate(-15deg);
  }
  4% {
    -webkit-transform: rotate(15deg);
            transform: rotate(15deg);
  }
  8%, 24% {
    -webkit-transform: rotate(-18deg);
            transform: rotate(-18deg);
  }
  12%, 28% {
    -webkit-transform: rotate(18deg);
            transform: rotate(18deg);
  }
  16% {
    -webkit-transform: rotate(-22deg);
            transform: rotate(-22deg);
  }
  20% {
    -webkit-transform: rotate(22deg);
            transform: rotate(22deg);
  }
  32% {
    -webkit-transform: rotate(-12deg);
            transform: rotate(-12deg);
  }
  36% {
    -webkit-transform: rotate(12deg);
            transform: rotate(12deg);
  }
  40%, 100% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
}
@keyframes fa-shake {
  0% {
    -webkit-transform: rotate(-15deg);
            transform: rotate(-15deg);
  }
  4% {
    -webkit-transform: rotate(15deg);
            transform: rotate(15deg);
  }
  8%, 24% {
    -webkit-transform: rotate(-18deg);
            transform: rotate(-18deg);
  }
  12%, 28% {
    -webkit-transform: rotate(18deg);
            transform: rotate(18deg);
  }
  16% {
    -webkit-transform: rotate(-22deg);
            transform: rotate(-22deg);
  }
  20% {
    -webkit-transform: rotate(22deg);
            transform: rotate(22deg);
  }
  32% {
    -webkit-transform: rotate(-12deg);
            transform: rotate(-12deg);
  }
  36% {
    -webkit-transform: rotate(12deg);
            transform: rotate(12deg);
  }
  40%, 100% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
}
@-webkit-keyframes fa-spin {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}
@keyframes fa-spin {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}
.fa-rotate-90 {
  -webkit-transform: rotate(90deg);
          transform: rotate(90deg);
}

.fa-rotate-180 {
  -webkit-transform: rotate(180deg);
          transform: rotate(180deg);
}

.fa-rotate-270 {
  -webkit-transform: rotate(270deg);
          transform: rotate(270deg);
}

.fa-flip-horizontal {
  -webkit-transform: scale(-1, 1);
          transform: scale(-1, 1);
}

.fa-flip-vertical {
  -webkit-transform: scale(1, -1);
          transform: scale(1, -1);
}

.fa-flip-both,
.fa-flip-horizontal.fa-flip-vertical {
  -webkit-transform: scale(-1, -1);
          transform: scale(-1, -1);
}

.fa-rotate-by {
  -webkit-transform: rotate(var(--fa-rotate-angle, none));
          transform: rotate(var(--fa-rotate-angle, none));
}

.fa-stack {
  display: inline-block;
  vertical-align: middle;
  height: 2em;
  position: relative;
  width: 2.5em;
}

.fa-stack-1x,
.fa-stack-2x {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
  z-index: var(--fa-stack-z-index, auto);
}

.svg-inline--fa.fa-stack-1x {
  height: 1em;
  width: 1.25em;
}
.svg-inline--fa.fa-stack-2x {
  height: 2em;
  width: 2.5em;
}

.fa-inverse {
  color: var(--fa-inverse, #fff);
}

.sr-only,
.fa-sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}

.sr-only-focusable:not(:focus),
.fa-sr-only-focusable:not(:focus) {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}

.svg-inline--fa .fa-primary {
  fill: var(--fa-primary-color, currentColor);
  opacity: var(--fa-primary-opacity, 1);
}

.svg-inline--fa .fa-secondary {
  fill: var(--fa-secondary-color, currentColor);
  opacity: var(--fa-secondary-opacity, 0.4);
}

.svg-inline--fa.fa-swap-opacity .fa-primary {
  opacity: var(--fa-secondary-opacity, 0.4);
}

.svg-inline--fa.fa-swap-opacity .fa-secondary {
  opacity: var(--fa-primary-opacity, 1);
}

.svg-inline--fa mask .fa-primary,
.svg-inline--fa mask .fa-secondary {
  fill: black;
}

.fad.fa-inverse,
.fa-duotone.fa-inverse {
  color: var(--fa-inverse, #fff);
}`;
function Hd() {
  var e = zd, t = Ld, n = K.cssPrefix, r = K.replacementClass, i = lv;
  if (n !== e || r !== t) {
    var o = new RegExp("\\.".concat(e, "\\-"), "g"), a = new RegExp("\\--".concat(e, "\\-"), "g"), s = new RegExp("\\.".concat(t), "g");
    i = i.replace(o, ".".concat(n, "-")).replace(a, "--".concat(n, "-")).replace(s, ".".concat(r));
  }
  return i;
}
var Zl = !1;
function Ko() {
  K.autoAddCss && !Zl && (rv(Hd()), Zl = !0);
}
var cv = {
  mixout: function() {
    return {
      dom: {
        css: Hd,
        insertCss: Ko
      }
    };
  },
  hooks: function() {
    return {
      beforeDOMElementCreation: function() {
        Ko();
      },
      beforeI2svg: function() {
        Ko();
      }
    };
  }
}, jt = on || {};
jt[Vt] || (jt[Vt] = {});
jt[Vt].styles || (jt[Vt].styles = {});
jt[Vt].hooks || (jt[Vt].hooks = {});
jt[Vt].shims || (jt[Vt].shims = []);
var Et = jt[Vt], Bd = [], uv = function e() {
  Ie.removeEventListener("DOMContentLoaded", e), eo = 1, Bd.map(function(t) {
    return t();
  });
}, eo = !1;
Bt && (eo = (Ie.documentElement.doScroll ? /^loaded|^c/ : /^loaded|^i|^c/).test(Ie.readyState), eo || Ie.addEventListener("DOMContentLoaded", uv));
function dv(e) {
  Bt && (eo ? setTimeout(e, 0) : Bd.push(e));
}
function ri(e) {
  var t = e.tag, n = e.attributes, r = n === void 0 ? {} : n, i = e.children, o = i === void 0 ? [] : i;
  return typeof e == "string" ? Ud(e) : "<".concat(t, " ").concat(ov(r), ">").concat(o.map(ri).join(""), "</").concat(t, ">");
}
function ec(e, t, n) {
  if (e && e[t] && e[t][n])
    return {
      prefix: t,
      iconName: n,
      icon: e[t][n]
    };
}
var fv = function(t, n) {
  return function(r, i, o, a) {
    return t.call(n, r, i, o, a);
  };
}, Xo = function(t, n, r, i) {
  var o = Object.keys(t), a = o.length, s = i !== void 0 ? fv(n, i) : n, l, c, u;
  for (r === void 0 ? (l = 1, u = t[o[0]]) : (l = 0, u = r); l < a; l++)
    c = o[l], u = s(u, t[c], c, t);
  return u;
};
function mv(e) {
  for (var t = [], n = 0, r = e.length; n < r; ) {
    var i = e.charCodeAt(n++);
    if (i >= 55296 && i <= 56319 && n < r) {
      var o = e.charCodeAt(n++);
      (o & 64512) == 56320 ? t.push(((i & 1023) << 10) + (o & 1023) + 65536) : (t.push(i), n--);
    } else
      t.push(i);
  }
  return t;
}
function Ca(e) {
  var t = mv(e);
  return t.length === 1 ? t[0].toString(16) : null;
}
function pv(e, t) {
  var n = e.length, r = e.charCodeAt(t), i;
  return r >= 55296 && r <= 56319 && n > t + 1 && (i = e.charCodeAt(t + 1), i >= 56320 && i <= 57343) ? (r - 55296) * 1024 + i - 56320 + 65536 : r;
}
function tc(e) {
  return Object.keys(e).reduce(function(t, n) {
    var r = e[n], i = !!r.icon;
    return i ? t[r.iconName] = r.icon : t[n] = r, t;
  }, {});
}
function Ta(e, t) {
  var n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {}, r = n.skipHooks, i = r === void 0 ? !1 : r, o = tc(t);
  typeof Et.hooks.addPack == "function" && !i ? Et.hooks.addPack(e, tc(t)) : Et.styles[e] = B(B({}, Et.styles[e] || {}), o), e === "fas" && Ta("fa", t);
}
var ki, Si, Oi, Ln = Et.styles, bv = Et.shims, hv = (ki = {}, Be(ki, Ne, Object.values(Gr[Ne])), Be(ki, Re, Object.values(Gr[Re])), ki), Ss = null, Gd = {}, Yd = {}, Wd = {}, qd = {}, Kd = {}, vv = (Si = {}, Be(Si, Ne, Object.keys(Hr[Ne])), Be(Si, Re, Object.keys(Hr[Re])), Si);
function gv(e) {
  return ~Q0.indexOf(e);
}
function yv(e, t) {
  var n = t.split("-"), r = n[0], i = n.slice(1).join("-");
  return r === e && i !== "" && !gv(i) ? i : null;
}
var Xd = function() {
  var t = function(o) {
    return Xo(Ln, function(a, s, l) {
      return a[l] = Xo(s, o, {}), a;
    }, {});
  };
  Gd = t(function(i, o, a) {
    if (o[3] && (i[o[3]] = a), o[2]) {
      var s = o[2].filter(function(l) {
        return typeof l == "number";
      });
      s.forEach(function(l) {
        i[l.toString(16)] = a;
      });
    }
    return i;
  }), Yd = t(function(i, o, a) {
    if (i[a] = a, o[2]) {
      var s = o[2].filter(function(l) {
        return typeof l == "string";
      });
      s.forEach(function(l) {
        i[l] = a;
      });
    }
    return i;
  }), Kd = t(function(i, o, a) {
    var s = o[2];
    return i[a] = a, s.forEach(function(l) {
      i[l] = a;
    }), i;
  });
  var n = "far" in Ln || K.autoFetchSvg, r = Xo(bv, function(i, o) {
    var a = o[0], s = o[1], l = o[2];
    return s === "far" && !n && (s = "fas"), typeof a == "string" && (i.names[a] = {
      prefix: s,
      iconName: l
    }), typeof a == "number" && (i.unicodes[a.toString(16)] = {
      prefix: s,
      iconName: l
    }), i;
  }, {
    names: {},
    unicodes: {}
  });
  Wd = r.names, qd = r.unicodes, Ss = To(K.styleDefault, {
    family: K.familyDefault
  });
};
nv(function(e) {
  Ss = To(e.styleDefault, {
    family: K.familyDefault
  });
});
Xd();
function Os(e, t) {
  return (Gd[e] || {})[t];
}
function _v(e, t) {
  return (Yd[e] || {})[t];
}
function wn(e, t) {
  return (Kd[e] || {})[t];
}
function Jd(e) {
  return Wd[e] || {
    prefix: null,
    iconName: null
  };
}
function wv(e) {
  var t = qd[e], n = Os("fas", e);
  return t || (n ? {
    prefix: "fas",
    iconName: n
  } : null) || {
    prefix: null,
    iconName: null
  };
}
function an() {
  return Ss;
}
var As = function() {
  return {
    prefix: null,
    iconName: null,
    rest: []
  };
};
function To(e) {
  var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, n = t.family, r = n === void 0 ? Ne : n, i = Hr[r][e], o = Br[r][e] || Br[r][i], a = e in Et.styles ? e : null;
  return o || a || null;
}
var nc = (Oi = {}, Be(Oi, Ne, Object.keys(Gr[Ne])), Be(Oi, Re, Object.keys(Gr[Re])), Oi);
function Po(e) {
  var t, n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, r = n.skipLookups, i = r === void 0 ? !1 : r, o = (t = {}, Be(t, Ne, "".concat(K.cssPrefix, "-").concat(Ne)), Be(t, Re, "".concat(K.cssPrefix, "-").concat(Re)), t), a = null, s = Ne;
  (e.includes(o[Ne]) || e.some(function(c) {
    return nc[Ne].includes(c);
  })) && (s = Ne), (e.includes(o[Re]) || e.some(function(c) {
    return nc[Re].includes(c);
  })) && (s = Re);
  var l = e.reduce(function(c, u) {
    var f = yv(K.cssPrefix, u);
    if (Ln[u] ? (u = hv[s].includes(u) ? Y0[s][u] : u, a = u, c.prefix = u) : vv[s].indexOf(u) > -1 ? (a = u, c.prefix = To(u, {
      family: s
    })) : f ? c.iconName = f : u !== K.replacementClass && u !== o[Ne] && u !== o[Re] && c.rest.push(u), !i && c.prefix && c.iconName) {
      var d = a === "fa" ? Jd(c.iconName) : {}, m = wn(c.prefix, c.iconName);
      d.prefix && (a = null), c.iconName = d.iconName || m || c.iconName, c.prefix = d.prefix || c.prefix, c.prefix === "far" && !Ln.far && Ln.fas && !K.autoFetchSvg && (c.prefix = "fas");
    }
    return c;
  }, As());
  return (e.includes("fa-brands") || e.includes("fab")) && (l.prefix = "fab"), (e.includes("fa-duotone") || e.includes("fad")) && (l.prefix = "fad"), !l.prefix && s === Re && (Ln.fass || K.autoFetchSvg) && (l.prefix = "fass", l.iconName = wn(l.prefix, l.iconName) || l.iconName), (l.prefix === "fa" || a === "fa") && (l.prefix = an() || "fas"), l;
}
var xv = /* @__PURE__ */ function() {
  function e() {
    R0(this, e), this.definitions = {};
  }
  return D0(e, [{
    key: "add",
    value: function() {
      for (var n = this, r = arguments.length, i = new Array(r), o = 0; o < r; o++)
        i[o] = arguments[o];
      var a = i.reduce(this._pullDefinitions, {});
      Object.keys(a).forEach(function(s) {
        n.definitions[s] = B(B({}, n.definitions[s] || {}), a[s]), Ta(s, a[s]);
        var l = Gr[Ne][s];
        l && Ta(l, a[s]), Xd();
      });
    }
  }, {
    key: "reset",
    value: function() {
      this.definitions = {};
    }
  }, {
    key: "_pullDefinitions",
    value: function(n, r) {
      var i = r.prefix && r.iconName && r.icon ? {
        0: r
      } : r;
      return Object.keys(i).map(function(o) {
        var a = i[o], s = a.prefix, l = a.iconName, c = a.icon, u = c[2];
        n[s] || (n[s] = {}), u.length > 0 && u.forEach(function(f) {
          typeof f == "string" && (n[s][f] = c);
        }), n[s][l] = c;
      }), n;
    }
  }]), e;
}(), rc = [], $n = {}, Bn = {}, Ev = Object.keys(Bn);
function kv(e, t) {
  var n = t.mixoutsTo;
  return rc = e, $n = {}, Object.keys(Bn).forEach(function(r) {
    Ev.indexOf(r) === -1 && delete Bn[r];
  }), rc.forEach(function(r) {
    var i = r.mixout ? r.mixout() : {};
    if (Object.keys(i).forEach(function(a) {
      typeof i[a] == "function" && (n[a] = i[a]), Zi(i[a]) === "object" && Object.keys(i[a]).forEach(function(s) {
        n[a] || (n[a] = {}), n[a][s] = i[a][s];
      });
    }), r.hooks) {
      var o = r.hooks();
      Object.keys(o).forEach(function(a) {
        $n[a] || ($n[a] = []), $n[a].push(o[a]);
      });
    }
    r.provides && r.provides(Bn);
  }), n;
}
function Pa(e, t) {
  for (var n = arguments.length, r = new Array(n > 2 ? n - 2 : 0), i = 2; i < n; i++)
    r[i - 2] = arguments[i];
  var o = $n[e] || [];
  return o.forEach(function(a) {
    t = a.apply(null, [t].concat(r));
  }), t;
}
function An(e) {
  for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++)
    n[r - 1] = arguments[r];
  var i = $n[e] || [];
  i.forEach(function(o) {
    o.apply(null, n);
  });
}
function Ut() {
  var e = arguments[0], t = Array.prototype.slice.call(arguments, 1);
  return Bn[e] ? Bn[e].apply(null, t) : void 0;
}
function Ma(e) {
  e.prefix === "fa" && (e.prefix = "fas");
  var t = e.iconName, n = e.prefix || an();
  if (t)
    return t = wn(n, t) || t, ec(Qd.definitions, n, t) || ec(Et.styles, n, t);
}
var Qd = new xv(), Sv = function() {
  K.autoReplaceSvg = !1, K.observeMutations = !1, An("noAuto");
}, Ov = {
  i2svg: function() {
    var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    return Bt ? (An("beforeI2svg", t), Ut("pseudoElements2svg", t), Ut("i2svg", t)) : Promise.reject("Operation requires a DOM of some kind.");
  },
  watch: function() {
    var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, n = t.autoReplaceSvgRoot;
    K.autoReplaceSvg === !1 && (K.autoReplaceSvg = !0), K.observeMutations = !0, dv(function() {
      Nv({
        autoReplaceSvgRoot: n
      }), An("watch", t);
    });
  }
}, Av = {
  icon: function(t) {
    if (t === null)
      return null;
    if (Zi(t) === "object" && t.prefix && t.iconName)
      return {
        prefix: t.prefix,
        iconName: wn(t.prefix, t.iconName) || t.iconName
      };
    if (Array.isArray(t) && t.length === 2) {
      var n = t[1].indexOf("fa-") === 0 ? t[1].slice(3) : t[1], r = To(t[0]);
      return {
        prefix: r,
        iconName: wn(r, n) || n
      };
    }
    if (typeof t == "string" && (t.indexOf("".concat(K.cssPrefix, "-")) > -1 || t.match(W0))) {
      var i = Po(t.split(" "), {
        skipLookups: !0
      });
      return {
        prefix: i.prefix || an(),
        iconName: wn(i.prefix, i.iconName) || i.iconName
      };
    }
    if (typeof t == "string") {
      var o = an();
      return {
        prefix: o,
        iconName: wn(o, t) || t
      };
    }
  }
}, dt = {
  noAuto: Sv,
  config: K,
  dom: Ov,
  parse: Av,
  library: Qd,
  findIconDefinition: Ma,
  toHtml: ri
}, Nv = function() {
  var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, n = t.autoReplaceSvgRoot, r = n === void 0 ? Ie : n;
  (Object.keys(Et.styles).length > 0 || K.autoFetchSvg) && Bt && K.autoReplaceSvg && dt.dom.i2svg({
    node: r
  });
};
function Mo(e, t) {
  return Object.defineProperty(e, "abstract", {
    get: t
  }), Object.defineProperty(e, "html", {
    get: function() {
      return e.abstract.map(function(r) {
        return ri(r);
      });
    }
  }), Object.defineProperty(e, "node", {
    get: function() {
      if (Bt) {
        var r = Ie.createElement("div");
        return r.innerHTML = e.html, r.children;
      }
    }
  }), e;
}
function Iv(e) {
  var t = e.children, n = e.main, r = e.mask, i = e.attributes, o = e.styles, a = e.transform;
  if (ks(a) && n.found && !r.found) {
    var s = n.width, l = n.height, c = {
      x: s / l / 2,
      y: 0.5
    };
    i.style = Co(B(B({}, o), {}, {
      "transform-origin": "".concat(c.x + a.x / 16, "em ").concat(c.y + a.y / 16, "em")
    }));
  }
  return [{
    tag: "svg",
    attributes: i,
    children: t
  }];
}
function Cv(e) {
  var t = e.prefix, n = e.iconName, r = e.children, i = e.attributes, o = e.symbol, a = o === !0 ? "".concat(t, "-").concat(K.cssPrefix, "-").concat(n) : o;
  return [{
    tag: "svg",
    attributes: {
      style: "display: none;"
    },
    children: [{
      tag: "symbol",
      attributes: B(B({}, i), {}, {
        id: a
      }),
      children: r
    }]
  }];
}
function Ns(e) {
  var t = e.icons, n = t.main, r = t.mask, i = e.prefix, o = e.iconName, a = e.transform, s = e.symbol, l = e.title, c = e.maskId, u = e.titleId, f = e.extra, d = e.watchable, m = d === void 0 ? !1 : d, p = r.found ? r : n, h = p.width, _ = p.height, y = i === "fak", g = [K.replacementClass, o ? "".concat(K.cssPrefix, "-").concat(o) : ""].filter(function(R) {
    return f.classes.indexOf(R) === -1;
  }).filter(function(R) {
    return R !== "" || !!R;
  }).concat(f.classes).join(" "), w = {
    children: [],
    attributes: B(B({}, f.attributes), {}, {
      "data-prefix": i,
      "data-icon": o,
      class: g,
      role: f.attributes.role || "img",
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 ".concat(h, " ").concat(_)
    })
  }, x = y && !~f.classes.indexOf("fa-fw") ? {
    width: "".concat(h / _ * 16 * 0.0625, "em")
  } : {};
  m && (w.attributes[On] = ""), l && (w.children.push({
    tag: "title",
    attributes: {
      id: w.attributes["aria-labelledby"] || "title-".concat(u || Wr())
    },
    children: [l]
  }), delete w.attributes.title);
  var I = B(B({}, w), {}, {
    prefix: i,
    iconName: o,
    main: n,
    mask: r,
    maskId: c,
    transform: a,
    symbol: s,
    styles: B(B({}, x), f.styles)
  }), U = r.found && n.found ? Ut("generateAbstractMask", I) || {
    children: [],
    attributes: {}
  } : Ut("generateAbstractIcon", I) || {
    children: [],
    attributes: {}
  }, M = U.children, C = U.attributes;
  return I.children = M, I.attributes = C, s ? Cv(I) : Iv(I);
}
function ic(e) {
  var t = e.content, n = e.width, r = e.height, i = e.transform, o = e.title, a = e.extra, s = e.watchable, l = s === void 0 ? !1 : s, c = B(B(B({}, a.attributes), o ? {
    title: o
  } : {}), {}, {
    class: a.classes.join(" ")
  });
  l && (c[On] = "");
  var u = B({}, a.styles);
  ks(i) && (u.transform = sv({
    transform: i,
    startCentered: !0,
    width: n,
    height: r
  }), u["-webkit-transform"] = u.transform);
  var f = Co(u);
  f.length > 0 && (c.style = f);
  var d = [];
  return d.push({
    tag: "span",
    attributes: c,
    children: [t]
  }), o && d.push({
    tag: "span",
    attributes: {
      class: "sr-only"
    },
    children: [o]
  }), d;
}
function Tv(e) {
  var t = e.content, n = e.title, r = e.extra, i = B(B(B({}, r.attributes), n ? {
    title: n
  } : {}), {}, {
    class: r.classes.join(" ")
  }), o = Co(r.styles);
  o.length > 0 && (i.style = o);
  var a = [];
  return a.push({
    tag: "span",
    attributes: i,
    children: [t]
  }), n && a.push({
    tag: "span",
    attributes: {
      class: "sr-only"
    },
    children: [n]
  }), a;
}
var Jo = Et.styles;
function Ra(e) {
  var t = e[0], n = e[1], r = e.slice(4), i = gs(r, 1), o = i[0], a = null;
  return Array.isArray(o) ? a = {
    tag: "g",
    attributes: {
      class: "".concat(K.cssPrefix, "-").concat(_n.GROUP)
    },
    children: [{
      tag: "path",
      attributes: {
        class: "".concat(K.cssPrefix, "-").concat(_n.SECONDARY),
        fill: "currentColor",
        d: o[0]
      }
    }, {
      tag: "path",
      attributes: {
        class: "".concat(K.cssPrefix, "-").concat(_n.PRIMARY),
        fill: "currentColor",
        d: o[1]
      }
    }]
  } : a = {
    tag: "path",
    attributes: {
      fill: "currentColor",
      d: o
    }
  }, {
    found: !0,
    width: t,
    height: n,
    icon: a
  };
}
var Pv = {
  found: !1,
  width: 512,
  height: 512
};
function Mv(e, t) {
  !$d && !K.showMissingIcons && e && console.error('Icon with name "'.concat(e, '" and prefix "').concat(t, '" is missing.'));
}
function Da(e, t) {
  var n = t;
  return t === "fa" && K.styleDefault !== null && (t = an()), new Promise(function(r, i) {
    if (Ut("missingIconAbstract"), n === "fa") {
      var o = Jd(e) || {};
      e = o.iconName || e, t = o.prefix || t;
    }
    if (e && t && Jo[t] && Jo[t][e]) {
      var a = Jo[t][e];
      return r(Ra(a));
    }
    Mv(e, t), r(B(B({}, Pv), {}, {
      icon: K.showMissingIcons && e ? Ut("missingIconAbstract") || {} : {}
    }));
  });
}
var oc = function() {
}, za = K.measurePerformance && gi && gi.mark && gi.measure ? gi : {
  mark: oc,
  measure: oc
}, wr = 'FA "6.4.0"', Rv = function(t) {
  return za.mark("".concat(wr, " ").concat(t, " begins")), function() {
    return Zd(t);
  };
}, Zd = function(t) {
  za.mark("".concat(wr, " ").concat(t, " ends")), za.measure("".concat(wr, " ").concat(t), "".concat(wr, " ").concat(t, " begins"), "".concat(wr, " ").concat(t, " ends"));
}, Is = {
  begin: Rv,
  end: Zd
}, Mi = function() {
};
function ac(e) {
  var t = e.getAttribute ? e.getAttribute(On) : null;
  return typeof t == "string";
}
function Dv(e) {
  var t = e.getAttribute ? e.getAttribute(_s) : null, n = e.getAttribute ? e.getAttribute(ws) : null;
  return t && n;
}
function zv(e) {
  return e && e.classList && e.classList.contains && e.classList.contains(K.replacementClass);
}
function Lv() {
  if (K.autoReplaceSvg === !0)
    return Ri.replace;
  var e = Ri[K.autoReplaceSvg];
  return e || Ri.replace;
}
function $v(e) {
  return Ie.createElementNS("http://www.w3.org/2000/svg", e);
}
function Fv(e) {
  return Ie.createElement(e);
}
function ef(e) {
  var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, n = t.ceFn, r = n === void 0 ? e.tag === "svg" ? $v : Fv : n;
  if (typeof e == "string")
    return Ie.createTextNode(e);
  var i = r(e.tag);
  Object.keys(e.attributes || []).forEach(function(a) {
    i.setAttribute(a, e.attributes[a]);
  });
  var o = e.children || [];
  return o.forEach(function(a) {
    i.appendChild(ef(a, {
      ceFn: r
    }));
  }), i;
}
function Vv(e) {
  var t = " ".concat(e.outerHTML, " ");
  return t = "".concat(t, "Font Awesome fontawesome.com "), t;
}
var Ri = {
  replace: function(t) {
    var n = t[0];
    if (n.parentNode)
      if (t[1].forEach(function(i) {
        n.parentNode.insertBefore(ef(i), n);
      }), n.getAttribute(On) === null && K.keepOriginalSource) {
        var r = Ie.createComment(Vv(n));
        n.parentNode.replaceChild(r, n);
      } else
        n.remove();
  },
  nest: function(t) {
    var n = t[0], r = t[1];
    if (~Es(n).indexOf(K.replacementClass))
      return Ri.replace(t);
    var i = new RegExp("".concat(K.cssPrefix, "-.*"));
    if (delete r[0].attributes.id, r[0].attributes.class) {
      var o = r[0].attributes.class.split(" ").reduce(function(s, l) {
        return l === K.replacementClass || l.match(i) ? s.toSvg.push(l) : s.toNode.push(l), s;
      }, {
        toNode: [],
        toSvg: []
      });
      r[0].attributes.class = o.toSvg.join(" "), o.toNode.length === 0 ? n.removeAttribute("class") : n.setAttribute("class", o.toNode.join(" "));
    }
    var a = r.map(function(s) {
      return ri(s);
    }).join(`
`);
    n.setAttribute(On, ""), n.innerHTML = a;
  }
};
function sc(e) {
  e();
}
function tf(e, t) {
  var n = typeof t == "function" ? t : Mi;
  if (e.length === 0)
    n();
  else {
    var r = sc;
    K.mutateApproach === B0 && (r = on.requestAnimationFrame || sc), r(function() {
      var i = Lv(), o = Is.begin("mutate");
      e.map(i), o(), n();
    });
  }
}
var Cs = !1;
function nf() {
  Cs = !0;
}
function La() {
  Cs = !1;
}
var to = null;
function lc(e) {
  if (Jl && K.observeMutations) {
    var t = e.treeCallback, n = t === void 0 ? Mi : t, r = e.nodeCallback, i = r === void 0 ? Mi : r, o = e.pseudoElementsCallback, a = o === void 0 ? Mi : o, s = e.observeMutationsRoot, l = s === void 0 ? Ie : s;
    to = new Jl(function(c) {
      if (!Cs) {
        var u = an();
        lr(c).forEach(function(f) {
          if (f.type === "childList" && f.addedNodes.length > 0 && !ac(f.addedNodes[0]) && (K.searchPseudoElements && a(f.target), n(f.target)), f.type === "attributes" && f.target.parentNode && K.searchPseudoElements && a(f.target.parentNode), f.type === "attributes" && ac(f.target) && ~J0.indexOf(f.attributeName))
            if (f.attributeName === "class" && Dv(f.target)) {
              var d = Po(Es(f.target)), m = d.prefix, p = d.iconName;
              f.target.setAttribute(_s, m || u), p && f.target.setAttribute(ws, p);
            } else
              zv(f.target) && i(f.target);
        });
      }
    }), Bt && to.observe(l, {
      childList: !0,
      attributes: !0,
      characterData: !0,
      subtree: !0
    });
  }
}
function jv() {
  to && to.disconnect();
}
function Uv(e) {
  var t = e.getAttribute("style"), n = [];
  return t && (n = t.split(";").reduce(function(r, i) {
    var o = i.split(":"), a = o[0], s = o.slice(1);
    return a && s.length > 0 && (r[a] = s.join(":").trim()), r;
  }, {})), n;
}
function Hv(e) {
  var t = e.getAttribute("data-prefix"), n = e.getAttribute("data-icon"), r = e.innerText !== void 0 ? e.innerText.trim() : "", i = Po(Es(e));
  return i.prefix || (i.prefix = an()), t && n && (i.prefix = t, i.iconName = n), i.iconName && i.prefix || (i.prefix && r.length > 0 && (i.iconName = _v(i.prefix, e.innerText) || Os(i.prefix, Ca(e.innerText))), !i.iconName && K.autoFetchSvg && e.firstChild && e.firstChild.nodeType === Node.TEXT_NODE && (i.iconName = e.firstChild.data)), i;
}
function Bv(e) {
  var t = lr(e.attributes).reduce(function(i, o) {
    return i.name !== "class" && i.name !== "style" && (i[o.name] = o.value), i;
  }, {}), n = e.getAttribute("title"), r = e.getAttribute("data-fa-title-id");
  return K.autoA11y && (n ? t["aria-labelledby"] = "".concat(K.replacementClass, "-title-").concat(r || Wr()) : (t["aria-hidden"] = "true", t.focusable = "false")), t;
}
function Gv() {
  return {
    iconName: null,
    title: null,
    titleId: null,
    prefix: null,
    transform: Tt,
    symbol: !1,
    mask: {
      iconName: null,
      prefix: null,
      rest: []
    },
    maskId: null,
    extra: {
      classes: [],
      styles: {},
      attributes: {}
    }
  };
}
function cc(e) {
  var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {
    styleParser: !0
  }, n = Hv(e), r = n.iconName, i = n.prefix, o = n.rest, a = Bv(e), s = Pa("parseNodeAttributes", {}, e), l = t.styleParser ? Uv(e) : [];
  return B({
    iconName: r,
    title: e.getAttribute("title"),
    titleId: e.getAttribute("data-fa-title-id"),
    prefix: i,
    transform: Tt,
    mask: {
      iconName: null,
      prefix: null,
      rest: []
    },
    maskId: null,
    symbol: !1,
    extra: {
      classes: o,
      styles: l,
      attributes: a
    }
  }, s);
}
var Yv = Et.styles;
function rf(e) {
  var t = K.autoReplaceSvg === "nest" ? cc(e, {
    styleParser: !1
  }) : cc(e);
  return ~t.extra.classes.indexOf(Fd) ? Ut("generateLayersText", e, t) : Ut("generateSvgReplacementMutation", e, t);
}
var sn = /* @__PURE__ */ new Set();
xs.map(function(e) {
  sn.add("fa-".concat(e));
});
Object.keys(Hr[Ne]).map(sn.add.bind(sn));
Object.keys(Hr[Re]).map(sn.add.bind(sn));
sn = ti(sn);
function uc(e) {
  var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
  if (!Bt)
    return Promise.resolve();
  var n = Ie.documentElement.classList, r = function(f) {
    return n.add("".concat(Ql, "-").concat(f));
  }, i = function(f) {
    return n.remove("".concat(Ql, "-").concat(f));
  }, o = K.autoFetchSvg ? sn : xs.map(function(u) {
    return "fa-".concat(u);
  }).concat(Object.keys(Yv));
  o.includes("fa") || o.push("fa");
  var a = [".".concat(Fd, ":not([").concat(On, "])")].concat(o.map(function(u) {
    return ".".concat(u, ":not([").concat(On, "])");
  })).join(", ");
  if (a.length === 0)
    return Promise.resolve();
  var s = [];
  try {
    s = lr(e.querySelectorAll(a));
  } catch {
  }
  if (s.length > 0)
    r("pending"), i("complete");
  else
    return Promise.resolve();
  var l = Is.begin("onTree"), c = s.reduce(function(u, f) {
    try {
      var d = rf(f);
      d && u.push(d);
    } catch (m) {
      $d || m.name === "MissingIcon" && console.error(m);
    }
    return u;
  }, []);
  return new Promise(function(u, f) {
    Promise.all(c).then(function(d) {
      tf(d, function() {
        r("active"), r("complete"), i("pending"), typeof t == "function" && t(), l(), u();
      });
    }).catch(function(d) {
      l(), f(d);
    });
  });
}
function Wv(e) {
  var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
  rf(e).then(function(n) {
    n && tf([n], t);
  });
}
function qv(e) {
  return function(t) {
    var n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, r = (t || {}).icon ? t : Ma(t || {}), i = n.mask;
    return i && (i = (i || {}).icon ? i : Ma(i || {})), e(r, B(B({}, n), {}, {
      mask: i
    }));
  };
}
var Kv = function(t) {
  var n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, r = n.transform, i = r === void 0 ? Tt : r, o = n.symbol, a = o === void 0 ? !1 : o, s = n.mask, l = s === void 0 ? null : s, c = n.maskId, u = c === void 0 ? null : c, f = n.title, d = f === void 0 ? null : f, m = n.titleId, p = m === void 0 ? null : m, h = n.classes, _ = h === void 0 ? [] : h, y = n.attributes, g = y === void 0 ? {} : y, w = n.styles, x = w === void 0 ? {} : w;
  if (t) {
    var I = t.prefix, U = t.iconName, M = t.icon;
    return Mo(B({
      type: "icon"
    }, t), function() {
      return An("beforeDOMElementCreation", {
        iconDefinition: t,
        params: n
      }), K.autoA11y && (d ? g["aria-labelledby"] = "".concat(K.replacementClass, "-title-").concat(p || Wr()) : (g["aria-hidden"] = "true", g.focusable = "false")), Ns({
        icons: {
          main: Ra(M),
          mask: l ? Ra(l.icon) : {
            found: !1,
            width: null,
            height: null,
            icon: {}
          }
        },
        prefix: I,
        iconName: U,
        transform: B(B({}, Tt), i),
        symbol: a,
        title: d,
        maskId: u,
        titleId: p,
        extra: {
          attributes: g,
          styles: x,
          classes: _
        }
      });
    });
  }
}, Xv = {
  mixout: function() {
    return {
      icon: qv(Kv)
    };
  },
  hooks: function() {
    return {
      mutationObserverCallbacks: function(n) {
        return n.treeCallback = uc, n.nodeCallback = Wv, n;
      }
    };
  },
  provides: function(t) {
    t.i2svg = function(n) {
      var r = n.node, i = r === void 0 ? Ie : r, o = n.callback, a = o === void 0 ? function() {
      } : o;
      return uc(i, a);
    }, t.generateSvgReplacementMutation = function(n, r) {
      var i = r.iconName, o = r.title, a = r.titleId, s = r.prefix, l = r.transform, c = r.symbol, u = r.mask, f = r.maskId, d = r.extra;
      return new Promise(function(m, p) {
        Promise.all([Da(i, s), u.iconName ? Da(u.iconName, u.prefix) : Promise.resolve({
          found: !1,
          width: 512,
          height: 512,
          icon: {}
        })]).then(function(h) {
          var _ = gs(h, 2), y = _[0], g = _[1];
          m([n, Ns({
            icons: {
              main: y,
              mask: g
            },
            prefix: s,
            iconName: i,
            transform: l,
            symbol: c,
            maskId: f,
            title: o,
            titleId: a,
            extra: d,
            watchable: !0
          })]);
        }).catch(p);
      });
    }, t.generateAbstractIcon = function(n) {
      var r = n.children, i = n.attributes, o = n.main, a = n.transform, s = n.styles, l = Co(s);
      l.length > 0 && (i.style = l);
      var c;
      return ks(a) && (c = Ut("generateAbstractTransformGrouping", {
        main: o,
        transform: a,
        containerWidth: o.width,
        iconWidth: o.width
      })), r.push(c || o.icon), {
        children: r,
        attributes: i
      };
    };
  }
}, Jv = {
  mixout: function() {
    return {
      layer: function(n) {
        var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, i = r.classes, o = i === void 0 ? [] : i;
        return Mo({
          type: "layer"
        }, function() {
          An("beforeDOMElementCreation", {
            assembler: n,
            params: r
          });
          var a = [];
          return n(function(s) {
            Array.isArray(s) ? s.map(function(l) {
              a = a.concat(l.abstract);
            }) : a = a.concat(s.abstract);
          }), [{
            tag: "span",
            attributes: {
              class: ["".concat(K.cssPrefix, "-layers")].concat(ti(o)).join(" ")
            },
            children: a
          }];
        });
      }
    };
  }
}, Qv = {
  mixout: function() {
    return {
      counter: function(n) {
        var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, i = r.title, o = i === void 0 ? null : i, a = r.classes, s = a === void 0 ? [] : a, l = r.attributes, c = l === void 0 ? {} : l, u = r.styles, f = u === void 0 ? {} : u;
        return Mo({
          type: "counter",
          content: n
        }, function() {
          return An("beforeDOMElementCreation", {
            content: n,
            params: r
          }), Tv({
            content: n.toString(),
            title: o,
            extra: {
              attributes: c,
              styles: f,
              classes: ["".concat(K.cssPrefix, "-layers-counter")].concat(ti(s))
            }
          });
        });
      }
    };
  }
}, Zv = {
  mixout: function() {
    return {
      text: function(n) {
        var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, i = r.transform, o = i === void 0 ? Tt : i, a = r.title, s = a === void 0 ? null : a, l = r.classes, c = l === void 0 ? [] : l, u = r.attributes, f = u === void 0 ? {} : u, d = r.styles, m = d === void 0 ? {} : d;
        return Mo({
          type: "text",
          content: n
        }, function() {
          return An("beforeDOMElementCreation", {
            content: n,
            params: r
          }), ic({
            content: n,
            transform: B(B({}, Tt), o),
            title: s,
            extra: {
              attributes: f,
              styles: m,
              classes: ["".concat(K.cssPrefix, "-layers-text")].concat(ti(c))
            }
          });
        });
      }
    };
  },
  provides: function(t) {
    t.generateLayersText = function(n, r) {
      var i = r.title, o = r.transform, a = r.extra, s = null, l = null;
      if (Dd) {
        var c = parseInt(getComputedStyle(n).fontSize, 10), u = n.getBoundingClientRect();
        s = u.width / c, l = u.height / c;
      }
      return K.autoA11y && !i && (a.attributes["aria-hidden"] = "true"), Promise.resolve([n, ic({
        content: n.innerHTML,
        width: s,
        height: l,
        transform: o,
        title: i,
        extra: a,
        watchable: !0
      })]);
    };
  }
}, e2 = new RegExp('"', "ug"), dc = [1105920, 1112319];
function t2(e) {
  var t = e.replace(e2, ""), n = pv(t, 0), r = n >= dc[0] && n <= dc[1], i = t.length === 2 ? t[0] === t[1] : !1;
  return {
    value: Ca(i ? t[0] : t),
    isSecondary: r || i
  };
}
function fc(e, t) {
  var n = "".concat(H0).concat(t.replace(":", "-"));
  return new Promise(function(r, i) {
    if (e.getAttribute(n) !== null)
      return r();
    var o = lr(e.children), a = o.filter(function(M) {
      return M.getAttribute(Ia) === t;
    })[0], s = on.getComputedStyle(e, t), l = s.getPropertyValue("font-family").match(q0), c = s.getPropertyValue("font-weight"), u = s.getPropertyValue("content");
    if (a && !l)
      return e.removeChild(a), r();
    if (l && u !== "none" && u !== "") {
      var f = s.getPropertyValue("content"), d = ~["Sharp"].indexOf(l[2]) ? Re : Ne, m = ~["Solid", "Regular", "Light", "Thin", "Duotone", "Brands", "Kit"].indexOf(l[2]) ? Br[d][l[2].toLowerCase()] : K0[d][c], p = t2(f), h = p.value, _ = p.isSecondary, y = l[0].startsWith("FontAwesome"), g = Os(m, h), w = g;
      if (y) {
        var x = wv(h);
        x.iconName && x.prefix && (g = x.iconName, m = x.prefix);
      }
      if (g && !_ && (!a || a.getAttribute(_s) !== m || a.getAttribute(ws) !== w)) {
        e.setAttribute(n, w), a && e.removeChild(a);
        var I = Gv(), U = I.extra;
        U.attributes[Ia] = t, Da(g, m).then(function(M) {
          var C = Ns(B(B({}, I), {}, {
            icons: {
              main: M,
              mask: As()
            },
            prefix: m,
            iconName: w,
            extra: U,
            watchable: !0
          })), R = Ie.createElement("svg");
          t === "::before" ? e.insertBefore(R, e.firstChild) : e.appendChild(R), R.outerHTML = C.map(function(W) {
            return ri(W);
          }).join(`
`), e.removeAttribute(n), r();
        }).catch(i);
      } else
        r();
    } else
      r();
  });
}
function n2(e) {
  return Promise.all([fc(e, "::before"), fc(e, "::after")]);
}
function r2(e) {
  return e.parentNode !== document.head && !~G0.indexOf(e.tagName.toUpperCase()) && !e.getAttribute(Ia) && (!e.parentNode || e.parentNode.tagName !== "svg");
}
function mc(e) {
  if (Bt)
    return new Promise(function(t, n) {
      var r = lr(e.querySelectorAll("*")).filter(r2).map(n2), i = Is.begin("searchPseudoElements");
      nf(), Promise.all(r).then(function() {
        i(), La(), t();
      }).catch(function() {
        i(), La(), n();
      });
    });
}
var i2 = {
  hooks: function() {
    return {
      mutationObserverCallbacks: function(n) {
        return n.pseudoElementsCallback = mc, n;
      }
    };
  },
  provides: function(t) {
    t.pseudoElements2svg = function(n) {
      var r = n.node, i = r === void 0 ? Ie : r;
      K.searchPseudoElements && mc(i);
    };
  }
}, pc = !1, o2 = {
  mixout: function() {
    return {
      dom: {
        unwatch: function() {
          nf(), pc = !0;
        }
      }
    };
  },
  hooks: function() {
    return {
      bootstrap: function() {
        lc(Pa("mutationObserverCallbacks", {}));
      },
      noAuto: function() {
        jv();
      },
      watch: function(n) {
        var r = n.observeMutationsRoot;
        pc ? La() : lc(Pa("mutationObserverCallbacks", {
          observeMutationsRoot: r
        }));
      }
    };
  }
}, bc = function(t) {
  var n = {
    size: 16,
    x: 0,
    y: 0,
    flipX: !1,
    flipY: !1,
    rotate: 0
  };
  return t.toLowerCase().split(" ").reduce(function(r, i) {
    var o = i.toLowerCase().split("-"), a = o[0], s = o.slice(1).join("-");
    if (a && s === "h")
      return r.flipX = !0, r;
    if (a && s === "v")
      return r.flipY = !0, r;
    if (s = parseFloat(s), isNaN(s))
      return r;
    switch (a) {
      case "grow":
        r.size = r.size + s;
        break;
      case "shrink":
        r.size = r.size - s;
        break;
      case "left":
        r.x = r.x - s;
        break;
      case "right":
        r.x = r.x + s;
        break;
      case "up":
        r.y = r.y - s;
        break;
      case "down":
        r.y = r.y + s;
        break;
      case "rotate":
        r.rotate = r.rotate + s;
        break;
    }
    return r;
  }, n);
}, a2 = {
  mixout: function() {
    return {
      parse: {
        transform: function(n) {
          return bc(n);
        }
      }
    };
  },
  hooks: function() {
    return {
      parseNodeAttributes: function(n, r) {
        var i = r.getAttribute("data-fa-transform");
        return i && (n.transform = bc(i)), n;
      }
    };
  },
  provides: function(t) {
    t.generateAbstractTransformGrouping = function(n) {
      var r = n.main, i = n.transform, o = n.containerWidth, a = n.iconWidth, s = {
        transform: "translate(".concat(o / 2, " 256)")
      }, l = "translate(".concat(i.x * 32, ", ").concat(i.y * 32, ") "), c = "scale(".concat(i.size / 16 * (i.flipX ? -1 : 1), ", ").concat(i.size / 16 * (i.flipY ? -1 : 1), ") "), u = "rotate(".concat(i.rotate, " 0 0)"), f = {
        transform: "".concat(l, " ").concat(c, " ").concat(u)
      }, d = {
        transform: "translate(".concat(a / 2 * -1, " -256)")
      }, m = {
        outer: s,
        inner: f,
        path: d
      };
      return {
        tag: "g",
        attributes: B({}, m.outer),
        children: [{
          tag: "g",
          attributes: B({}, m.inner),
          children: [{
            tag: r.icon.tag,
            children: r.icon.children,
            attributes: B(B({}, r.icon.attributes), m.path)
          }]
        }]
      };
    };
  }
}, Qo = {
  x: 0,
  y: 0,
  width: "100%",
  height: "100%"
};
function hc(e) {
  var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
  return e.attributes && (e.attributes.fill || t) && (e.attributes.fill = "black"), e;
}
function s2(e) {
  return e.tag === "g" ? e.children : [e];
}
var l2 = {
  hooks: function() {
    return {
      parseNodeAttributes: function(n, r) {
        var i = r.getAttribute("data-fa-mask"), o = i ? Po(i.split(" ").map(function(a) {
          return a.trim();
        })) : As();
        return o.prefix || (o.prefix = an()), n.mask = o, n.maskId = r.getAttribute("data-fa-mask-id"), n;
      }
    };
  },
  provides: function(t) {
    t.generateAbstractMask = function(n) {
      var r = n.children, i = n.attributes, o = n.main, a = n.mask, s = n.maskId, l = n.transform, c = o.width, u = o.icon, f = a.width, d = a.icon, m = av({
        transform: l,
        containerWidth: f,
        iconWidth: c
      }), p = {
        tag: "rect",
        attributes: B(B({}, Qo), {}, {
          fill: "white"
        })
      }, h = u.children ? {
        children: u.children.map(hc)
      } : {}, _ = {
        tag: "g",
        attributes: B({}, m.inner),
        children: [hc(B({
          tag: u.tag,
          attributes: B(B({}, u.attributes), m.path)
        }, h))]
      }, y = {
        tag: "g",
        attributes: B({}, m.outer),
        children: [_]
      }, g = "mask-".concat(s || Wr()), w = "clip-".concat(s || Wr()), x = {
        tag: "mask",
        attributes: B(B({}, Qo), {}, {
          id: g,
          maskUnits: "userSpaceOnUse",
          maskContentUnits: "userSpaceOnUse"
        }),
        children: [p, y]
      }, I = {
        tag: "defs",
        children: [{
          tag: "clipPath",
          attributes: {
            id: w
          },
          children: s2(d)
        }, x]
      };
      return r.push(I, {
        tag: "rect",
        attributes: B({
          fill: "currentColor",
          "clip-path": "url(#".concat(w, ")"),
          mask: "url(#".concat(g, ")")
        }, Qo)
      }), {
        children: r,
        attributes: i
      };
    };
  }
}, c2 = {
  provides: function(t) {
    var n = !1;
    on.matchMedia && (n = on.matchMedia("(prefers-reduced-motion: reduce)").matches), t.missingIconAbstract = function() {
      var r = [], i = {
        fill: "currentColor"
      }, o = {
        attributeType: "XML",
        repeatCount: "indefinite",
        dur: "2s"
      };
      r.push({
        tag: "path",
        attributes: B(B({}, i), {}, {
          d: "M156.5,447.7l-12.6,29.5c-18.7-9.5-35.9-21.2-51.5-34.9l22.7-22.7C127.6,430.5,141.5,440,156.5,447.7z M40.6,272H8.5 c1.4,21.2,5.4,41.7,11.7,61.1L50,321.2C45.1,305.5,41.8,289,40.6,272z M40.6,240c1.4-18.8,5.2-37,11.1-54.1l-29.5-12.6 C14.7,194.3,10,216.7,8.5,240H40.6z M64.3,156.5c7.8-14.9,17.2-28.8,28.1-41.5L69.7,92.3c-13.7,15.6-25.5,32.8-34.9,51.5 L64.3,156.5z M397,419.6c-13.9,12-29.4,22.3-46.1,30.4l11.9,29.8c20.7-9.9,39.8-22.6,56.9-37.6L397,419.6z M115,92.4 c13.9-12,29.4-22.3,46.1-30.4l-11.9-29.8c-20.7,9.9-39.8,22.6-56.8,37.6L115,92.4z M447.7,355.5c-7.8,14.9-17.2,28.8-28.1,41.5 l22.7,22.7c13.7-15.6,25.5-32.9,34.9-51.5L447.7,355.5z M471.4,272c-1.4,18.8-5.2,37-11.1,54.1l29.5,12.6 c7.5-21.1,12.2-43.5,13.6-66.8H471.4z M321.2,462c-15.7,5-32.2,8.2-49.2,9.4v32.1c21.2-1.4,41.7-5.4,61.1-11.7L321.2,462z M240,471.4c-18.8-1.4-37-5.2-54.1-11.1l-12.6,29.5c21.1,7.5,43.5,12.2,66.8,13.6V471.4z M462,190.8c5,15.7,8.2,32.2,9.4,49.2h32.1 c-1.4-21.2-5.4-41.7-11.7-61.1L462,190.8z M92.4,397c-12-13.9-22.3-29.4-30.4-46.1l-29.8,11.9c9.9,20.7,22.6,39.8,37.6,56.9 L92.4,397z M272,40.6c18.8,1.4,36.9,5.2,54.1,11.1l12.6-29.5C317.7,14.7,295.3,10,272,8.5V40.6z M190.8,50 c15.7-5,32.2-8.2,49.2-9.4V8.5c-21.2,1.4-41.7,5.4-61.1,11.7L190.8,50z M442.3,92.3L419.6,115c12,13.9,22.3,29.4,30.5,46.1 l29.8-11.9C470,128.5,457.3,109.4,442.3,92.3z M397,92.4l22.7-22.7c-15.6-13.7-32.8-25.5-51.5-34.9l-12.6,29.5 C370.4,72.1,384.4,81.5,397,92.4z"
        })
      });
      var a = B(B({}, o), {}, {
        attributeName: "opacity"
      }), s = {
        tag: "circle",
        attributes: B(B({}, i), {}, {
          cx: "256",
          cy: "364",
          r: "28"
        }),
        children: []
      };
      return n || s.children.push({
        tag: "animate",
        attributes: B(B({}, o), {}, {
          attributeName: "r",
          values: "28;14;28;28;14;28;"
        })
      }, {
        tag: "animate",
        attributes: B(B({}, a), {}, {
          values: "1;0;1;1;0;1;"
        })
      }), r.push(s), r.push({
        tag: "path",
        attributes: B(B({}, i), {}, {
          opacity: "1",
          d: "M263.7,312h-16c-6.6,0-12-5.4-12-12c0-71,77.4-63.9,77.4-107.8c0-20-17.8-40.2-57.4-40.2c-29.1,0-44.3,9.6-59.2,28.7 c-3.9,5-11.1,6-16.2,2.4l-13.1-9.2c-5.6-3.9-6.9-11.8-2.6-17.2c21.2-27.2,46.4-44.7,91.2-44.7c52.3,0,97.4,29.8,97.4,80.2 c0,67.6-77.4,63.5-77.4,107.8C275.7,306.6,270.3,312,263.7,312z"
        }),
        children: n ? [] : [{
          tag: "animate",
          attributes: B(B({}, a), {}, {
            values: "1;0;0;0;0;1;"
          })
        }]
      }), n || r.push({
        tag: "path",
        attributes: B(B({}, i), {}, {
          opacity: "0",
          d: "M232.5,134.5l7,168c0.3,6.4,5.6,11.5,12,11.5h9c6.4,0,11.7-5.1,12-11.5l7-168c0.3-6.8-5.2-12.5-12-12.5h-23 C237.7,122,232.2,127.7,232.5,134.5z"
        }),
        children: [{
          tag: "animate",
          attributes: B(B({}, a), {}, {
            values: "0;0;1;1;0;0;"
          })
        }]
      }), {
        tag: "g",
        attributes: {
          class: "missing"
        },
        children: r
      };
    };
  }
}, u2 = {
  hooks: function() {
    return {
      parseNodeAttributes: function(n, r) {
        var i = r.getAttribute("data-fa-symbol"), o = i === null ? !1 : i === "" ? !0 : i;
        return n.symbol = o, n;
      }
    };
  }
}, d2 = [cv, Xv, Jv, Qv, Zv, i2, o2, a2, l2, c2, u2];
kv(d2, {
  mixoutsTo: dt
});
dt.noAuto;
dt.config;
var f2 = dt.library;
dt.dom;
var $a = dt.parse;
dt.findIconDefinition;
dt.toHtml;
var m2 = dt.icon;
dt.layer;
dt.text;
dt.counter;
function vc(e, t) {
  var n = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var r = Object.getOwnPropertySymbols(e);
    t && (r = r.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), n.push.apply(n, r);
  }
  return n;
}
function Lt(e) {
  for (var t = 1; t < arguments.length; t++) {
    var n = arguments[t] != null ? arguments[t] : {};
    t % 2 ? vc(Object(n), !0).forEach(function(r) {
      it(e, r, n[r]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : vc(Object(n)).forEach(function(r) {
      Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(n, r));
    });
  }
  return e;
}
function no(e) {
  "@babel/helpers - typeof";
  return no = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, no(e);
}
function it(e, t, n) {
  return t in e ? Object.defineProperty(e, t, {
    value: n,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : e[t] = n, e;
}
function p2(e, t) {
  if (e == null)
    return {};
  var n = {}, r = Object.keys(e), i, o;
  for (o = 0; o < r.length; o++)
    i = r[o], !(t.indexOf(i) >= 0) && (n[i] = e[i]);
  return n;
}
function b2(e, t) {
  if (e == null)
    return {};
  var n = p2(e, t), r, i;
  if (Object.getOwnPropertySymbols) {
    var o = Object.getOwnPropertySymbols(e);
    for (i = 0; i < o.length; i++)
      r = o[i], !(t.indexOf(r) >= 0) && Object.prototype.propertyIsEnumerable.call(e, r) && (n[r] = e[r]);
  }
  return n;
}
var h2 = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, of = { exports: {} };
(function(e) {
  (function(t) {
    var n = function(y, g, w) {
      if (!c(g) || f(g) || d(g) || m(g) || l(g))
        return g;
      var x, I = 0, U = 0;
      if (u(g))
        for (x = [], U = g.length; I < U; I++)
          x.push(n(y, g[I], w));
      else {
        x = {};
        for (var M in g)
          Object.prototype.hasOwnProperty.call(g, M) && (x[y(M, w)] = n(y, g[M], w));
      }
      return x;
    }, r = function(y, g) {
      g = g || {};
      var w = g.separator || "_", x = g.split || /(?=[A-Z])/;
      return y.split(x).join(w);
    }, i = function(y) {
      return p(y) ? y : (y = y.replace(/[\-_\s]+(.)?/g, function(g, w) {
        return w ? w.toUpperCase() : "";
      }), y.substr(0, 1).toLowerCase() + y.substr(1));
    }, o = function(y) {
      var g = i(y);
      return g.substr(0, 1).toUpperCase() + g.substr(1);
    }, a = function(y, g) {
      return r(y, g).toLowerCase();
    }, s = Object.prototype.toString, l = function(y) {
      return typeof y == "function";
    }, c = function(y) {
      return y === Object(y);
    }, u = function(y) {
      return s.call(y) == "[object Array]";
    }, f = function(y) {
      return s.call(y) == "[object Date]";
    }, d = function(y) {
      return s.call(y) == "[object RegExp]";
    }, m = function(y) {
      return s.call(y) == "[object Boolean]";
    }, p = function(y) {
      return y = y - 0, y === y;
    }, h = function(y, g) {
      var w = g && "process" in g ? g.process : g;
      return typeof w != "function" ? y : function(x, I) {
        return w(x, y, I);
      };
    }, _ = {
      camelize: i,
      decamelize: a,
      pascalize: o,
      depascalize: a,
      camelizeKeys: function(y, g) {
        return n(h(i, g), y);
      },
      decamelizeKeys: function(y, g) {
        return n(h(a, g), y, g);
      },
      pascalizeKeys: function(y, g) {
        return n(h(o, g), y);
      },
      depascalizeKeys: function() {
        return this.decamelizeKeys.apply(this, arguments);
      }
    };
    e.exports ? e.exports = _ : t.humps = _;
  })(h2);
})(of);
var v2 = of.exports, g2 = ["class", "style"];
function y2(e) {
  return e.split(";").map(function(t) {
    return t.trim();
  }).filter(function(t) {
    return t;
  }).reduce(function(t, n) {
    var r = n.indexOf(":"), i = v2.camelize(n.slice(0, r)), o = n.slice(r + 1).trim();
    return t[i] = o, t;
  }, {});
}
function _2(e) {
  return e.split(/\s+/).reduce(function(t, n) {
    return t[n] = !0, t;
  }, {});
}
function af(e) {
  var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
  if (typeof e == "string")
    return e;
  var r = (e.children || []).map(function(l) {
    return af(l);
  }), i = Object.keys(e.attributes || {}).reduce(function(l, c) {
    var u = e.attributes[c];
    switch (c) {
      case "class":
        l.class = _2(u);
        break;
      case "style":
        l.style = y2(u);
        break;
      default:
        l.attrs[c] = u;
    }
    return l;
  }, {
    attrs: {},
    class: {},
    style: {}
  });
  n.class;
  var o = n.style, a = o === void 0 ? {} : o, s = b2(n, g2);
  return He(e.tag, Lt(Lt(Lt({}, t), {}, {
    class: i.class,
    style: Lt(Lt({}, i.style), a)
  }, i.attrs), s), r);
}
var sf = !1;
try {
  sf = !0;
} catch {
}
function w2() {
  if (!sf && console && typeof console.error == "function") {
    var e;
    (e = console).error.apply(e, arguments);
  }
}
function Zo(e, t) {
  return Array.isArray(t) && t.length > 0 || !Array.isArray(t) && t ? it({}, e, t) : {};
}
function x2(e) {
  var t, n = (t = {
    "fa-spin": e.spin,
    "fa-pulse": e.pulse,
    "fa-fw": e.fixedWidth,
    "fa-border": e.border,
    "fa-li": e.listItem,
    "fa-inverse": e.inverse,
    "fa-flip": e.flip === !0,
    "fa-flip-horizontal": e.flip === "horizontal" || e.flip === "both",
    "fa-flip-vertical": e.flip === "vertical" || e.flip === "both"
  }, it(t, "fa-".concat(e.size), e.size !== null), it(t, "fa-rotate-".concat(e.rotation), e.rotation !== null), it(t, "fa-pull-".concat(e.pull), e.pull !== null), it(t, "fa-swap-opacity", e.swapOpacity), it(t, "fa-bounce", e.bounce), it(t, "fa-shake", e.shake), it(t, "fa-beat", e.beat), it(t, "fa-fade", e.fade), it(t, "fa-beat-fade", e.beatFade), it(t, "fa-flash", e.flash), it(t, "fa-spin-pulse", e.spinPulse), it(t, "fa-spin-reverse", e.spinReverse), t);
  return Object.keys(n).map(function(r) {
    return n[r] ? r : null;
  }).filter(function(r) {
    return r;
  });
}
function gc(e) {
  if (e && no(e) === "object" && e.prefix && e.iconName && e.icon)
    return e;
  if ($a.icon)
    return $a.icon(e);
  if (e === null)
    return null;
  if (no(e) === "object" && e.prefix && e.iconName)
    return e;
  if (Array.isArray(e) && e.length === 2)
    return {
      prefix: e[0],
      iconName: e[1]
    };
  if (typeof e == "string")
    return {
      prefix: "fas",
      iconName: e
    };
}
var E2 = de({
  name: "FontAwesomeIcon",
  props: {
    border: {
      type: Boolean,
      default: !1
    },
    fixedWidth: {
      type: Boolean,
      default: !1
    },
    flip: {
      type: [Boolean, String],
      default: !1,
      validator: function(t) {
        return [!0, !1, "horizontal", "vertical", "both"].indexOf(t) > -1;
      }
    },
    icon: {
      type: [Object, Array, String],
      required: !0
    },
    mask: {
      type: [Object, Array, String],
      default: null
    },
    listItem: {
      type: Boolean,
      default: !1
    },
    pull: {
      type: String,
      default: null,
      validator: function(t) {
        return ["right", "left"].indexOf(t) > -1;
      }
    },
    pulse: {
      type: Boolean,
      default: !1
    },
    rotation: {
      type: [String, Number],
      default: null,
      validator: function(t) {
        return [90, 180, 270].indexOf(Number.parseInt(t, 10)) > -1;
      }
    },
    swapOpacity: {
      type: Boolean,
      default: !1
    },
    size: {
      type: String,
      default: null,
      validator: function(t) {
        return ["2xs", "xs", "sm", "lg", "xl", "2xl", "1x", "2x", "3x", "4x", "5x", "6x", "7x", "8x", "9x", "10x"].indexOf(t) > -1;
      }
    },
    spin: {
      type: Boolean,
      default: !1
    },
    transform: {
      type: [String, Object],
      default: null
    },
    symbol: {
      type: [Boolean, String],
      default: !1
    },
    title: {
      type: String,
      default: null
    },
    inverse: {
      type: Boolean,
      default: !1
    },
    bounce: {
      type: Boolean,
      default: !1
    },
    shake: {
      type: Boolean,
      default: !1
    },
    beat: {
      type: Boolean,
      default: !1
    },
    fade: {
      type: Boolean,
      default: !1
    },
    beatFade: {
      type: Boolean,
      default: !1
    },
    flash: {
      type: Boolean,
      default: !1
    },
    spinPulse: {
      type: Boolean,
      default: !1
    },
    spinReverse: {
      type: Boolean,
      default: !1
    }
  },
  setup: function(t, n) {
    var r = n.attrs, i = $(function() {
      return gc(t.icon);
    }), o = $(function() {
      return Zo("classes", x2(t));
    }), a = $(function() {
      return Zo("transform", typeof t.transform == "string" ? $a.transform(t.transform) : t.transform);
    }), s = $(function() {
      return Zo("mask", gc(t.mask));
    }), l = $(function() {
      return m2(i.value, Lt(Lt(Lt(Lt({}, o.value), a.value), s.value), {}, {
        symbol: t.symbol,
        title: t.title
      }));
    });
    bt(l, function(u) {
      if (!u)
        return w2("Could not find one or more icon(s)", i.value, s.value);
    }, {
      immediate: !0
    });
    var c = $(function() {
      return l.value ? af(l.value.abstract[0], {}, r) : null;
    });
    return function() {
      return c.value;
    };
  }
}), k2 = {
  prefix: "fab",
  iconName: "monero",
  icon: [496, 512, [], "f3d0", "M352 384h108.4C417 455.9 338.1 504 248 504S79 455.9 35.6 384H144V256.2L248 361l104-105v128zM88 336V128l159.4 159.4L408 128v208h74.8c8.5-25.1 13.2-52 13.2-80C496 119 385 8 248 8S0 119 0 256c0 28 4.6 54.9 13.2 80H88z"]
}, S2 = {
  prefix: "fab",
  iconName: "cc-stripe",
  icon: [576, 512, [], "f1f5", "M492.4 220.8c-8.9 0-18.7 6.7-18.7 22.7h36.7c0-16-9.3-22.7-18-22.7zM375 223.4c-8.2 0-13.3 2.9-17 7l.2 52.8c3.5 3.7 8.5 6.7 16.8 6.7 13.1 0 21.9-14.3 21.9-33.4 0-18.6-9-33.2-21.9-33.1zM528 32H48C21.5 32 0 53.5 0 80v352c0 26.5 21.5 48 48 48h480c26.5 0 48-21.5 48-48V80c0-26.5-21.5-48-48-48zM122.2 281.1c0 25.6-20.3 40.1-49.9 40.3-12.2 0-25.6-2.4-38.8-8.1v-33.9c12 6.4 27.1 11.3 38.9 11.3 7.9 0 13.6-2.1 13.6-8.7 0-17-54-10.6-54-49.9 0-25.2 19.2-40.2 48-40.2 11.8 0 23.5 1.8 35.3 6.5v33.4c-10.8-5.8-24.5-9.1-35.3-9.1-7.5 0-12.1 2.2-12.1 7.7 0 16 54.3 8.4 54.3 50.7zm68.8-56.6h-27V275c0 20.9 22.5 14.4 27 12.6v28.9c-4.7 2.6-13.3 4.7-24.9 4.7-21.1 0-36.9-15.5-36.9-36.5l.2-113.9 34.7-7.4v30.8H191zm74 2.4c-4.5-1.5-18.7-3.6-27.1 7.4v84.4h-35.5V194.2h30.7l2.2 10.5c8.3-15.3 24.9-12.2 29.6-10.5h.1zm44.1 91.8h-35.7V194.2h35.7zm0-142.9l-35.7 7.6v-28.9l35.7-7.6zm74.1 145.5c-12.4 0-20-5.3-25.1-9l-.1 40.2-35.5 7.5V194.2h31.3l1.8 8.8c4.9-4.5 13.9-11.1 27.8-11.1 24.9 0 48.4 22.5 48.4 63.8 0 45.1-23.2 65.5-48.6 65.6zm160.4-51.5h-69.5c1.6 16.6 13.8 21.5 27.6 21.5 14.1 0 25.2-3 34.9-7.9V312c-9.7 5.3-22.4 9.2-39.4 9.2-34.6 0-58.8-21.7-58.8-64.5 0-36.2 20.5-64.9 54.3-64.9 33.7 0 51.3 28.7 51.3 65.1 0 3.5-.3 10.9-.4 12.9z"]
}, O2 = {
  prefix: "fab",
  iconName: "bitcoin",
  icon: [512, 512, [], "f379", "M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zm-141.651-35.33c4.937-32.999-20.191-50.739-54.55-62.573l11.146-44.702-27.213-6.781-10.851 43.524c-7.154-1.783-14.502-3.464-21.803-5.13l10.929-43.81-27.198-6.781-11.153 44.686c-5.922-1.349-11.735-2.682-17.377-4.084l.031-.14-37.53-9.37-7.239 29.062s20.191 4.627 19.765 4.913c11.022 2.751 13.014 10.044 12.68 15.825l-12.696 50.925c.76.194 1.744.473 2.829.907-.907-.225-1.876-.473-2.876-.713l-17.796 71.338c-1.349 3.348-4.767 8.37-12.471 6.464.271.395-19.78-4.937-19.78-4.937l-13.51 31.147 35.414 8.827c6.588 1.651 13.045 3.379 19.4 5.006l-11.262 45.213 27.182 6.781 11.153-44.733a1038.209 1038.209 0 0 0 21.687 5.627l-11.115 44.523 27.213 6.781 11.262-45.128c46.404 8.781 81.299 5.239 95.986-36.727 11.836-33.79-.589-53.281-25.004-65.991 17.78-4.098 31.174-15.792 34.747-39.949zm-62.177 87.179c-8.41 33.79-65.308 15.523-83.755 10.943l14.944-59.899c18.446 4.603 77.6 13.717 68.811 48.956zm8.417-87.667c-7.673 30.736-55.031 15.12-70.393 11.292l13.548-54.327c15.363 3.828 64.836 10.973 56.845 43.035z"]
}, A2 = {
  prefix: "fab",
  iconName: "paypal",
  icon: [384, 512, [], "f1ed", "M111.4 295.9c-3.5 19.2-17.4 108.7-21.5 134-.3 1.8-1 2.5-3 2.5H12.3c-7.6 0-13.1-6.6-12.1-13.9L58.8 46.6c1.5-9.6 10.1-16.9 20-16.9 152.3 0 165.1-3.7 204 11.4 60.1 23.3 65.6 79.5 44 140.3-21.5 62.6-72.5 89.5-140.1 90.3-43.4.7-69.5-7-75.3 24.2zM357.1 152c-1.8-1.3-2.5-1.8-3 1.3-2 11.4-5.1 22.5-8.8 33.6-39.9 113.8-150.5 103.9-204.5 103.9-6.1 0-10.1 3.3-10.9 9.4-22.6 140.4-27.1 169.7-27.1 169.7-1 7.1 3.5 12.9 10.6 12.9h63.5c8.6 0 15.7-6.3 17.4-14.9.7-5.4-1.1 6.1 14.4-91.3 4.6-22 14.3-19.7 29.3-19.7 71 0 126.4-28.8 142.9-112.3 6.5-34.8 4.6-71.4-23.8-92.6z"]
}, N2 = {
  prefix: "fab",
  iconName: "ethereum",
  icon: [320, 512, [], "f42e", "M311.9 260.8L160 353.6 8 260.8 160 0l151.9 260.8zM160 383.4L8 290.6 160 512l152-221.4-152 92.8z"]
}, I2 = {
  prefix: "fas",
  iconName: "v",
  icon: [384, 512, [118], "56", "M19.7 34.5c16.3-6.8 35 .9 41.8 17.2L192 364.8 322.5 51.7c6.8-16.3 25.5-24 41.8-17.2s24 25.5 17.2 41.8l-160 384c-5 11.9-16.6 19.7-29.5 19.7s-24.6-7.8-29.5-19.7L2.5 76.3c-6.8-16.3 .9-35 17.2-41.8z"]
}, C2 = {
  prefix: "fas",
  iconName: "money-bill-wave",
  icon: [576, 512, [], "f53a", "M0 112.5V422.3c0 18 10.1 35 27 41.3c87 32.5 174 10.3 261-11.9c79.8-20.3 159.6-40.7 239.3-18.9c23 6.3 48.7-9.5 48.7-33.4V89.7c0-18-10.1-35-27-41.3C462 15.9 375 38.1 288 60.3C208.2 80.6 128.4 100.9 48.7 79.1C25.6 72.8 0 88.6 0 112.5zM288 352c-44.2 0-80-43-80-96s35.8-96 80-96s80 43 80 96s-35.8 96-80 96zM64 352c35.3 0 64 28.7 64 64H64V352zm64-208c0 35.3-28.7 64-64 64V144h64zM512 304v64H448c0-35.3 28.7-64 64-64zM448 96h64v64c-35.3 0-64-28.7-64-64z"]
}, T2 = {
  prefix: "fas",
  iconName: "bitcoin-sign",
  icon: [320, 512, [], "e0b4", "M48 32C48 14.3 62.3 0 80 0s32 14.3 32 32V64h32V32c0-17.7 14.3-32 32-32s32 14.3 32 32V64c0 1.5-.1 3.1-.3 4.5C254.1 82.2 288 125.1 288 176c0 24.2-7.7 46.6-20.7 64.9c31.7 19.8 52.7 55 52.7 95.1c0 61.9-50.1 112-112 112v32c0 17.7-14.3 32-32 32s-32-14.3-32-32V448H112v32c0 17.7-14.3 32-32 32s-32-14.3-32-32V448H41.7C18.7 448 0 429.3 0 406.3V288 265.7 224 101.6C0 80.8 16.8 64 37.6 64H48V32zM64 224H176c26.5 0 48-21.5 48-48s-21.5-48-48-48H64v96zm112 64H64v96H208c26.5 0 48-21.5 48-48s-21.5-48-48-48H176z"]
}, P2 = {
  prefix: "fas",
  iconName: "wallet",
  icon: [512, 512, [], "f555", "M64 32C28.7 32 0 60.7 0 96V416c0 35.3 28.7 64 64 64H448c35.3 0 64-28.7 64-64V192c0-35.3-28.7-64-64-64H80c-8.8 0-16-7.2-16-16s7.2-16 16-16H448c17.7 0 32-14.3 32-32s-14.3-32-32-32H64zM416 272a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"]
}, M2 = {
  prefix: "fas",
  iconName: "litecoin-sign",
  icon: [384, 512, [], "e1d3", "M128 64c0-17.7-14.3-32-32-32S64 46.3 64 64V213.6L23.2 225.2c-17 4.9-26.8 22.6-22 39.6s22.6 26.8 39.6 22L64 280.1V448c0 17.7 14.3 32 32 32H352c17.7 0 32-14.3 32-32s-14.3-32-32-32H128V261.9l136.8-39.1c17-4.9 26.8-22.6 22-39.6s-22.6-26.8-39.6-22L128 195.3V64z"]
}, R2 = {
  prefix: "fas",
  iconName: "coins",
  icon: [512, 512, [], "f51e", "M512 80c0 18-14.3 34.6-38.4 48c-29.1 16.1-72.5 27.5-122.3 30.9c-3.7-1.8-7.4-3.5-11.3-5C300.6 137.4 248.2 128 192 128c-8.3 0-16.4 .2-24.5 .6l-1.1-.6C142.3 114.6 128 98 128 80c0-44.2 86-80 192-80S512 35.8 512 80zM160.7 161.1c10.2-.7 20.7-1.1 31.3-1.1c62.2 0 117.4 12.3 152.5 31.4C369.3 204.9 384 221.7 384 240c0 4-.7 7.9-2.1 11.7c-4.6 13.2-17 25.3-35 35.5c0 0 0 0 0 0c-.1 .1-.3 .1-.4 .2l0 0 0 0c-.3 .2-.6 .3-.9 .5c-35 19.4-90.8 32-153.6 32c-59.6 0-112.9-11.3-148.2-29.1c-1.9-.9-3.7-1.9-5.5-2.9C14.3 274.6 0 258 0 240c0-34.8 53.4-64.5 128-75.4c10.5-1.5 21.4-2.7 32.7-3.5zM416 240c0-21.9-10.6-39.9-24.1-53.4c28.3-4.4 54.2-11.4 76.2-20.5c16.3-6.8 31.5-15.2 43.9-25.5V176c0 19.3-16.5 37.1-43.8 50.9c-14.6 7.4-32.4 13.7-52.4 18.5c.1-1.8 .2-3.5 .2-5.3zm-32 96c0 18-14.3 34.6-38.4 48c-1.8 1-3.6 1.9-5.5 2.9C304.9 404.7 251.6 416 192 416c-62.8 0-118.6-12.6-153.6-32C14.3 370.6 0 354 0 336V300.6c12.5 10.3 27.6 18.7 43.9 25.5C83.4 342.6 135.8 352 192 352s108.6-9.4 148.1-25.9c7.8-3.2 15.3-6.9 22.4-10.9c6.1-3.4 11.8-7.2 17.2-11.2c1.5-1.1 2.9-2.3 4.3-3.4V304v5.7V336zm32 0V304 278.1c19-4.2 36.5-9.5 52.1-16c16.3-6.8 31.5-15.2 43.9-25.5V272c0 10.5-5 21-14.9 30.9c-16.3 16.3-45 29.7-81.3 38.4c.1-1.7 .2-3.5 .2-5.3zM192 448c56.2 0 108.6-9.4 148.1-25.9c16.3-6.8 31.5-15.2 43.9-25.5V432c0 44.2-86 80-192 80S0 476.2 0 432V396.6c12.5 10.3 27.6 18.7 43.9 25.5C83.4 438.6 135.8 448 192 448z"]
}, D2 = {
  prefix: "fas",
  iconName: "credit-card",
  icon: [576, 512, [128179, 62083, "credit-card-alt"], "f09d", "M64 32C28.7 32 0 60.7 0 96v32H576V96c0-35.3-28.7-64-64-64H64zM576 224H0V416c0 35.3 28.7 64 64 64H512c35.3 0 64-28.7 64-64V224zM112 352h64c8.8 0 16 7.2 16 16s-7.2 16-16 16H112c-8.8 0-16-7.2-16-16s7.2-16 16-16zm112 16c0-8.8 7.2-16 16-16H368c8.8 0 16 7.2 16 16s-7.2 16-16 16H240c-8.8 0-16-7.2-16-16z"]
}, z2 = {
  prefix: "fas",
  iconName: "dollar-sign",
  icon: [320, 512, [128178, 61781, "dollar", "usd"], "24", "M160 0c17.7 0 32 14.3 32 32V67.7c1.6 .2 3.1 .4 4.7 .7c.4 .1 .7 .1 1.1 .2l48 8.8c17.4 3.2 28.9 19.9 25.7 37.2s-19.9 28.9-37.2 25.7l-47.5-8.7c-31.3-4.6-58.9-1.5-78.3 6.2s-27.2 18.3-29 28.1c-2 10.7-.5 16.7 1.2 20.4c1.8 3.9 5.5 8.3 12.8 13.2c16.3 10.7 41.3 17.7 73.7 26.3l2.9 .8c28.6 7.6 63.6 16.8 89.6 33.8c14.2 9.3 27.6 21.9 35.9 39.5c8.5 17.9 10.3 37.9 6.4 59.2c-6.9 38-33.1 63.4-65.6 76.7c-13.7 5.6-28.6 9.2-44.4 11V480c0 17.7-14.3 32-32 32s-32-14.3-32-32V445.1c-.4-.1-.9-.1-1.3-.2l-.2 0 0 0c-24.4-3.8-64.5-14.3-91.5-26.3c-16.1-7.2-23.4-26.1-16.2-42.2s26.1-23.4 42.2-16.2c20.9 9.3 55.3 18.5 75.2 21.6c31.9 4.7 58.2 2 76-5.3c16.9-6.9 24.6-16.9 26.8-28.9c1.9-10.6 .4-16.7-1.3-20.4c-1.9-4-5.6-8.4-13-13.3c-16.4-10.7-41.5-17.7-74-26.3l-2.8-.7 0 0C119.4 279.3 84.4 270 58.4 253c-14.2-9.3-27.5-22-35.8-39.6c-8.4-17.9-10.1-37.9-6.1-59.2C23.7 116 52.3 91.2 84.8 78.3c13.3-5.3 27.9-8.9 43.2-11V32c0-17.7 14.3-32 32-32z"]
};
const L2 = {
  name: "Cryptoicon",
  props: {
    symbol: {
      type: String,
      default: null
    },
    color: {
      type: String,
      default: null
    },
    size: {
      type: [String, Number],
      default: "24"
    },
    generic: {
      type: Boolean,
      default: !1
    }
  },
  data() {
    return {
      lookupSymbol: /* @__PURE__ */ new Map([["BCHSV", "BSV"], ["BCHABC", "BAB"]])
    };
  },
  computed: {
    lSymbol() {
      return this.symbol && this.symbol.toLowerCase();
    },
    uSymbol() {
      return this.symbol && this.symbol.toUpperCase();
    },
    icon() {
      const e = this.lookupSymbol.has(this.uSymbol) ? this.lookupSymbol.get(this.uSymbol) : this.symbol;
      let t = this.$options.lib.find((n) => n.symbol === e.toLowerCase());
      if (t)
        return this.color ? t.plainIcon(this.color) : t.colorIcon();
      if (this.generic) {
        let n = this.$options.lib.find((r) => r.symbol == "generic");
        if (n)
          return this.color ? n.plainIcon(this.color) : n.colorIcon();
      } else {
        console.error(`Symbol of the icon is not correct: ${this.symbol}`);
        return;
      }
    }
  },
  lib: [],
  add(e) {
    Array.isArray(e) ? this.lib = e : this.lib.push(e);
  }
}, $2 = ["width", "height", "innerHTML"];
function F2(e, t, n, r, i, o) {
  return D(), Y("svg", {
    width: n.size,
    height: n.size,
    class: _e(`cryptoicon--${n.symbol}`),
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 32 32",
    onClick: t[0] || (t[0] = (a) => e.$emit("click")),
    innerHTML: o.icon
  }, null, 10, $2);
}
const lf = /* @__PURE__ */ qe(L2, [["render", F2]]), V2 = {
  symbol: "bnb",
  color: "#000",
  colorIcon() {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><g fill="none"><circle cx="16" cy="16" r="16" fill="#F3BA2F"/><path fill="#FFF" d="M12.116 14.404L16 10.52l3.886 3.886 2.26-2.26L16 6l-6.144 6.144 2.26 2.26zM6 16l2.26-2.26L10.52 16l-2.26 2.26L6 16zm6.116 1.596L16 21.48l3.886-3.886 2.26 2.259L16 26l-6.144-6.144-.003-.003 2.263-2.257zM21.48 16l2.26-2.26L26 16l-2.26 2.26L21.48 16zm-3.188-.002h.002V16L16 18.294l-2.291-2.29-.004-.004.004-.003.401-.402.195-.195L16 13.706l2.293 2.293z"/></g>';
  },
  plainIcon: (e) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path fill-rule="evenodd" fill="${e || globalThis.color}" d="M16 32C7.163 32 0 24.837 0 16S7.163 0 16 0s16 7.163 16 16-7.163 16-16 16zm-3.884-17.596L16 10.52l3.886 3.886 2.26-2.26L16 6l-6.144 6.144 2.26 2.26zM6 16l2.26 2.26L10.52 16l-2.26-2.26L6 16zm6.116 1.596l-2.263 2.257.003.003L16 26l6.146-6.146v-.001l-2.26-2.26L16 21.48l-3.884-3.884zM21.48 16l2.26 2.26L26 16l-2.26-2.26L21.48 16zm-3.188-.002h.001L16 13.706 14.305 15.4l-.195.195-.401.402-.004.003.004.003 2.29 2.291 2.294-2.293.001-.001-.002-.001z"/>`
}, j2 = {
  symbol: "btc",
  color: "#000",
  colorIcon() {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><g fill="none" fill-rule="evenodd"><circle cx="16" cy="16" r="16" fill="#F7931A"/><path fill="#FFF" fill-rule="nonzero" d="M23.189 14.02c.314-2.096-1.283-3.223-3.465-3.975l.708-2.84-1.728-.43-.69 2.765c-.454-.114-.92-.22-1.385-.326l.695-2.783L15.596 6l-.708 2.839c-.376-.086-.746-.17-1.104-.26l.002-.009-2.384-.595-.46 1.846s1.283.294 1.256.312c.7.175.826.638.805 1.006l-.806 3.235c.048.012.11.03.18.057l-.183-.045-1.13 4.532c-.086.212-.303.531-.793.41.018.025-1.256-.313-1.256-.313l-.858 1.978 2.25.561c.418.105.828.215 1.231.318l-.715 2.872 1.727.43.708-2.84c.472.127.93.245 1.378.357l-.706 2.828 1.728.43.715-2.866c2.948.558 5.164.333 6.097-2.333.752-2.146-.037-3.385-1.588-4.192 1.13-.26 1.98-1.003 2.207-2.538zm-3.95 5.538c-.533 2.147-4.148.986-5.32.695l.95-3.805c1.172.293 4.929.872 4.37 3.11zm.535-5.569c-.487 1.953-3.495.96-4.47.717l.86-3.45c.975.243 4.118.696 3.61 2.733z"/></g>';
  },
  plainIcon: (e) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path fill-rule="evenodd" fill="${e || globalThis.color}" fill-rule="evenodd" d="M16 32C7.163 32 0 24.837 0 16S7.163 0 16 0s16 7.163 16 16-7.163 16-16 16zm7.189-17.98c.314-2.096-1.283-3.223-3.465-3.975l.708-2.84-1.728-.43-.69 2.765c-.454-.114-.92-.22-1.385-.326l.695-2.783L15.596 6l-.708 2.839c-.376-.086-.746-.17-1.104-.26l.002-.009-2.384-.595-.46 1.846s1.283.294 1.256.312c.7.175.826.638.805 1.006l-.806 3.235c.048.012.11.03.18.057l-.183-.045-1.13 4.532c-.086.212-.303.531-.793.41.018.025-1.256-.313-1.256-.313l-.858 1.978 2.25.561c.418.105.828.215 1.231.318l-.715 2.872 1.727.43.708-2.84c.472.127.93.245 1.378.357l-.706 2.828 1.728.43.715-2.866c2.948.558 5.164.333 6.097-2.333.752-2.146-.037-3.385-1.588-4.192 1.13-.26 1.98-1.003 2.207-2.538zm-3.95 5.538c-.533 2.147-4.148.986-5.32.695l.95-3.805c1.172.293 4.929.872 4.37 3.11zm.535-5.569c-.487 1.953-3.495.96-4.47.717l.86-3.45c.975.243 4.118.696 3.61 2.733z"/>`
}, U2 = {
  symbol: "dai",
  color: "#000",
  colorIcon() {
    return '<g fill="none" fill-rule="evenodd"><circle fill="#F4B731" fill-rule="nonzero" cx="16" cy="16" r="16"/><path d="M9.277 8h6.552c3.985 0 7.006 2.116 8.13 5.194H26v1.861h-1.611c.031.294.047.594.047.898v.046c0 .342-.02.68-.06 1.01H26v1.86h-2.08C22.767 21.905 19.77 24 15.83 24H9.277v-5.131H7v-1.86h2.277v-1.954H7v-1.86h2.277V8zm1.831 10.869v3.462h4.72c2.914 0 5.078-1.387 6.085-3.462H11.108zm11.366-1.86H11.108v-1.954h11.37c.041.307.063.622.063.944v.045c0 .329-.023.65-.067.964zM15.83 9.665c2.926 0 5.097 1.424 6.098 3.528h-10.82V9.666h4.72z" fill="#FFF"/></g>';
  },
  plainIcon: (e) => `<path fill-rule="evenodd" fill="${e || globalThis.color}" d="M16 0c8.837 0 16 7.163 16 16s-7.163 16-16 16S0 24.837 0 16 7.163 0 16 0zm-.171 8H9.277v5.194H7v1.861h2.277v1.953H7v1.86h2.277V24h6.552c3.94 0 6.938-2.095 8.091-5.131H26v-1.86h-1.624c.04-.33.06-.668.06-1.01v-.046c0-.304-.016-.604-.047-.898H26v-1.86h-2.041C22.835 10.114 19.814 8 15.829 8zm6.084 10.869c-1.007 2.075-3.171 3.462-6.084 3.462h-4.72v-3.462zm.564-3.814c.042.307.064.622.064.944v.045c0 .329-.023.65-.067.964H11.108v-1.953h11.37zM15.83 9.666c2.926 0 5.097 1.424 6.098 3.528h-10.82V9.666h4.72z"/>`
}, H2 = {
  symbol: "eth",
  color: "#000",
  colorIcon() {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><g fill="none" fill-rule="evenodd"><circle cx="16" cy="16" r="16" fill="#627EEA"/><g fill="#FFF" fill-rule="nonzero"><path fill-opacity=".602" d="M16.498 4v8.87l7.497 3.35z"/><path d="M16.498 4L9 16.22l7.498-3.35z"/><path fill-opacity=".602" d="M16.498 21.968v6.027L24 17.616z"/><path d="M16.498 27.995v-6.028L9 17.616z"/><path fill-opacity=".2" d="M16.498 20.573l7.497-4.353-7.497-3.348z"/><path fill-opacity=".602" d="M9 16.22l7.498 4.353v-7.701z"/></g></g>';
  },
  plainIcon: (e) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><g fill-rule="evenodd"><path fill-rule="evenodd" fill="${e || globalThis.color}" d="M16 32C7.163 32 0 24.837 0 16S7.163 0 16 0s16 7.163 16 16-7.163 16-16 16zm7.994-15.781L16.498 4 9 16.22l7.498 4.353 7.496-4.354zM24 17.616l-7.502 4.351L9 17.617l7.498 10.378L24 17.616z"/><g fill-rule="nonzero"><path fill-opacity=".298" d="M16.498 4v8.87l7.497 3.35zm0 17.968v6.027L24 17.616z"/><path fill-opacity=".801" d="M16.498 20.573l7.497-4.353-7.497-3.348z"/><path fill-opacity=".298" d="M9 16.22l7.498 4.353v-7.701z"/></g></g>`
}, B2 = {
  symbol: "ltc",
  color: "#000",
  colorIcon() {
    return '<g fill="none" fill-rule="evenodd"><circle cx="16" cy="16" r="16" fill="#BFBBBB"/><path fill="#FFF" d="M10.427 19.214L9 19.768l.688-2.759 1.444-.58L13.213 8h5.129l-1.519 6.196 1.41-.571-.68 2.75-1.427.571-.848 3.483H23L22.127 24H9.252z"/></g>';
  },
  plainIcon: (e) => `<path fill-rule="evenodd" fill="${e || globalThis.color}" fill-rule="evenodd" d="M16 32C7.163 32 0 24.837 0 16S7.163 0 16 0s16 7.163 16 16-7.163 16-16 16zm-5.573-12.786L9.252 24h12.875L23 20.429h-7.722l.848-3.483 1.427-.571.68-2.75-1.41.571L18.342 8h-5.129l-2.081 8.429-1.444.58L9 19.768l1.427-.554z"/>`
}, G2 = {
  symbol: "matic",
  color: "#000",
  colorIcon() {
    return '<g fill="none"><circle fill="#6F41D8" cx="16" cy="16" r="16"/><path d="M21.092 12.693c-.369-.215-.848-.215-1.254 0l-2.879 1.654-1.955 1.078-2.879 1.653c-.369.216-.848.216-1.254 0l-2.288-1.294c-.369-.215-.627-.61-.627-1.042V12.19c0-.431.221-.826.627-1.042l2.25-1.258c.37-.216.85-.216 1.256 0l2.25 1.258c.37.216.628.611.628 1.042v1.654l1.955-1.115v-1.653a1.16 1.16 0 00-.627-1.042l-4.17-2.372c-.369-.216-.848-.216-1.254 0l-4.244 2.372A1.16 1.16 0 006 11.076v4.78c0 .432.221.827.627 1.043l4.244 2.372c.369.215.849.215 1.254 0l2.879-1.618 1.955-1.114 2.879-1.617c.369-.216.848-.216 1.254 0l2.251 1.258c.37.215.627.61.627 1.042v2.552c0 .431-.22.826-.627 1.042l-2.25 1.294c-.37.216-.85.216-1.255 0l-2.251-1.258c-.37-.216-.628-.611-.628-1.042v-1.654l-1.955 1.115v1.653c0 .431.221.827.627 1.042l4.244 2.372c.369.216.848.216 1.254 0l4.244-2.372c.369-.215.627-.61.627-1.042v-4.78a1.16 1.16 0 00-.627-1.042l-4.28-2.409z" fill="#FFF"/></g>';
  },
  plainIcon: (e) => `<path fill-rule="evenodd" fill="${e || globalThis.color}" d="M16 0c8.837 0 16 7.163 16 16s-7.163 16-16 16S0 24.837 0 16 7.163 0 16 0zm-5.13 7.662l-4.243 2.372A1.16 1.16 0 006 11.076v4.78c0 .432.221.827.627 1.043l4.244 2.372c.369.215.849.215 1.254 0l2.879-1.618 1.955-1.114 2.879-1.617c.369-.216.848-.216 1.254 0l2.251 1.258c.37.215.627.61.627 1.042v2.552c0 .431-.22.826-.627 1.042l-2.25 1.294c-.37.216-.85.216-1.255 0l-2.251-1.258c-.37-.216-.628-.611-.628-1.042v-1.654l-1.955 1.115v1.653c0 .431.221.827.627 1.042l4.244 2.372c.369.216.848.216 1.254 0l4.244-2.372c.369-.215.627-.61.627-1.042v-4.78a1.16 1.16 0 00-.627-1.042l-4.28-2.409c-.37-.215-.85-.215-1.255 0l-2.879 1.654-1.955 1.078-2.879 1.653c-.369.216-.848.216-1.254 0l-2.288-1.294c-.369-.215-.627-.61-.627-1.042V12.19c0-.431.221-.826.627-1.042l2.25-1.258c.37-.216.85-.216 1.256 0l2.25 1.258c.37.216.628.611.628 1.042v1.654l1.955-1.115v-1.653a1.16 1.16 0 00-.627-1.042l-4.17-2.372c-.369-.216-.848-.216-1.254 0z"/>`
}, Y2 = {
  symbol: "trx",
  color: "#000",
  colorIcon() {
    return '<g fill="none"><circle fill="#EF0027" cx="16" cy="16" r="16"/><path d="M21.932 9.913L7.5 7.257l7.595 19.112 10.583-12.894-3.746-3.562zm-.232 1.17l2.208 2.099-6.038 1.093 3.83-3.192zm-5.142 2.973l-6.364-5.278 10.402 1.914-4.038 3.364zm-.453.934l-1.038 8.58L9.472 9.487l6.633 5.502zm.96.455l6.687-1.21-7.67 9.343.983-8.133z" fill="#FFF"/></g>';
  },
  plainIcon: (e) => `<path fill-rule="evenodd" fill="${e || globalThis.color}" d="M16 0c8.837 0 16 7.163 16 16s-7.163 16-16 16S0 24.837 0 16 7.163 0 16 0zM7.5 7.257l7.595 19.112 10.583-12.894-3.746-3.562L7.5 7.257zm16.252 6.977l-7.67 9.344.983-8.133 6.687-1.21zM9.472 9.488l6.633 5.502-1.038 8.58L9.472 9.487zM21.7 11.083l2.208 2.099-6.038 1.093 3.83-3.192zM10.194 8.778l10.402 1.914-4.038 3.364-6.364-5.278z"/>`
}, W2 = {
  symbol: "uni",
  color: "#000",
  colorIcon() {
    return '<g fill="none" fill-rule="evenodd"><circle fill="#FF007A" fill-rule="nonzero" cx="16" cy="16" r="16"/><g fill="#FFF"><path d="M12.261 5.767c-.285-.044-.297-.05-.163-.07.257-.04.865.015 1.284.114.977.233 1.866.828 2.816 1.885l.252.28.36-.057c1.52-.245 3.067-.05 4.36.547.356.164.917.491.987.576.023.026.064.199.091.383.096.637.048 1.125-.146 1.49-.106.198-.112.26-.041.43a.416.416 0 00.372.236c.322 0 .668-.52.828-1.243l.064-.287.126.143c.692.784 1.235 1.853 1.328 2.613l.025.199-.117-.18c-.2-.31-.4-.522-.658-.693-.464-.307-.955-.411-2.255-.48-1.174-.062-1.839-.162-2.497-.377-1.121-.365-1.686-.852-3.018-2.599-.591-.776-.957-1.205-1.32-1.55-.827-.786-1.639-1.198-2.678-1.36z" fill-rule="nonzero"/><path d="M22.422 7.5c.03-.52.1-.863.242-1.176.056-.124.109-.226.117-.226a.773.773 0 01-.055.204c-.103.304-.12.72-.049 1.203.09.614.142.702.79 1.365.305.311.659.703.787.872l.233.306-.233-.219c-.285-.267-.941-.79-1.086-.864-.097-.05-.112-.049-.172.01-.055.056-.067.138-.074.529-.012.608-.095 1-.296 1.39-.108.21-.125.166-.027-.073.073-.178.08-.256.08-.845 0-1.184-.141-1.468-.966-1.956a9.046 9.046 0 00-.764-.396 2.916 2.916 0 01-.374-.182c.023-.023.827.211 1.15.336.482.185.561.209.62.186.039-.015.058-.129.077-.464zm-9.607 2.025c-.579-.797-.937-2.02-.86-2.934l.024-.283.132.024c.248.045.675.204.875.326.548.333.786.772 1.027 1.898.071.33.164.703.207.83.068.203.328.678.54.987.152.222.05.327-.286.297-.514-.047-1.21-.527-1.659-1.145zm8.905 5.935c-2.707-1.09-3.66-2.036-3.66-3.632 0-.235.008-.427.017-.427.01 0 .115.077.233.172.549.44 1.164.628 2.865.876 1.001.147 1.565.265 2.085.437 1.652.548 2.674 1.66 2.918 3.174.07.44.029 1.265-.086 1.7-.09.344-.367.963-.44.987-.02.006-.04-.071-.046-.178-.028-.568-.315-1.122-.798-1.537-.549-.471-1.286-.847-3.089-1.572zm-1.9.452a4.808 4.808 0 00-.131-.572l-.07-.206.129.144c.177.2.318.454.436.794.091.259.101.336.1.757 0 .414-.011.5-.095.734a2.32 2.32 0 01-.571.908c-.495.504-1.13.782-2.048.898-.16.02-.624.054-1.033.075-1.03.054-1.707.164-2.316.378a.488.488 0 01-.174.042c-.024-.025.39-.272.733-.437.483-.233.963-.36 2.04-.539.532-.089 1.082-.196 1.221-.239 1.318-.404 1.995-1.446 1.778-2.737z" fill-rule="nonzero"/><path d="M21.06 18.116c-.36-.773-.442-1.52-.245-2.216.021-.074.055-.135.075-.135a.73.73 0 01.189.102c.166.112.498.3 1.383.782 1.105.603 1.735 1.07 2.164 1.602.375.467.607.999.719 1.647.063.367.026 1.25-.068 1.62-.297 1.166-.988 2.082-1.972 2.616a2.53 2.53 0 01-.288.143c-.014 0 .038-.133.117-.297.33-.692.369-1.366.118-2.116-.153-.459-.466-1.02-1.097-1.966-.734-1.1-.914-1.394-1.095-1.782zm-10.167 4.171c1.005-.848 2.254-1.45 3.393-1.635.49-.08 1.308-.048 1.762.068.728.186 1.38.604 1.719 1.101.33.486.473.91.62 1.852.06.372.123.745.142.83.11.488.327.879.595 1.075.425.311 1.158.33 1.878.05a.981.981 0 01.236-.074c.026.026-.336.269-.592.397a2.014 2.014 0 01-.983.238c-.66 0-1.208-.335-1.665-1.02-.09-.135-.292-.538-.45-.897-.482-1.1-.72-1.436-1.28-1.803-.489-.32-1.118-.377-1.591-.145-.622.305-.795 1.1-.35 1.603.177.2.507.373.777.406a.83.83 0 00.939-.83c0-.332-.128-.52-.448-.665-.437-.197-.907.033-.905.444.001.175.077.285.253.365.113.05.115.055.023.036-.401-.084-.495-.567-.172-.888.387-.386 1.188-.216 1.463.31.116.221.129.662.028.928-.225.595-.883.907-1.55.737-.454-.116-.639-.241-1.186-.805-.951-.98-1.32-1.17-2.692-1.384l-.263-.041.3-.253z" fill-rule="nonzero"/><path d="M6.196 3.35l.096.117c3.708 4.54 5.624 6.896 5.746 7.064.2.278.125.527-.219.723-.191.109-.585.219-.781.219-.223 0-.474-.107-.657-.28-.129-.123-.65-.901-1.853-2.768a188.53 188.53 0 00-1.712-2.633c-.049-.046-.048-.045 1.618 2.936 1.046 1.872 1.4 2.533 1.4 2.622 0 .18-.05.274-.272.522-.37.413-.535.877-.655 1.837-.134 1.077-.51 1.837-1.554 3.138-.61.762-.71.902-.865 1.209-.194.386-.247.603-.269 1.091-.023.516.022.85.18 1.343.138.432.282.718.65 1.288.318.493.501.859.501 1.002 0 .114.022.114.515.003 1.179-.266 2.136-.735 2.675-1.309.333-.355.411-.551.414-1.038.001-.318-.01-.385-.096-.568-.14-.298-.395-.546-.957-.93-.737-.504-1.051-.91-1.138-1.467-.072-.457.011-.78.419-1.634.421-.884.526-1.26.597-2.151.045-.576.108-.803.274-.985.172-.19.328-.255.755-.313.696-.095 1.139-.275 1.503-.61.316-.292.448-.573.468-.995l.016-.32-.177-.206c-.254-.296-2.355-2.614-6.304-6.956l-.106-.115-.212.165zM7.91 19.732a.566.566 0 00-.174-.746c-.228-.152-.583-.08-.583.118 0 .06.033.104.108.143.127.065.136.139.037.288-.101.152-.093.286.023.377.186.146.45.065.59-.18zm5.524-7.176c-.327.1-.644.447-.743.81-.06.221-.026.61.064.73.145.194.286.245.666.242.744-.005 1.39-.324 1.466-.723.062-.327-.223-.78-.614-.98-.202-.102-.631-.143-.839-.079zm.87.68c.115-.163.064-.34-.13-.458-.372-.227-.934-.04-.934.312 0 .174.293.365.561.365.18 0 .424-.107.503-.219z"/></g></g>';
  },
  plainIcon: (e) => `<path fill-rule="evenodd" fill="${e || globalThis.color}" d="M16 0c8.837 0 16 7.163 16 16s-7.163 16-16 16S0 24.837 0 16A15.97 15.97 0 016.199 3.353l.093.114.25.306c3.544 4.34 5.376 6.593 5.496 6.758.2.278.125.527-.219.723-.191.109-.585.219-.781.219-.223 0-.474-.107-.657-.28a1.453 1.453 0 01-.134-.167l-.086-.119c-.27-.384-.78-1.16-1.633-2.482a188.53 188.53 0 00-1.712-2.633l-.012-.01c-.002 0-.001.004.004.016l.032.064c.103.198.469.852 1.594 2.866 1.046 1.872 1.4 2.533 1.4 2.622 0 .18-.05.274-.272.522-.37.413-.535.877-.655 1.837-.134 1.077-.51 1.837-1.554 3.138-.61.762-.71.902-.865 1.209-.194.386-.247.603-.269 1.091-.023.516.022.85.18 1.343.138.432.282.718.65 1.288.318.493.501.859.501 1.002 0 .114.022.114.515.003 1.179-.266 2.136-.735 2.675-1.309.333-.355.411-.551.414-1.038.001-.318-.01-.385-.096-.568-.14-.298-.395-.546-.957-.93-.737-.504-1.051-.91-1.138-1.467-.072-.457.011-.78.419-1.634.421-.884.526-1.26.597-2.151.045-.576.108-.803.274-.985.172-.19.328-.255.755-.313.696-.095 1.139-.275 1.503-.61.316-.292.448-.573.468-.995l.016-.32-.177-.206-.02-.024c-.332-.38-2.427-2.691-6.284-6.932l-.102-.111A15.93 15.93 0 0116 0zm.048 20.72c-.454-.116-1.271-.148-1.762-.068-1.139.185-2.388.787-3.393 1.635l-.299.253.263.04c1.371.215 1.74.405 2.692 1.385.547.564.732.69 1.186.805.667.17 1.325-.142 1.55-.737.101-.266.088-.707-.028-.928-.275-.526-1.076-.696-1.463-.31-.323.32-.229.804.172.888.092.019.09.015-.023-.036-.176-.08-.252-.19-.253-.365-.002-.41.468-.641.905-.444.32.144.448.333.448.664a.83.83 0 01-.939.831 1.38 1.38 0 01-.777-.406c-.445-.504-.272-1.298.35-1.603.473-.232 1.102-.175 1.59.145.56.367.799.702 1.282 1.803.157.359.36.762.45.897.456.685 1.004 1.02 1.664 1.02.364 0 .638-.066.983-.238.256-.128.618-.37.592-.397a1.005 1.005 0 00-.236.073c-.72.281-1.453.262-1.878-.05-.268-.195-.484-.586-.595-1.074a23.05 23.05 0 01-.141-.83c-.148-.942-.29-1.366-.621-1.852-.34-.497-.99-.915-1.719-1.101zm4.842-4.955c-.02 0-.054.061-.075.135-.197.697-.115 1.443.245 2.216l.065.135c.166.333.382.676 1.03 1.647.631.947.944 1.507 1.097 1.966.25.75.213 1.424-.118 2.116-.079.164-.131.297-.117.297.014 0 .143-.064.288-.143.984-.534 1.675-1.45 1.972-2.616.094-.37.131-1.253.068-1.62-.112-.648-.344-1.18-.72-1.647-.428-.533-1.058-1-2.163-1.602-.885-.482-1.217-.67-1.383-.782a.73.73 0 00-.189-.102zM7.152 19.103c0-.198.355-.27.583-.118.242.16.319.49.174.746-.138.245-.403.326-.59.18-.115-.091-.123-.225-.022-.377.1-.15.09-.223-.037-.288-.075-.039-.108-.083-.108-.143zm12.468-3.97l.069.207a4.8 4.8 0 01.13.572c.217 1.29-.46 2.333-1.778 2.737-.14.043-.689.15-1.22.239-1.078.18-1.558.306-2.041.539-.343.165-.757.412-.733.437a.488.488 0 00.174-.042c.609-.214 1.287-.324 2.316-.378.409-.021.874-.055 1.033-.075.918-.116 1.553-.394 2.048-.898.275-.28.439-.54.57-.908.085-.234.096-.32.097-.734 0-.421-.01-.498-.1-.757-.12-.34-.26-.595-.437-.794l-.128-.144zm-1.543-3.732c-.01 0-.018.192-.018.427 0 1.596.954 2.542 3.66 3.632 1.803.725 2.54 1.1 3.09 1.572.482.415.77.969.797 1.537.005.107.025.184.045.178.074-.024.35-.643.441-.987.115-.435.156-1.26.086-1.7-.244-1.514-1.266-2.626-2.918-3.174-.52-.172-1.084-.29-2.085-.437-1.701-.248-2.316-.436-2.865-.876a2.057 2.057 0 00-.233-.172zm-3.804 1.235c-.202-.103-.631-.144-.839-.08-.327.1-.644.447-.743.81-.06.221-.026.61.064.73.145.194.286.245.666.242.744-.005 1.39-.324 1.466-.723.062-.327-.223-.78-.614-.98zm-1.033.454c0-.351.562-.54.933-.312.195.119.246.295.13.458-.078.112-.323.22-.502.22-.268 0-.561-.192-.561-.366zm.142-7.279c-.419-.1-1.027-.153-1.284-.114-.134.02-.122.026.163.07 1.04.162 1.851.574 2.678 1.36.363.345.729.774 1.32 1.55 1.332 1.747 1.897 2.234 3.018 2.6.658.214 1.323.314 2.497.376 1.3.069 1.79.173 2.255.48.257.17.458.382.658.692l.117.18-.025-.198c-.093-.76-.636-1.83-1.328-2.613l-.126-.143-.064.287c-.16.723-.506 1.242-.828 1.243a.416.416 0 01-.372-.236c-.071-.17-.065-.232.04-.43.195-.365.243-.853.147-1.49-.027-.184-.068-.357-.09-.383-.07-.085-.632-.412-.988-.576-1.293-.598-2.84-.792-4.36-.547l-.36.058-.252-.281c-.95-1.057-1.839-1.652-2.816-1.885zm9.399.287c-.008 0-.061.102-.117.226-.142.313-.212.656-.242 1.176-.019.335-.038.45-.077.464-.059.023-.138-.001-.62-.186-.323-.125-1.127-.36-1.15-.336-.006.006.162.088.374.182s.556.272.764.396c.825.488.965.772.966 1.956 0 .59-.007.667-.08.845-.098.239-.08.284.027.073.2-.39.284-.782.296-1.39.007-.39.019-.473.074-.528.06-.06.075-.06.172-.01.145.074.8.596 1.086.863l.233.219-.233-.306c-.128-.169-.482-.56-.787-.872-.648-.663-.7-.751-.79-1.365-.07-.484-.054-.9.05-1.203a.773.773 0 00.054-.204zm-10.802.21l-.024.283c-.077.914.281 2.137.86 2.934.45.618 1.145 1.098 1.66 1.145.336.03.437-.075.285-.297-.212-.309-.472-.784-.54-.988a10.64 10.64 0 01-.207-.83c-.241-1.125-.479-1.564-1.027-1.897a3.31 3.31 0 00-.875-.326l-.132-.024z"/>`
}, q2 = {
  symbol: "usdc",
  color: "#000",
  colorIcon() {
    return '<g fill="none"><circle fill="#3E73C4" cx="16" cy="16" r="16"/><g fill="#FFF"><path d="M20.022 18.124c0-2.124-1.28-2.852-3.84-3.156-1.828-.243-2.193-.728-2.193-1.578 0-.85.61-1.396 1.828-1.396 1.097 0 1.707.364 2.011 1.275a.458.458 0 00.427.303h.975a.416.416 0 00.427-.425v-.06a3.04 3.04 0 00-2.743-2.489V9.142c0-.243-.183-.425-.487-.486h-.915c-.243 0-.426.182-.487.486v1.396c-1.829.242-2.986 1.456-2.986 2.974 0 2.002 1.218 2.791 3.778 3.095 1.707.303 2.255.668 2.255 1.639 0 .97-.853 1.638-2.011 1.638-1.585 0-2.133-.667-2.316-1.578-.06-.242-.244-.364-.427-.364h-1.036a.416.416 0 00-.426.425v.06c.243 1.518 1.219 2.61 3.23 2.914v1.457c0 .242.183.425.487.485h.915c.243 0 .426-.182.487-.485V21.34c1.829-.303 3.047-1.578 3.047-3.217z"/><path d="M12.892 24.497c-4.754-1.7-7.192-6.98-5.424-11.653.914-2.55 2.925-4.491 5.424-5.402.244-.121.365-.303.365-.607v-.85c0-.242-.121-.424-.365-.485-.061 0-.183 0-.244.06a10.895 10.895 0 00-7.13 13.717c1.096 3.4 3.717 6.01 7.13 7.102.244.121.488 0 .548-.243.061-.06.061-.122.061-.243v-.85c0-.182-.182-.424-.365-.546zm6.46-18.936c-.244-.122-.488 0-.548.242-.061.061-.061.122-.061.243v.85c0 .243.182.485.365.607 4.754 1.7 7.192 6.98 5.424 11.653-.914 2.55-2.925 4.491-5.424 5.402-.244.121-.365.303-.365.607v.85c0 .242.121.424.365.485.061 0 .183 0 .244-.06a10.895 10.895 0 007.13-13.717c-1.096-3.46-3.778-6.07-7.13-7.162z"/></g></g>';
  },
  plainIcon: (e) => `<path fill-rule="evenodd" fill="${e || globalThis.color}" d="M16 0c8.837 0 16 7.163 16 16s-7.163 16-16 16S0 24.837 0 16 7.163 0 16 0zm3.352 5.56c-.244-.12-.488 0-.548.243-.061.061-.061.122-.061.243v.85l.01.104a.86.86 0 00.355.503c4.754 1.7 7.192 6.98 5.424 11.653-.914 2.55-2.925 4.491-5.424 5.402-.244.121-.365.303-.365.607v.85l.005.088a.45.45 0 00.36.397c.061 0 .183 0 .244-.06a10.895 10.895 0 007.13-13.717c-1.096-3.46-3.778-6.07-7.13-7.162zm-6.46-.06c-.061 0-.183 0-.244.06a10.895 10.895 0 00-7.13 13.717c1.096 3.4 3.717 6.01 7.13 7.102.244.121.488 0 .548-.243.061-.06.061-.122.061-.243v-.85l-.01-.08c-.042-.169-.199-.362-.355-.466-4.754-1.7-7.192-6.98-5.424-11.653.914-2.55 2.925-4.491 5.424-5.402.244-.121.365-.303.365-.607v-.85l-.005-.088a.45.45 0 00-.36-.397zm3.535 3.156h-.915l-.088.008c-.2.04-.346.212-.4.478v1.396l-.207.032c-1.708.304-2.778 1.483-2.778 2.942 0 2.002 1.218 2.791 3.778 3.095 1.707.303 2.255.668 2.255 1.639 0 .97-.853 1.638-2.011 1.638-1.585 0-2.133-.667-2.316-1.578-.06-.242-.244-.364-.427-.364h-1.036l-.079.007a.413.413 0 00-.347.418v.06l.033.18c.29 1.424 1.266 2.443 3.197 2.734v1.457l.008.088c.04.198.213.344.48.397h.914l.088-.008c.2-.04.346-.212.4-.477V21.34l.207-.04c1.713-.362 2.84-1.601 2.84-3.177 0-2.124-1.28-2.852-3.84-3.156-1.829-.243-2.194-.728-2.194-1.578 0-.85.61-1.396 1.828-1.396 1.097 0 1.707.364 2.011 1.275a.458.458 0 00.427.303h.975l.079-.006a.413.413 0 00.348-.419v-.06l-.037-.173a3.04 3.04 0 00-2.706-2.316V9.142l-.008-.088c-.04-.199-.213-.345-.48-.398z"/>`
}, K2 = {
  symbol: "usdt",
  color: "#000",
  colorIcon() {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><g fill="none" fill-rule="evenodd"><circle cx="16" cy="16" r="16" fill="#26A17B"/><path fill="#FFF" d="M17.922 17.383v-.002c-.11.008-.677.042-1.942.042-1.01 0-1.721-.03-1.971-.042v.003c-3.888-.171-6.79-.848-6.79-1.658 0-.809 2.902-1.486 6.79-1.66v2.644c.254.018.982.061 1.988.061 1.207 0 1.812-.05 1.925-.06v-2.643c3.88.173 6.775.85 6.775 1.658 0 .81-2.895 1.485-6.775 1.657m0-3.59v-2.366h5.414V7.819H8.595v3.608h5.414v2.365c-4.4.202-7.709 1.074-7.709 2.118 0 1.044 3.309 1.915 7.709 2.118v7.582h3.913v-7.584c4.393-.202 7.694-1.073 7.694-2.116 0-1.043-3.301-1.914-7.694-2.117"/></g>';
  },
  plainIcon: (e) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path fill-rule="evenodd" fill="${e || globalThis.color}" fill-rule="evenodd" d="M16 32C7.163 32 0 24.837 0 16S7.163 0 16 0s16 7.163 16 16-7.163 16-16 16zm1.922-18.207v-2.366h5.414V7.819H8.595v3.608h5.414v2.365c-4.4.202-7.709 1.074-7.709 2.118 0 1.044 3.309 1.915 7.709 2.118v7.582h3.913v-7.584c4.393-.202 7.694-1.073 7.694-2.116 0-1.043-3.301-1.914-7.694-2.117zm0 3.59v-.002c-.11.008-.677.042-1.942.042-1.01 0-1.721-.03-1.971-.042v.003c-3.888-.171-6.79-.848-6.79-1.658 0-.809 2.902-1.486 6.79-1.66v2.644c.254.018.982.061 1.988.061 1.207 0 1.812-.05 1.925-.06v-2.643c3.88.173 6.775.85 6.775 1.658 0 .81-2.895 1.485-6.775 1.657z"/>`
}, X2 = {
  symbol: "xmr",
  color: "#000",
  colorIcon() {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><g fill="none" fill-rule="evenodd"><circle cx="16" cy="16" r="16" fill="#F60"/><path fill="#FFF" fill-rule="nonzero" d="M15.97 5.235c5.985 0 10.825 4.84 10.825 10.824a11.07 11.07 0 01-.558 3.432h-3.226v-9.094l-7.04 7.04-7.04-7.04v9.094H5.704a11.07 11.07 0 01-.557-3.432c0-5.984 4.84-10.824 10.824-10.824zM14.358 19.02L16 20.635l1.613-1.614 3.051-3.08v5.72h4.547a10.806 10.806 0 01-9.24 5.192c-3.902 0-7.334-2.082-9.24-5.192h4.546v-5.72l3.08 3.08z"/></g>';
  },
  plainIcon: (e) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path fill-rule="evenodd" fill="${e || globalThis.color}" fill-rule="evenodd" d="M16 32C7.163 32 0 24.837 0 16S7.163 0 16 0s16 7.163 16 16-7.163 16-16 16zm-.03-26.765A10.816 10.816 0 005.148 16.059c0 1.202.205 2.346.557 3.432h3.227v-9.094l7.04 7.04 7.04-7.04v9.094h3.226a11.07 11.07 0 00.558-3.432c0-5.984-4.84-10.824-10.824-10.824zM14.358 19.02l-3.08-3.08v5.72H6.731c1.906 3.11 5.338 5.192 9.24 5.192 3.901 0 7.362-2.082 9.24-5.192h-4.547v-5.72l-3.05 3.08L16 20.635l-1.643-1.614z"/>`
};
lf.add([j2, B2, X2, H2, V2, Y2, G2, K2, q2, W2, U2]);
f2.add(A2, T2, O2, S2, C2, D2, I2, k2, N2, M2, P2, R2, z2);
const J2 = de({
  name: "PaymentMethod",
  components: {
    CryptoIcon: lf,
    Navigator: ei,
    RadioGroup: Gu,
    RadioGroupDescription: qu,
    RadioGroupLabel: Wu,
    RadioGroupOption: Yu,
    DialogTitle: ln,
    FontAwesomeIcon: E2,
    Disclosure: D1,
    DisclosureButton: z1,
    DisclosurePanel: L1
  },
  setup() {
    const { context: e } = ut(), t = {
      PAYPAL: {
        description: "Checkout with your PayPal account",
        name: "PayPal",
        icon: "fa-brands fa-paypal"
      },
      PAYSTACK: {
        description: "Pay with credit and debit card",
        name: "PayStack",
        icon: "fa-solid fa-money-bill-wave"
      },
      STRIPE: {
        description: "Debit and credit card, Apple/Google Pay, and more",
        name: "Stripe",
        icon: "fa-brands fa-cc-stripe"
      },
      CASHAPP: {
        description: "Checkout with your Cash App account",
        name: "Cash App",
        icon: "fa-solid fa-credit-card"
      },
      SQUARE: {
        description: "Debit and credit card, Apple/Google Pay, and more",
        name: "Square",
        icon: "fa-solid fa-credit-card"
      },
      VENMO: {
        description: "Pay directly with your Venmo account",
        name: "Venmo",
        icon: "fa-solid fa-v"
      },
      PADDLE: {
        description: "Debit and credit card, Apple/Google Pay, and more",
        name: "Paddle",
        icon: "fa-solid fa-credit-card"
      },
      BTC: {
        description: "Pay with Bitcoin",
        name: "Bitcoin",
        icon: "Btc"
      },
      LTC: {
        description: "Pay with Litecoin",
        name: "Litecoin",
        icon: "Ltc"
      },
      ETH: {
        description: "Pay with Ethereum",
        name: "Ethereum",
        icon: "Eth"
      },
      XMR: {
        description: "Pay with Monero",
        name: "Monero",
        icon: "Xmr"
      },
      BNB: {
        description: "Pay with BNB",
        name: "BNB",
        icon: "Bnb"
      },
      TRX: {
        description: "Pay with Tron",
        name: "Tron",
        icon: "Trx"
      },
      MATIC: {
        description: "Pay with Polygon",
        name: "Polygon",
        icon: "Matic"
      },
      ETH_USDT: {
        description: "Pay with USDT",
        name: "USDT",
        icon: "Usdt"
      },
      ETH_USDC: {
        description: "Pay with USDC",
        name: "USDC",
        icon: "Usdc"
      },
      ETH_UNI: {
        description: "Pay with UNI",
        name: "Uniswap",
        icon: "Uni"
      },
      ETH_SHIB: {
        description: "Pay with SHIB",
        name: "Shiba Inu",
        icon: "Eth"
      },
      ETH_DAI: {
        description: "Pay with DAI",
        name: "Dai",
        icon: "Dai"
      }
    }, n = (o) => {
      var a, s;
      return o = o.toLowerCase(), ((s = (a = e.value.variant) == null ? void 0 : a.payment_discounts) == null ? void 0 : s[o]) || 0;
    }, r = {
      type: e.value.variant.discord_request ? "CONNECT_DISCORD" : "CUSTOMER_EMAIL"
    }, i = $(() => !Qn(e.value.variant.crypto_options));
    return {
      checkout_information: Ee,
      context: e,
      paymentMethods: t,
      getDiscount: n,
      next: r,
      showCrypto: i
    };
  }
}), Q2 = { class: "embed-flex embed-flex-col embed-px-4 embed-pt-5 embed-pb-4 sm:embed-p-6" }, Z2 = { class: "embed-mt-3 embed-space-y-4" }, eg = /* @__PURE__ */ k("div", { class: "embed-rounded-lg embed-w-full embed-py-2 embed-px-6 embed-flex embed-flex-col embed-text-black dark:embed-text-white" }, [
  /* @__PURE__ */ k("p", { class: "embed-font-medium embed-text-left embed-mb-1" }, "Crypto"),
  /* @__PURE__ */ k("p", { class: "embed-text-xs embed-font-medium embed-text-left" }, "Click to show cryptocurrency options")
], -1), tg = { class: "embed-space-y-4" }, ng = { class: "embed-flex embed-items-center embed-justify-between embed-flex-grow-0" }, rg = { class: "embed-text-sm" }, ig = { class: "embed-mr-1" }, og = {
  key: 0,
  class: "embed-bg-white dark:embed-bg-black embed-rounded-xl embed-shadow dark:embed-shadow-black embed-text-xs embed-text-black dark:embed-text-white embed-absolute -embed-bottom-4 embed-left-1/2 -embed-translate-x-1/2 -embed-translate-y-1/2 embed-px-2"
}, ag = {
  key: 1,
  class: "embed-bg-white dark:embed-bg-black embed-rounded-xl embed-shadow dark:embed-shadow-black embed-text-xs embed-text-black dark:embed-text-white embed-absolute -embed-bottom-4 embed-left-1/2 -embed-translate-x-1/2 -embed-translate-y-1/2 embed-px-2"
}, sg = /* @__PURE__ */ k("div", {
  class: "embed-absolute -embed-inset-px embed-rounded-lg embed-pointer-events-none",
  "aria-hidden": "true"
}, null, -1), lg = { class: "embed-flex embed-items-center embed-justify-between embed-flex-grow-0" }, cg = { class: "embed-text-sm" }, ug = { class: "embed-mr-1" }, dg = {
  key: 0,
  class: "embed-bg-white dark:embed-bg-black embed-rounded-xl embed-shadow dark:embed-shadow-black embed-text-xs embed-text-black dark:embed-text-white embed-absolute -embed-bottom-4 embed-left-1/2 -embed-translate-x-1/2 -embed-translate-y-1/2 embed-px-2"
}, fg = {
  key: 1,
  class: "embed-bg-white dark:embed-bg-black embed-rounded-xl embed-shadow dark:embed-shadow-black embed-text-xs embed-text-black dark:embed-text-white embed-absolute -embed-bottom-4 embed-left-1/2 -embed-translate-x-1/2 -embed-translate-y-1/2 embed-px-2"
}, mg = /* @__PURE__ */ k("div", {
  class: "embed-absolute -embed-inset-px embed-rounded-lg embed-pointer-events-none",
  "aria-hidden": "true"
}, null, -1), pg = ["textContent"], bg = ["textContent"], hg = ["textContent"];
function vg(e, t, n, r, i, o) {
  var y, g, w, x, I, U, M, C, R, W, F, A, X, ce, Ce;
  const a = te("DialogTitle"), s = te("RadioGroupLabel"), l = te("RadioGroupDescription"), c = te("DisclosureButton"), u = te("CryptoIcon"), f = te("RadioGroupOption"), d = te("DisclosurePanel"), m = te("Disclosure"), p = te("font-awesome-icon"), h = te("RadioGroup"), _ = te("Navigator");
  return D(), Y("div", null, [
    k("div", Q2, [
      H(a, {
        as: "h2",
        class: "embed-font-bold embed-text-center embed-text-black dark:embed-text-white embed-text-xl"
      }, {
        default: ne(() => [
          ye("Payment Method")
        ]),
        _: 1
      }),
      H(h, {
        modelValue: e.checkout_information.payment_method,
        "onUpdate:modelValue": t[0] || (t[0] = (J) => e.checkout_information.payment_method = J)
      }, {
        default: ne(() => [
          H(s, { class: "embed-sr-only" }, {
            default: ne(() => [
              ye("Payment Method")
            ]),
            _: 1
          }),
          H(l, { class: "embed-mb-4 embed-font-normal embed-text-center embed-text-zinc-800 dark:embed-text-zinc-400 embed-text-xs" }, {
            default: ne(() => [
              ye("Select which payment method you'd like to pay with")
            ]),
            _: 1
          }),
          k("div", Z2, [
            e.showCrypto ? (D(), $e(m, { key: 0 }, {
              default: ne(() => [
                H(c, { class: "embed-w-full embed-rounded-lg embed-bg-white dark:embed-from-zinc-800 dark:[background:linear-gradient(theme(colors.zinc.800),_theme(colors.zinc.800))_padding-box,_conic-gradient(theme(colors.zinc.500),_theme(colors.zinc.800)_25%,_theme(colors.zinc.800)_75%,_theme(colors.zinc.500)_100%)_border-box] dark:embed-border dark:embed-border-transparent embed-shadow-inner embed-shadow-zinc-200 hover:embed-shadow-zinc-300 dark:embed-shadow-neutral-900 dark:hover:embed-shadow-black embed-transition embed-duration-300 embed-ease-in-out" }, {
                  default: ne(() => [
                    eg
                  ]),
                  _: 1
                }),
                H(Wn, {
                  "enter-active-class": "embed-transition embed-duration-100 embed-ease-out embed-origin-top",
                  "enter-from-class": "embed-transform embed-scale-0 embed-opacity-0",
                  "enter-to-class": "embed-transform embed-scale-100 embed-opacity-100",
                  "leave-active-class": "embed-transition embed-duration-100 embed-ease-in embed-origin-top",
                  "leave-from-class": "embed-transform embed-scale-100 embed-opacity-100",
                  "leave-to-class": "embed-transform embed-scale-0 embed-opacity-0"
                }, {
                  default: ne(() => [
                    H(d, null, {
                      default: ne(() => [
                        k("div", tg, [
                          (D(!0), Y(De, null, zr(e.context.variant.crypto_options, (J) => (D(), $e(f, {
                            key: J,
                            as: "template",
                            value: J
                          }, {
                            default: ne(({ checked: V }) => [
                              k("div", {
                                class: _e(["embed-flex embed-flex-col dark:embed-border dark:embed-border-transparent embed-shadow-inner", [V ? "embed-bg-white dark:[background:linear-gradient(theme(colors.zinc.950),_theme(colors.zinc.950))_padding-box,_conic-gradient(theme(colors.zinc.400),_theme(colors.zinc.700)_25%,_theme(colors.zinc.700)_75%,_theme(colors.zinc.400)_100%)_border-box] embed-shadow-zinc-400 dark:embed-shadow-black" : "embed-shadow-zinc-200 hover:embed-shadow-zinc-300 focus:embed-shadow-zinc-400 dark:embed-shadow-neutral-900 dark:hover:embed-shadow-black dark:focus:embed-shadow-neutral-800 embed-bg-white dark:[background:linear-gradient(theme(colors.zinc.800),_theme(colors.zinc.800))_padding-box,_conic-gradient(theme(colors.zinc.500),_theme(colors.zinc.800)_25%,_theme(colors.zinc.800)_75%,_theme(colors.zinc.500)_100%)_border-box]", "embed-transition embed-duration-300 embed-ease-in-out embed-relative embed-rounded-lg embed-px-6 embed-py-4 embed-cursor-pointer sm:embed-flex sm:embed-justify-between focus:embed-outline-none"]])
                              }, [
                                k("div", ng, [
                                  k("div", rg, [
                                    H(s, {
                                      as: "p",
                                      class: "embed-font-medium embed-text-black dark:embed-text-white"
                                    }, {
                                      default: ne(() => {
                                        var G, me;
                                        return [
                                          k("span", ig, [
                                            H(u, {
                                              symbol: (G = e.paymentMethods) == null ? void 0 : G[J].icon,
                                              size: "24",
                                              class: _e(["embed-w-6 embed-h-6", [V ? "embed-text-black dark:embed-text-white" : "embed-text-zinc-600 dark:embed-text-zinc-300"]])
                                            }, null, 8, ["symbol", "class"])
                                          ]),
                                          k("span", {
                                            class: _e(["embed-capitalize embed-ml-1", [V ? "embed-text-black dark:embed-text-white embed-font-bold" : "embed-text-zinc-700 dark:embed-text-zinc-300"]])
                                          }, ie((me = e.paymentMethods) == null ? void 0 : me[J].name), 3)
                                        ];
                                      }),
                                      _: 2
                                    }, 1024)
                                  ]),
                                  e.getDiscount(J) !== null && e.getDiscount(J) > 0 ? (D(), Y("div", og, [
                                    ye(" Get "),
                                    k("strong", null, ie(e.getDiscount(J)) + "%", 1),
                                    ye(" off ")
                                  ])) : xe("", !0),
                                  e.getDiscount(J) !== null && e.getDiscount(J) < 0 ? (D(), Y("div", ag, [
                                    ye(" Costs "),
                                    k("strong", null, ie(e.getDiscount(J) * -1) + "%", 1),
                                    ye(" extra ")
                                  ])) : xe("", !0)
                                ]),
                                H(l, {
                                  as: "div",
                                  class: _e(["embed-flex embed-text-xs embed-text-left dark:embed-text-zinc-100 embed-mt-2", [V ? "embed-text-black dark:embed-text-white" : "embed-text-zinc-500 dark:embed-text-zinc-400"]])
                                }, {
                                  default: ne(() => {
                                    var G;
                                    return [
                                      ye(ie((G = e.paymentMethods) == null ? void 0 : G[J].description), 1)
                                    ];
                                  }),
                                  _: 2
                                }, 1032, ["class"]),
                                sg
                              ], 2)
                            ]),
                            _: 2
                          }, 1032, ["value"]))), 128))
                        ])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })) : xe("", !0),
            (D(!0), Y(De, null, zr(e.context.variant.payment_processors, (J) => (D(), $e(f, {
              key: J,
              as: "template",
              value: J
            }, {
              default: ne(({ checked: V }) => [
                k("div", {
                  class: _e(["embed-flex embed-flex-col dark:embed-border dark:embed-border-transparent embed-shadow-inner", [V ? "embed-bg-white dark:[background:linear-gradient(theme(colors.zinc.950),_theme(colors.zinc.950))_padding-box,_conic-gradient(theme(colors.zinc.400),_theme(colors.zinc.700)_25%,_theme(colors.zinc.700)_75%,_theme(colors.zinc.400)_100%)_border-box] embed-shadow-zinc-400 dark:embed-shadow-black" : "embed-shadow-zinc-200 hover:embed-shadow-zinc-300 focus:embed-shadow-zinc-400 dark:embed-shadow-neutral-900 dark:hover:embed-shadow-black dark:focus:embed-shadow-neutral-800 embed-bg-white dark:[background:linear-gradient(theme(colors.zinc.800),_theme(colors.zinc.800))_padding-box,_conic-gradient(theme(colors.zinc.500),_theme(colors.zinc.800)_25%,_theme(colors.zinc.800)_75%,_theme(colors.zinc.500)_100%)_border-box]", "embed-transition embed-duration-300 embed-ease-in-out embed-relative embed-rounded-lg embed-px-6 embed-py-4 embed-cursor-pointer sm:embed-flex sm:embed-justify-between focus:embed-outline-none"]])
                }, [
                  k("div", lg, [
                    k("div", cg, [
                      H(s, {
                        as: "p",
                        class: "embed-flex embed-items-center embed-font-medium embed-text-black dark:embed-text-white"
                      }, {
                        default: ne(() => {
                          var G, me;
                          return [
                            k("span", ug, [
                              H(p, {
                                icon: (G = e.paymentMethods) == null ? void 0 : G[J].icon,
                                class: _e(["embed-w-6 embed-h-6", [V ? "embed-text-black dark:embed-text-white" : "embed-text-zinc-600 dark:embed-text-zinc-300"]])
                              }, null, 8, ["icon", "class"])
                            ]),
                            k("span", {
                              class: _e(["embed-capitalize embed-ml-1", [V ? "embed-text-black dark:embed-text-white embed-font-bold" : "embed-text-zinc-700 dark:embed-text-zinc-300"]])
                            }, ie((me = e.paymentMethods) == null ? void 0 : me[J].name), 3)
                          ];
                        }),
                        _: 2
                      }, 1024)
                    ]),
                    e.getDiscount(J) !== null && e.getDiscount(J) > 0 ? (D(), Y("div", dg, [
                      ye(" Get "),
                      k("strong", null, ie(e.getDiscount(J)) + "%", 1),
                      ye(" off ")
                    ])) : xe("", !0),
                    e.getDiscount(J) !== null && e.getDiscount(J) < 0 ? (D(), Y("div", fg, [
                      ye(" Costs "),
                      k("strong", null, ie(e.getDiscount(J) * -1) + "%", 1),
                      ye(" extra ")
                    ])) : xe("", !0)
                  ]),
                  H(l, {
                    as: "div",
                    class: _e(["embed-flex embed-text-xs embed-text-left embed-mt-2 embed-transition embed-duration-200 embed-ease-in-out", [V ? "embed-text-black dark:embed-text-white" : "embed-text-zinc-500 dark:embed-text-zinc-400"]])
                  }, {
                    default: ne(() => {
                      var G;
                      return [
                        ye(ie((G = e.paymentMethods) == null ? void 0 : G[J].description), 1)
                      ];
                    }),
                    _: 2
                  }, 1032, ["class"]),
                  mg
                ], 2)
              ]),
              _: 2
            }, 1032, ["value"]))), 128))
          ])
        ]),
        _: 1
      }, 8, ["modelValue"]),
      (w = (g = (y = e.context.error) == null ? void 0 : y.errors) == null ? void 0 : g.payment_method) != null && w[0] ? (D(), Y("p", {
        key: 0,
        class: "embed-ml-1.5 embed-mt-1 embed-text-left embed-text-sm embed-text-red-600 dark:embed-text-red embed-w-full",
        textContent: ie((I = (x = e.context.error) == null ? void 0 : x.errors) == null ? void 0 : I.payment_method[0])
      }, null, 8, pg)) : xe("", !0),
      (C = (M = (U = e.context.error) == null ? void 0 : U.errors) == null ? void 0 : M.total) != null && C[0] ? (D(), Y("p", {
        key: 1,
        class: "embed-ml-1.5 embed-mt-1 embed-text-left embed-text-sm embed-text-red-600 dark:embed-text-red embed-w-full",
        textContent: ie((W = (R = e.context.error) == null ? void 0 : R.errors) == null ? void 0 : W.total[0])
      }, null, 8, bg)) : xe("", !0),
      (X = (A = (F = e.context.error) == null ? void 0 : F.errors) == null ? void 0 : A.discord_token) != null && X[0] ? (D(), Y("p", {
        key: 2,
        class: "embed-ml-1.5 embed-mt-1 embed-text-left embed-text-sm embed-text-red-600 dark:embed-text-red embed-w-full",
        textContent: ie((Ce = (ce = e.context.error) == null ? void 0 : ce.errors) == null ? void 0 : Ce.discord_token[0])
      }, null, 8, hg)) : xe("", !0),
      H(_, {
        next: e.next,
        class: _e(e.checkout_information.payment_method == null ? "embed-hidden" : "")
      }, null, 8, ["next", "class"])
    ])
  ]);
}
const gg = /* @__PURE__ */ qe(J2, [["render", vg]]), yg = de({
  name: "InputGroup",
  components: {
    ExclamationCircleIcon: Id
  },
  inheritAttrs: !1,
  props: {
    type: {
      type: String,
      required: !0
    },
    errorKey: {
      type: String,
      required: !1,
      default: null
    },
    modelValue: {
      type: null,
      required: !1,
      default: null
    },
    label: {
      type: String,
      required: !1,
      default: null
    },
    fieldKey: {
      type: String,
      required: !1,
      default: null
    }
  },
  emits: ["update:modelValue"],
  setup(e, { slots: t, emit: n }) {
    const { context: r } = ut();
    function i(s) {
      n("update:modelValue", s);
    }
    const o = (s) => !!t[s], a = $(() => {
      var s, l, c;
      return (c = (l = (s = r.value.error) == null ? void 0 : s.errors) == null ? void 0 : l[e.errorKey]) == null ? void 0 : c[0];
    });
    return {
      hasSlot: o,
      emitUpdate: i,
      error: a
    };
  }
}), _g = ["for"], wg = {
  key: 0,
  class: "embed-absolute embed-inset-y-0 embed-left-0 embed-pl-3 embed-pt-1 embed-flex embed-items-center embed-pointer-events-none"
}, xg = ["type", "value"], Eg = ["id", "checked", "type", "value"], kg = ["value"], Sg = ["textContent"];
function Og(e, t, n, r, i, o) {
  const a = te("ExclamationCircleIcon");
  return D(), Y(De, null, [
    k("div", {
      class: _e({
        "embed-justify-between embed-flex embed-items-center embed-h-5": e.type === "checkbox"
      })
    }, [
      k("label", {
        for: e.fieldKey,
        class: "embed-block embed-text-sm embed-font-medium embed-text-black dark:embed-text-white"
      }, ie(e.label), 9, _g),
      k("div", {
        class: _e(["embed-relative embed-rounded-md", { "embed-mt-1": e.type !== "checkbox" && !!e.label }])
      }, [
        e.type !== "checkbox" && e.type !== "textarea" ? (D(), Y("div", wg, [
          Vi(e.$slots, "icon")
        ])) : xe("", !0),
        e.type !== "textarea" && e.type !== "checkbox" ? (D(), Y("input", Or({
          key: 1,
          type: e.type,
          class: {
            "embed-border embed-border-transparent embed-w-full embed-rounded-md embed-bg-white dark:[background:linear-gradient(theme(colors.zinc.950),_theme(colors.zinc.950))_padding-box,_conic-gradient(theme(colors.zinc.400),_theme(colors.zinc.700)_25%,_theme(colors.zinc.700)_75%,_theme(colors.zinc.400)_100%)_border-box] embed-text-black dark:embed-text-white embed-placeholder-neutral-500 focus:embed-placeholder-neutral-800 dark:embed-placeholder-neutral-500 dark:focus:embed-placeholder-neutral-400 focus:embed-ring-0 embed-shadow-inner embed-shadow-zinc-200 hover:embed-shadow-zinc-300 focus:embed-shadow-zinc-400 dark:embed-shadow-black dark:hover:embed-shadow-zinc-600 dark:focus:embed-shadow-zinc-600 embed-transition embed-duration-200 embed-ease-in-out disabled:embed-bg-zinc-100 dark:disabled:embed-bg-zinc-900 disabled:embed-opacity-70": e.type !== "checkbox",
            "embed-pl-10": e.hasSlot("icon"),
            "embed-placeholder-red-300 dark:embed-placeholder-red-600 embed-text-red-900 embed-border-red-300 focus:embed-ring-red-500 focus:embed-border-red-500": !!e.error,
            "embed-pr-10": !!e.error && e.type !== "number"
          },
          value: e.modelValue
        }, e.$attrs, {
          onInput: t[0] || (t[0] = (s) => e.emitUpdate(s.target.value))
        }), null, 16, xg)) : e.type === "checkbox" ? (D(), Y("input", Or({
          key: 2,
          id: e.fieldKey,
          checked: e.modelValue,
          type: e.type,
          class: "embed-appearance-none embed-rounded focus:embed-border-zinc-100 focus:embed-ring-0 focus:embed-ring-offset-0 dark:focus:embed-border-transparent dark:focus:embed-text-black embed-bg-white dark:[background:linear-gradient(theme(colors.zinc.950),_theme(colors.zinc.950))_padding-box,_conic-gradient(theme(colors.zinc.400),_theme(colors.zinc.700)_25%,_theme(colors.zinc.700)_75%,_theme(colors.zinc.400)_100%)_border-box] embed-text-black dark:embed-text-white embed-placeholder-neutral-500 focus:embed-placeholder-neutral-800 dark:embed-placeholder-neutral-500 dark:focus:embed-placeholder-neutral-400 embed-shadow-inner embed-shadow-zinc-200 hover:embed-shadow-zinc-300 focus:embed-shadow-zinc-400 dark:embed-shadow-black dark:hover:embed-shadow-zinc-600 dark:focus:embed-shadow-zinc-600 embed-transition embed-duration-200 embed-ease-in-out disabled:embed-bg-zinc-100 dark:disabled:embed-bg-zinc-900 disabled:embed-opacity-70 embed-border embed-border-transparent checked:embed-bg-zinc-950",
          value: e.modelValue
        }, e.$attrs, {
          onInput: t[1] || (t[1] = (s) => e.emitUpdate(s.target.checked))
        }), null, 16, Eg)) : (D(), Y("textarea", Or({
          key: 3,
          class: ["embed-w-full embed-bg-white focus:embed-bg-zinc-50 dark:[background:linear-gradient(theme(colors.zinc.950),_theme(colors.zinc.950))_padding-box,_conic-gradient(theme(colors.zinc.400),_theme(colors.zinc.700)_25%,_theme(colors.zinc.700)_75%,_theme(colors.zinc.400)_100%)_border-box] embed-text-black dark:embed-text-zinc-100 embed-border embed-border-transparent embed-rounded-md embed-placeholder-neutral-500 focus:embed-placeholder-neutral-800 dark:embed-placeholder-neutral-500 dark:focus:embed-placeholder-neutral-400 focus:embed-outline-none embed-shadow-inner embed-shadow-zinc-200 hover:embed-shadow-zinc-300 focus:embed-shadow-zinc-400 dark:embed-shadow-black dark:hover:embed-shadow-zinc-600 dark:focus:embed-shadow-zinc-600 focus:embed-ring-0 focus:embed-border-transparent embed-transition embed-duration-200 embed-ease-in-out", {
            "embed-placeholder-red-300 embed-text-red-900 embed-border-red-300 focus:embed-ring-red-500 focus:embed-border-red-500": !!e.error
          }],
          value: e.modelValue
        }, e.$attrs, {
          onInput: t[2] || (t[2] = (s) => e.emitUpdate(s.target.value))
        }), null, 16, kg)),
        e.error && (e.type === "text" || e.type === "email") ? (D(), Y("div", {
          key: 4,
          class: _e(["embed-absolute embed-inset-y-0 embed-right-0 embed-pr-3 embed-flex embed-items-center embed-pointer-events-none", { "embed-mr-6": e.type === "number" }])
        }, [
          H(a, {
            class: "embed-h-5 embed-w-5 embed-text-red-500 dark:embed-text-red-900",
            "aria-hidden": "true"
          })
        ], 2)) : xe("", !0)
      ], 2)
    ], 2),
    e.error ? (D(), Y("p", {
      key: 0,
      class: "embed-mt-1 embed-text-xs embed-text-red-600 dark:embed-text-red embed-w-full embed-flex-grow",
      textContent: ie(e.error)
    }, null, 8, Sg)) : xe("", !0)
  ], 64);
}
const Ts = /* @__PURE__ */ qe(yg, [["render", Og]]), Ag = de({
  name: "ConnectDiscord",
  components: {
    Navigator: ei,
    DialogTitle: ln,
    InputGroup: Ts,
    MyButton: Io
  },
  setup() {
    const { context: e } = ut();
    let t = re(e.value.discord_data.discord_username);
    Ee.discord_token = e.value.discord_data.discord_token;
    const n = re(!0), r = () => {
      const o = window.open(e.value.discord_data.connect_url, "_blank", "width=400, height=600");
      (!o || o.closed || typeof o.closed > "u") && (n.value = !1);
    }, i = (o) => {
      var u;
      const a = o.data, s = /^((http[s]?|ftp):\/)?\/?([^:/\s]+)((\/\w+)*\/)([\w\-.]+[^#?\s]+)(.*)?(#[\w-]+)?$/, l = Zr.match(s), c = l[2] + "://" + l[3];
      o.origin === c && !Qn(a) && (u = e.value.discord_data) != null && u.connect_url && (sessionStorage.setItem("discord_token", a.discord_token), e.value.discord_data = {
        discord_id: a.discord_id,
        discord_token: a.discord_token,
        discord_username: a.discord_username,
        connect_url: e.value.discord_data.connect_url
      }, Ee.discord_token = a.discord_token, t.value = e.value.discord_data.discord_username);
    };
    return window.addEventListener("message", i), {
      checkout_information: Ee,
      context: e,
      linkDiscord: r,
      receiveData: i,
      popUpsEnabled: n,
      discordUsername: t
    };
  }
}), Ng = { class: "embed-flex embed-flex-col embed-px-4 embed-pt-5 embed-pb-4 sm:embed-p-6" }, Ig = ["textContent"], Cg = { class: "embed-mt-4" }, Tg = {
  key: 0,
  class: "embed-text-center embed-mt-2 embed-bg-white dark:embed-bg-black embed-rounded-2xl embed-px-4 embed-py-2"
}, Pg = /* @__PURE__ */ k("span", { class: "embed-font-medium embed-text-black dark:embed-text-white" }, "To continue your purchase, you'll want to connect your Discord account.", -1), Mg = [
  Pg
], Rg = {
  key: 1,
  class: "embed-text-center embed-mt-2 embed-bg-white dark:embed-bg-black embed-rounded-2xl embed-px-4 embed-py-2"
}, Dg = /* @__PURE__ */ k("span", { class: "embed-font-medium embed-text-black dark:embed-text-white" }, "Optionally connect your Discord to get exclusive accesss with your purchase.", -1), zg = [
  Dg
], Lg = {
  key: 1,
  class: "embed-mt-5 embed-text-red-500"
}, $g = /* @__PURE__ */ k("p", null, "Please, enable pop ups to proceed.", -1), Fg = [
  $g
], Vg = { key: 2 };
function jg(e, t, n, r, i, o) {
  const a = te("DialogTitle"), s = te("InputGroup"), l = te("MyButton"), c = te("Navigator");
  return D(), Y("div", Ng, [
    H(a, {
      as: "h1",
      class: "embed-font-bold embed-text-center embed-text-xl embed-text-black dark:embed-text-white"
    }, {
      default: ne(() => [
        ye("Connect discord")
      ]),
      _: 1
    }),
    e.discordUsername ? (D(), $e(s, {
      key: 0,
      class: "embed-text-center",
      type: "text",
      label: "",
      value: e.discordUsername,
      disabled: ""
    }, null, 8, ["value"])) : xe("", !0),
    H(l, {
      class: "embed-w-full embed-bg-[#5865F2] embed-text-white embed-mt-4",
      onClick: e.linkDiscord
    }, {
      default: ne(() => [
        k("span", {
          textContent: ie(e.checkout_information.discord_id ? "Change discord account" : "Connect discord")
        }, null, 8, Ig)
      ]),
      _: 1
    }, 8, ["onClick"]),
    k("div", Cg, [
      e.context.variant.discord_required ? (D(), Y("div", Tg, Mg)) : e.context.variant.discord_request ? (D(), Y("div", Rg, zg)) : xe("", !0)
    ]),
    e.popUpsEnabled ? xe("", !0) : (D(), Y("div", Lg, Fg)),
    e.context.variant.discord_required && e.checkout_information.discord_token || !e.context.variant.discord_required ? (D(), Y("div", Vg, [
      H(c)
    ])) : xe("", !0)
  ]);
}
const Ug = /* @__PURE__ */ qe(Ag, [["render", jg]]), Hg = de({
  name: "FinalStep",
  components: {
    Navigator: ei,
    DialogTitle: ln,
    DialogDescription: Lu
  },
  setup() {
    var o;
    const { context: e } = ut(), t = re(!1), n = $(() => e.value.variant), r = $(() => e.value.product);
    let i = parseFloat(e.value.variant.total.replace(/[^\d.-]/g, "")) || 0;
    if (e.value.variant.payment_discounts && Ee.payment_method) {
      const a = e.value.variant.payment_discounts[Ee.payment_method.toLowerCase()];
      if (a !== null && !isNaN(a)) {
        const s = parseFloat(a) / 100;
        i += i * s * -1;
      }
    }
    if (e.value.variant.available_vat_countries && Ee.country) {
      const a = (o = e.value.variant.available_vat_countries[Ee.country]) == null ? void 0 : o.vat;
      if (a !== null && !isNaN(a)) {
        const s = parseFloat(a) / 100;
        i += i * s;
      }
    }
    return {
      checkout_information: Ee,
      context: e,
      variant: n,
      product: r,
      price: i,
      terms_of_service: t
    };
  },
  methods: {
    capitalized(e) {
      const t = e[0].toUpperCase(), n = e.slice(1);
      return t + n;
    }
  }
}), Bg = { class: "embed-flex embed-flex-col embed-px-4 embed-pt-5 embed-pb-4 sm:embed-p-6" }, Gg = { class: "embed-p-3 embed-text-left embed-flex embed-flex-row embed-justify-between" }, Yg = { class: "embed-block embed-text-sm embed-font-medium embed-text-black dark:embed-text-white" }, Wg = ["textContent"], qg = { class: "embed-space-y-2 embed-mx-2 embed-bg-zinc-50 dark:embed-bg-zinc-950 embed-py-3 embed-px-3 embed-rounded-2xl embed-shadow-inner dark:embed-shadow-black embed-text-sm embed-font-medium embed-text-black dark:embed-text-white" }, Kg = { class: "embed-text-left embed-flex embed-flex-row embed-justify-between" }, Xg = /* @__PURE__ */ k("p", { class: "embed-block embed-text-sm embed-font-normal embed-text-black dark:embed-text-white" }, "Subtotal", -1), Jg = ["textContent"], Qg = /* @__PURE__ */ k("p", { class: "embed-block embed-text-sm embed-font-normal embed-text-black dark:embed-text-white" }, "Bulk discount", -1), Zg = { class: "embed-block embed-text-sm embed-font-normal embed-text-black dark:embed-text-white" }, ey = { class: "embed-inline-flex embed-items-center embed-space-x-2 embed-text-sm embed-font-normal embed-text-black dark:embed-text-white" }, ty = /* @__PURE__ */ k("span", null, "Coupon", -1), ny = { class: "embed-flex embed-rounded-lg embed-bg-zinc-100 embed-px-2 embed-text-sm embed-font-medium dark:embed-bg-black" }, ry = { class: "embed-block embed-text-sm embed-font-normal embed-text-black dark:embed-text-white" }, iy = { class: "embed-block embed-text-sm embed-font-normal embed-text-black dark:embed-text-white" }, oy = { class: "embed-block embed-text-sm embed-font-normal embed-text-black dark:embed-text-white" }, ay = { class: "embed-block embed-text-sm embed-font-normal embed-text-black dark:embed-text-white" }, sy = { class: "embed-block embed-text-sm embed-font-normal embed-text-black dark:embed-text-white" }, ly = { class: "embed-p-3 embed-flex embed-flex-row embed-justify-between" }, cy = /* @__PURE__ */ k("p", { class: "embed-block embed-text-sm embed-font-medium embed-text-black dark:embed-text-white" }, "Total", -1), uy = { class: "embed-block embed-text-sm embed-font-medium embed-text-black dark:embed-text-white" }, dy = { class: "embed-px-3 embed-mt-4 embed-relative embed-flex embed-items-center" }, fy = /* @__PURE__ */ k("div", { class: "embed-min-w-0 embed-flex-1 embed-text-left embed-text-sm" }, [
  /* @__PURE__ */ k("label", {
    for: "terms_of_service",
    class: "embed-select-none embed-mb-0 embed-font-semibold embed-text-sm embed-text-zinc-800 dark:embed-text-neutral-300"
  }, "By making this purchase, you agree to the terms of service")
], -1), my = { class: "embed-ml-3 embed-flex embed-items-center embed-h-5" }, py = ["checked"];
function by(e, t, n, r, i, o) {
  const a = te("DialogTitle"), s = te("DialogDescription"), l = te("Navigator");
  return D(), Y("div", Bg, [
    H(a, {
      as: "h1",
      class: "embed-font-bold embed-text-center embed-text-xl embed-text-black dark:embed-text-white"
    }, {
      default: ne(() => [
        ye("Order Overview")
      ]),
      _: 1
    }),
    H(s, {
      as: "p",
      class: "embed-mb-4 embed-font-normal embed-text-center embed-text-zinc-800 dark:embed-text-zinc-400 embed-text-xs"
    }, {
      default: ne(() => [
        ye("Finally, review your order details before checking out")
      ]),
      _: 1
    }),
    k("div", Gg, [
      k("p", Yg, ie(e.context.quantity) + "x " + ie(e.product.title), 1),
      k("p", {
        class: "embed-block embed-text-sm embed-font-medium embed-text-black dark:embed-text-white",
        textContent: ie(e.variant.price)
      }, null, 8, Wg)
    ]),
    k("div", qg, [
      k("div", Kg, [
        Xg,
        k("p", {
          class: "embed-block embed-text-sm embed-font-normal embed-text-black dark:embed-text-white",
          textContent: ie(e.variant.price)
        }, null, 8, Jg)
      ]),
      k("div", {
        class: _e(["embed-text-left embed-flex embed-flex-row embed-justify-between", e.context.variant.bulk_discount == null ? "embed-hidden" : ""])
      }, [
        Qg,
        k("p", Zg, "-" + ie(e.context.variant.bulk_discount), 1)
      ], 2),
      k("div", {
        class: _e(["embed-text-left embed-flex embed-flex-row embed-justify-between", e.context.coupon == null ? "embed-hidden" : ""])
      }, [
        k("p", ey, [
          ty,
          k("span", ny, ie(e.context.coupon), 1)
        ]),
        k("p", ry, "-" + ie(e.context.variant.coupon), 1)
      ], 2),
      k("div", {
        class: _e(["embed-text-left embed-flex embed-flex-row embed-justify-between", !e.context.variant.payment_discounts || e.context.variant.payment_discounts[e.checkout_information.payment_method.toLowerCase()] == null ? "embed-hidden" : ""])
      }, [
        k("p", iy, "Payment " + ie(e.context.variant.payment_discounts && e.context.variant.payment_discounts[e.checkout_information.payment_method.toLowerCase()] < 0 ? "fee" : "discount"), 1),
        k("p", oy, ie(e.context.variant.payment_discounts && e.context.variant.payment_discounts[e.checkout_information.payment_method.toLowerCase()] > 0 ? "-" : "+") + ie(Math.abs(e.context.variant.payment_discounts && e.context.variant.payment_discounts[e.checkout_information.payment_method.toLowerCase()])) + "%", 1)
      ], 2),
      k("div", {
        class: _e(["embed-text-left embed-flex embed-flex-row embed-justify-between", !e.checkout_information.country || e.context.variant.available_vat_countries[e.checkout_information.country].vat == 0 ? "embed-hidden" : ""])
      }, [
        k("p", ay, "VAT (" + ie(e.checkout_information.country && e.context.variant.available_vat_countries[e.checkout_information.country].name) + ")", 1),
        k("p", sy, "+" + ie(e.checkout_information.country && e.context.variant.available_vat_countries[e.checkout_information.country].vat) + "%", 1)
      ], 2)
    ]),
    k("div", ly, [
      cy,
      k("p", uy, ie(e.context.variant.total.replace(/[^\D]+.*/, "")) + " " + ie(!isNaN(e.price) && isFinite(e.price) ? e.price.toFixed(2) : e.context.variant.total.replace(/[^\d]+.*/, "")), 1)
    ]),
    k("div", dy, [
      fy,
      k("div", my, [
        Fi(k("input", {
          id: "terms_of_service",
          "onUpdate:modelValue": t[0] || (t[0] = (c) => e.terms_of_service = c),
          checked: e.terms_of_service == !0,
          required: "",
          name: "terms_of_service",
          type: "checkbox",
          class: "embed-p-2 embed-appearance-none embed-rounded focus:embed-ring-offset-0 embed-bg-white checked:embed-bg-black dark:embed-bg-zinc-800 dark:focus:embed-bg-zinc-950 embed-text-black dark:embed-text-white embed-placeholder-neutral-500 focus:embed-placeholder-neutral-800 dark:embed-placeholder-neutral-500 dark:focus:embed-placeholder-neutral-400 embed-border embed-border-zinc-100 hover:embed-border-zinc-200 focus:embed-border-zinc-400 dark:embed-border-zinc-800 dark:hover:embed-border-zinc-950 dark:focus:embed-border-zinc-800 focus:embed-ring-0 embed-shadow-inner embed-shadow-zinc-400 hover:embed-shadow-zinc-500 focus:embed-shadow-zinc-200 dark:embed-shadow-neutral-800 dark:hover:embed-shadow-neutral-900 dark:focus:embed-shadow-neutral-800 embed-transition embed-duration-200 embed-ease-in-out"
        }, null, 8, py), [
          [Dp, e.terms_of_service]
        ])
      ])
    ]),
    H(l, {
      next: { type: "CHECKOUT" },
      text: "Pay Now",
      "loading-state": "checkout.step.final_step.checkout_product",
      class: _e(e.terms_of_service == !1 ? "embed-hidden" : "")
    }, null, 8, ["class"])
  ]);
}
const hy = /* @__PURE__ */ qe(Hg, [["render", by]]), vy = de({
  name: "AdditionalInformation",
  components: {
    InputGroup: Ts
  },
  setup() {
    const { context: e } = ut(), t = $(() => e.value.variant.additional_information);
    return e.value.variant.additional_information.length > 0 && (Ee.additional_information ?? (Ee.additional_information = {}), t.value.forEach((n) => {
      var r, i;
      if ((Ee.additional_information[n.key] ?? null) === null) {
        let o;
        n.type === "CHECKBOX" ? o = !1 : n.type === "NUMBER" ? o = 0 : o = "", (r = Ee.additional_information)[i = n.key] ?? (r[i] = o);
      }
    })), {
      checkout_information: Ee,
      context: e,
      required_fields: t
    };
  }
}), gy = { class: "embed-space-y-4 embed-bg-zinc-50 dark:embed-bg-zinc-950 embed-py-4 embed-px-3 embed-rounded-2xl embed-shadow-inner dark:embed-shadow-black" };
function yy(e, t, n, r, i, o) {
  const a = te("InputGroup");
  return D(), Y("div", gy, [
    (D(!0), Y(De, null, zr(e.required_fields, (s) => (D(), Y(De, { key: s }, [
      s.type === "TEXTAREA" ? (D(), $e(a, {
        key: 0,
        modelValue: e.checkout_information.additional_information[s.key],
        "onUpdate:modelValue": (l) => e.checkout_information.additional_information[s.key] = l,
        type: s.type.toLowerCase(),
        "error-key": `additional_information.${s.key}`,
        placeholder: s.label,
        rows: "3",
        label: s.label
      }, null, 8, ["modelValue", "onUpdate:modelValue", "type", "error-key", "placeholder", "label"])) : s.type === "NUMBER" ? (D(), $e(a, {
        key: 1,
        modelValue: e.checkout_information.additional_information[s.key],
        "onUpdate:modelValue": (l) => e.checkout_information.additional_information[s.key] = l,
        type: s.type.toLowerCase(),
        "error-key": `additional_information.${s.key}`,
        placeholder: s.label,
        label: s.label,
        min: "1",
        class: "embed-w-full"
      }, null, 8, ["modelValue", "onUpdate:modelValue", "type", "error-key", "placeholder", "label"])) : s.type === "TEXT" ? (D(), $e(a, {
        key: 2,
        modelValue: e.checkout_information.additional_information[s.key],
        "onUpdate:modelValue": (l) => e.checkout_information.additional_information[s.key] = l,
        type: s.type.toLowerCase(),
        "error-key": `additional_information.${s.key}`,
        placeholder: s.label,
        label: s.label
      }, null, 8, ["modelValue", "onUpdate:modelValue", "type", "error-key", "placeholder", "label"])) : (D(), $e(a, {
        key: 3,
        modelValue: e.checkout_information.additional_information[s.key],
        "onUpdate:modelValue": (l) => e.checkout_information.additional_information[s.key] = l,
        "field-key": `additional_information.${s.key}`,
        type: s.type.toLowerCase(),
        "error-key": `additional_information.${s.key}`,
        placeholder: s.label,
        label: s.label
      }, null, 8, ["modelValue", "onUpdate:modelValue", "field-key", "type", "error-key", "placeholder", "label"]))
    ], 64))), 128))
  ]);
}
const _y = /* @__PURE__ */ qe(vy, [["render", yy]]), wy = de({
  name: "CustomerEmail",
  components: {
    Navigator: ei,
    InputGroup: Ts,
    AdditionalInformation: _y,
    EnvelopeIcon: Eh,
    DialogTitle: ln,
    DialogDescription: Lu
  },
  setup() {
    const { context: e } = ut(), t = e.value.variant.additional_information.map((r) => r.key);
    Ee.additional_information = t.filter((r) => r in Ee.additional_information).reduce((r, i) => (r[i] = Ee.additional_information[i], r), {}), Qn(Ee.country) && (Ee.country = e.value.variant.current_country), Qn(e.value.email) || (Ee.customer_email = e.value.email);
    const n = {
      type: e.value.variant.discord_request ? "CONNECT_DISCORD" : "PAYMENT_METHODS"
    };
    return {
      checkout_information: Ee,
      context: e,
      back: n
    };
  }
}), xy = { class: "embed-flex embed-flex-col embed-px-4 embed-pt-5 embed-pb-4 sm:embed-p-6" }, Ey = { class: "embed-p-3 embed-text-left" }, ky = {
  key: 0,
  class: "embed-py-3 embed-text-left"
}, Sy = {
  key: 1,
  class: "embed-p-3 embed-text-left embed-flex embed-flex-col embed-gap-3"
}, Oy = { class: "embed-block embed-text-sm embed-font-medium embed-text-black dark:embed-text-white" }, Ay = /* @__PURE__ */ k("span", null, "Country", -1), Ny = ["value"], Iy = { key: 0 };
function Cy(e, t, n, r, i, o) {
  var d;
  const a = te("DialogTitle"), s = te("DialogDescription"), l = te("EnvelopeIcon"), c = te("InputGroup"), u = te("AdditionalInformation"), f = te("Navigator");
  return D(), Y("div", xy, [
    H(a, {
      as: "h1",
      class: "embed-font-bold embed-text-center embed-text-xl embed-text-black dark:embed-text-white"
    }, {
      default: ne(() => [
        ye("Delivery Details")
      ]),
      _: 1
    }),
    H(s, {
      as: "p",
      class: "embed-mb-4 embed-font-normal embed-text-center embed-text-zinc-800 dark:embed-text-zinc-400 embed-text-xs"
    }, {
      default: ne(() => [
        ye("Enter your delivery information below")
      ]),
      _: 1
    }),
    k("div", Ey, [
      H(c, {
        modelValue: e.checkout_information.customer_email,
        "onUpdate:modelValue": t[0] || (t[0] = (m) => e.checkout_information.customer_email = m),
        "error-key": "customer_email",
        type: "email",
        label: "Email",
        placeholder: "example@example.com"
      }, {
        icon: ne(() => [
          H(l, {
            class: "embed-h-5 embed-w-5 embed-text-zinc-400",
            "aria-hidden": "true"
          })
        ]),
        _: 1
      }, 8, ["modelValue"])
    ]),
    e.context.variant.additional_information.length > 0 ? (D(), Y("div", ky, [
      H(u)
    ])) : xe("", !0),
    e.context.variant.vat_enabled ? (D(), Y("div", Sy, [
      k("label", Oy, [
        Ay,
        Fi(k("select", {
          id: "country",
          "onUpdate:modelValue": t[1] || (t[1] = (m) => e.checkout_information.country = m),
          name: "country",
          class: "embed-mt-1 embed-appearance-none embed-w-full embed-bg-white dark:embed-bg-zinc-800 embed-text-black dark:embed-text-zinc-400 embed-border embed-border-zinc-100 hover:embed-border-zinc-200 focus:embed-border-zinc-400 dark:embed-border-zinc-800 dark:hover:embed-border-zinc-950 dark:focus:embed-border-zinc-800 embed-rounded-lg focus:embed-ring-0 embed-shadow-inner embed-shadow-zinc-200 hover:embed-shadow-zinc-300 dark:embed-shadow-neutral-800 dark:hover:embed-shadow-neutral-900 embed-transition embed-duration-200 embed-ease-in-out disabled:embed-bg-zinc-100 dark:disabled:embed-bg-zinc-900 disabled:embed-opacity-70"
        }, [
          (D(!0), Y(De, null, zr(e.context.variant.available_vat_countries, (m, p) => (D(), Y("option", {
            key: p,
            value: p
          }, ie(m.name), 9, Ny))), 128))
        ], 512), [
          [zp, e.checkout_information.country]
        ])
      ]),
      e.context.variant.vat_enabled && ((d = e.context.variant.available_vat_countries[e.checkout_information.country]) == null ? void 0 : d.vat) > 0 ? (D(), Y("div", Iy, [
        H(c, {
          id: "vat_id",
          modelValue: e.checkout_information.vat_id,
          "onUpdate:modelValue": t[2] || (t[2] = (m) => e.checkout_information.vat_id = m),
          "error-key": "vat_id",
          type: "text",
          label: "VAT ID",
          placeholder: "DE123456789",
          name: "vat_id"
        }, null, 8, ["modelValue"])
      ])) : xe("", !0)
    ])) : xe("", !0),
    H(f, { back: e.back }, null, 8, ["back"])
  ]);
}
const Ty = /* @__PURE__ */ qe(wy, [["render", Cy]]), Py = de({
  name: "DialogMessage",
  components: {
    DialogTitle: ln
  },
  props: {
    title: {
      type: String,
      required: !1,
      default: null
    },
    message: {
      type: String,
      required: !1,
      default: null
    }
  }
}), My = { class: "embed-flex embed-flex-col embed-items-center embed-justify-evenly embed-h-4/6 embed-w-full embed-p-6" }, Ry = { class: "embed-flex embed-flex-col embed-items-center" }, Dy = { class: "embed-bg-zinc-100 embed-p-4 embed-rounded-lg embed-w-11/12 embed-mt-4 dark:embed-bg-zinc-800 embed-text-black dark:embed-text-white embed-shadow-inner dark:embed-shadow-black" };
function zy(e, t, n, r, i, o) {
  const a = te("DialogTitle");
  return D(), Y("div", My, [
    k("div", Ry, [
      Vi(e.$slots, "default"),
      H(a, {
        as: "h2",
        class: "embed-mb-0 embed-mt-3 embed-font-bold embed-text-2xl embed-text-black dark:embed-text-white"
      }, {
        default: ne(() => [
          ye(ie(e.title), 1)
        ]),
        _: 1
      })
    ]),
    k("div", Dy, [
      Vi(e.$slots, "action", {}, () => [
        k("p", null, ie(e.message), 1)
      ])
    ])
  ]);
}
const Ps = /* @__PURE__ */ qe(Py, [["render", zy]]), Ly = {
  name: "LoadingSpinner"
}, $y = { class: "embed-absolute embed-flex embed-justify-center embed-items-center embed-w-full embed-h-full embed-z-50 embed-bg-opacity-70" }, Fy = /* @__PURE__ */ k("span", { class: "embed-animate-ping embed-absolute embed-inline-flex embed-h-24 embed-w-24 embed-rounded-full embed-bg-zinc-700 embed-opacity-75" }, null, -1), Vy = [
  Fy
];
function jy(e, t, n, r, i, o) {
  return D(), Y("div", $y, Vy);
}
const Uy = /* @__PURE__ */ qe(Ly, [["render", jy]]), Hy = de({
  name: "SuccessDialog",
  components: {
    DialogMessage: Ps,
    CheckCircleIcon: Cd
  },
  setup: function() {
    const { context: e } = ut();
    return {
      context: e
    };
  }
}), By = ["href"];
function Gy(e, t, n, r, i, o) {
  const a = te("CheckCircleIcon"), s = te("DialogMessage");
  return D(), $e(s, {
    class: "embed-bg-white embed-text-center dark:embed-bg-zinc-900 embed-rounded-2xl embed-shadow-xl",
    title: "Order Created"
  }, {
    action: ne(() => [
      k("p", null, [
        ye(" Your order has been created! If the payment gateway did not open by itself, "),
        k("a", {
          href: e.context.order,
          class: "embed-font-bold embed-underline embed-decoration-zinc-800 dark:embed-decoration-zinc-50 hover:embed-decoration-wavy",
          target: "_blank"
        }, "click here to open it.", 8, By)
      ])
    ]),
    default: ne(() => [
      H(a, { class: "embed-h-24 embed-w-24 embed-text-green-600" })
    ]),
    _: 1
  });
}
const Yy = /* @__PURE__ */ qe(Hy, [["render", Gy]]), Wy = de({
  name: "HeadsUpDialog",
  components: {
    DialogMessage: Ps
  }
}), qy = /* @__PURE__ */ k("p", { class: "embed-mb-4" }, "Once paid, the order will instantly be sent to your entered email. That's it!", -1), Ky = /* @__PURE__ */ k("p", { class: "embed-text-xs" }, "Note: If you paid with PayPal, we will send the product to your PayPal email for security reasons.", -1);
function Xy(e, t, n, r, i, o) {
  const a = te("DialogMessage");
  return D(), $e(a, {
    class: "embed-bg-white embed-text-center dark:embed-bg-zinc-900 embed-rounded-2xl embed-shadow-xl",
    title: "What's Next?"
  }, {
    action: ne(() => [
      qy,
      Ky
    ]),
    _: 1
  });
}
const Jy = /* @__PURE__ */ qe(Wy, [["render", Xy]]);
function Qy(e) {
  return Object.keys(e).reduce((t, n) => {
    const r = e[n];
    return Object.assign(t, r), t;
  }, {});
}
const Zy = de({
  name: "EmbedCheckout",
  components: {
    LoadingSpinner: Uy,
    MyDialog: C1,
    DialogPanel: P1,
    DialogOverlay: T1,
    DialogTitle: ln,
    TransitionChild: Ju,
    TransitionRoot: Qu,
    ExclamationCircleIcon: Id,
    VariantSelection: Gh,
    Overview: C0,
    PaymentMethod: gg,
    ConnectDiscord: Ug,
    FinalStep: hy,
    CustomerEmail: Ty,
    Navigator: ei,
    DialogMessage: Ps,
    CheckCircleIcon: Cd,
    SuccessDialog: Yy,
    HeadsUpDialog: Jy
  },
  setup: function() {
    const { context: e, state: t, send: n } = ut();
    return Tl(), window.setupCheckoutButtons = Tl, {
      stepComponent: $(() => t.value.matches("checkout") ? Qy(t.value.meta).component : null),
      context: e,
      state: t,
      send: n
    };
  }
}), e3 = {
  id: "embed-modal",
  class: "embed-fixed embed-z-10 embed-inset-0 embed-overflow-auto"
}, t3 = /* @__PURE__ */ k("span", {
  class: "embed-hidden sm:embed-inline-block sm:embed-align-middle sm:embed-h-screen",
  "aria-hidden": "true"
}, "​", -1), n3 = { class: "embed-relative embed-z-50 embed-max-w-xl embed-w-full embed-inline-block embed-align-middle embed-px-4" }, r3 = {
  key: 1,
  class: "embed-space-y-4"
}, i3 = {
  key: 1,
  class: "embed-space-y-6"
};
function o3(e, t, n, r, i, o) {
  const a = te("DialogOverlay"), s = te("TransitionChild"), l = te("LoadingSpinner"), c = te("SuccessDialog"), u = te("HeadsUpDialog"), f = te("ExclamationCircleIcon"), d = te("DialogMessage"), m = te("DialogPanel"), p = te("MyDialog"), h = te("TransitionRoot");
  return D(), $e(h, {
    as: "template",
    show: !e.state.matches("closed")
  }, {
    default: ne(() => [
      H(p, {
        as: "div",
        onClose: t[0] || (t[0] = (_) => e.send("CLOSE"))
      }, {
        default: ne(() => [
          H(m, null, {
            default: ne(() => [
              k("div", e3, [
                k("div", {
                  class: _e(["embed-flex embed-items-center embed-justify-center embed-min-h-screen embed-text-center", { "embed-dark": e.context.customization.darkMode }])
                }, [
                  H(s, {
                    as: "template",
                    enter: "embed-ease-out embed-duration-300",
                    "enter-from": "embed-opacity-0",
                    "enter-to": "embed-opacity-100",
                    leave: "embed-ease-in embed-duration-200",
                    "leave-from": "embed-opacity-100",
                    "leave-to": "embed-opacity-0"
                  }, {
                    default: ne(() => [
                      H(a, { class: "embed-fixed embed-inset-0 embed-bg-zinc-500 dark:embed-bg-black embed-bg-opacity-50 dark:embed-bg-opacity-50 embed-transition-opacity" })
                    ]),
                    _: 1
                  }),
                  t3,
                  H(s, {
                    as: "template",
                    enter: "embed-ease-out embed-duration-300",
                    "enter-from": "embed-opacity-0 embed-translate-y-4 sm:embed-translate-y-0 sm:embed-scale-95",
                    "enter-to": "embed-opacity-100 embed-translate-y-0 sm:embed-scale-100",
                    leave: "embed-ease-in embed-duration-200",
                    "leave-from": "embed-opacity-100 embed-translate-y-0 sm:embed-scale-100",
                    "leave-to": "embed-opacity-0 embed-translate-y-4 sm:embed-translate-y-0 sm:embed-scale-95"
                  }, {
                    default: ne(() => [
                      k("div", n3, [
                        e.state.hasTag("loading") ? (D(), $e(l, { key: 0 })) : (D(), Y("div", r3, [
                          e.stepComponent ? (D(), $e(Wn, {
                            key: 0,
                            "enter-active-class": "embed-duration-500 embed-ease-out",
                            "enter-from-class": "embed-opacity-0 embed--translate-x-full md:embed-translate-x-full",
                            "enter-to-class": "embed-opacity-100 embed-translate-x-0",
                            "leave-active-class": "embed-duration-500 embed-ease-out",
                            "leave-from-class": "embed-opacity-100 embed-translate-x-0",
                            "leave-to-class": "embed-opacity-0 embed--translate-x-full",
                            mode: "out-in"
                          }, {
                            default: ne(() => [
                              (D(), $e(Cm(e.stepComponent), { class: "embed-bg-white embed-text-center dark:embed-bg-zinc-900 embed-rounded-lg embed-shadow-md dark:embed-shadow-black embed-overflow-hidden" }))
                            ]),
                            _: 1
                          })) : e.state.matches("invoice_processed") ? (D(), Y("div", i3, [
                            H(c),
                            H(u)
                          ])) : e.state.matches("error") ? (D(), $e(d, {
                            key: 2,
                            class: "embed-bg-white embed-text-center dark:embed-bg-zinc-900 embed-rounded-lg embed-shadow-md dark:embed-shadow-black embed-overflow-hidden",
                            title: "Whoops",
                            message: e.context.error.message
                          }, {
                            default: ne(() => [
                              H(f, { class: "embed-h-24 embed-w-24 embed-text-zinc-600" })
                            ]),
                            _: 1
                          }, 8, ["message"])) : xe("", !0)
                        ]))
                      ])
                    ]),
                    _: 1
                  })
                ], 2)
              ])
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  }, 8, ["show"]);
}
const a3 = /* @__PURE__ */ qe(Zy, [["render", o3]]);
const s3 = Fp(a3), cf = document.createElement("div");
document.body.append(cf);
s3.mount(cf);
